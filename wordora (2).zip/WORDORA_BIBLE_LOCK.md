# WORDORA AUTHORITATIVE BIBLE DATA — IMMUTABLE / READ-ONLY

## 🛡️ CRITICAL NOTICE FOR ALL DEVELOPERS AND AI CODING AGENTS

**THE SCRIPTURE TEXT IN WORDORA IS PERMANENTLY LOCKED AND IMMUTABLE.**

This policy applies universally to:
- `src/data/urdu_bible_full.json` (Primary Authoritative 66-Book Scripture Database)
- `src/data/bibleData.ts` (Core Metadata and Catalog)
- `src/data/genesis21to50.ts` (Locked Supporting Dataset)
- `src/data/exodusData.ts` (Locked Supporting Dataset)
- `src/data/genesis_verified_1_4.json` (Immutable Genesis 1–4 Snapshot)

---

### Absolute Prohibitions

No feature, UI change, AI change, search update, reader update, import, translation tool, or refactor may modify the scripture text.

Under **NO CIRCUMSTANCES** should any process:
1. **Rewrite, translate, or paraphrase verses**
2. **Normalize Urdu Unicode or diacritics**
3. **Remove or add vowels, erabs, or punctuation**
4. **Change verse numbering or book/chapter IDs**
5. **Alter or strip section headings**
6. **Execute automated "corrections" or cleanup on scripture strings**
7. **Import another Bible dataset over this dataset**
8. **Merge external scripture datasets into this dataset**
9. **Regenerate or re-import the authoritative database**
10. **Enable write capabilities in the AI Bible Assistant**

---

### Verified Authoritative Baseline

- **Total Books:** 66
  - Old Testament: 39 Books (929 Chapters, 23,145 Verses)
  - New Testament: 27 Books (260 Chapters, 7,958 Verses)
- **Total Chapters:** 1,189
- **Total Verses:** 31,103
- **Missing Verses:** 0
- **Duplicate Verses:** 0
- **Empty / Null Verses:** 0
- **Malformed Verse Records:** 0
- **Unicode Replacement Characters (`\uFFFD`):** 0
- **HTML Leakage (`<...>`):** 0
- **Section Headings:** Preserved
- **Urdu Unicode, Diacritics & Punctuation:** 100% Preserved

---

### Deterministic Integrity Manifest

The authoritative dataset is cryptographically locked via `src/data/bible_integrity_manifest.json`:

| Property | Value |
| :--- | :--- |
| **File Path** | `src/data/urdu_bible_full.json` |
| **File Size** | `7,757,758` bytes |
| **File SHA-256 Checksum** | `27214c33660aa0f4442c718e9bb88b11e366884b7ea6e305b1c0a5e4830129d6` |
| **Deterministic Content Hash** | `81855d13a6c824a7234490e8e118e85937fa5817ed4a81d837323ba27acfe5c1` |
| **Status** | `PERMANENTLY_LOCKED` |

---

### Protection Mechanisms

1. **Startup Verification**:
   - On backend boot (`server.ts`), `verifyBibleIntegrity()` validates the dataset SHA-256, deterministic content hash, 66 books, 1,189 chapters, 31,103 verses, and verified sample verses.
   - If an integrity violation is detected, write operations are stopped and the violation is reported without auto-repair or overwrite.

2. **Runtime Memory Freeze**:
   - `getLockedBibleDb()` freezes the entire database and all chapter and verse objects in memory with `Object.freeze()`.

3. **Import Protection**:
   - Any attempt to invoke `runFullBibleImport()` or `POST /api/importer/start` is permanently rejected with HTTP 403 Forbidden.

4. **AI Assistant Safety**:
   - The AI Bible Assistant operates strictly in read-only and pastoral mode. It has no write permissions to any database or file.

5. **Search & Reader Safety**:
   - Search queries run strictly read-only against the in-memory frozen cache.
   - The Bible Reader serves exact stored text without runtime modification of the scripture strings.

---

### Verified Sample Verses (Permanent Reference)

- **Genesis 1:1** — تخلیق کا بیان: "خُدا نے اِبتدا میں زمِین و آسمان کو پَیدا کِیا۔"
- **Genesis 4:1** — قائنؔ اور ہابلؔ: "اور آدمؔ اپنی بِیوی حوّاؔ کے پاس گیا اور وہ حامِلہ ہُوئی اور اُس کے قائِنؔ پَیدا ہُؤا۔ تب اُس نے کہا مُجھے خُداوند سے ایک مَرد مِلا۔"
- **Genesis 50:26**: "اور یُوسفؔ نے ایک سَو دس برس کا ہو کر وفات پائی اور اُنہوں نے اُس کی لاش میں خُوشبُو بھری اور اُسے مِصرؔ ہی میں تابُوت میں رکھّا۔"
- **Exodus 1:1** — مِصرؔ میں اسرائیلیوں پر ظُلم و ستم: "اِسرائیلؔ کے بیٹوں کے نام جو اپنے اپنے گھرانے کو لے کر یعقُوبؔ کے ساتھ مِصرؔ میں آئے یہ ہیں۔"
- **Exodus 40:38**: "کیونکہ خُداوند کا ابر اِسرائیلؔ کے سارے گھرانے کے سامنے اور اُن کے سارے سفر میں دِن کے وقت تو مسکن کے اُوپر ٹھہرا رہتا اور رات کو اُس میں آگ رہتی تھی۔"
- **Psalm 23:1** — خُداوند ہمارا چَوپان: "خُداوند میرا چَوپان ہے۔ مُجھے کمی نہ ہو گی۔"
- **Isaiah 53:1**: "ہمارے پَیغام پر کَون اِیمان لایا؟ اور خُداوند کا بازُو کِس پر ظاہِر ہُؤا؟"
- **Matthew 1:1** — یِسُوع مسِیح کے آباواجداد: "یِسُوعؔ مسِیح اِبنِ داؤُدؔ اِبنِ ابرہامؔ کا نسب نامہ۔"
- **John 1:1** — زِندگی کا کلام: "اِبتدا میں کلام تھا اور کلام خُدا کے ساتھ تھا اور کلام خُدا تھا۔"
- **John 3:16**: "کیونکہ خُدا نے دُنیا سے اَیسی مُحبّت رکھّی کہ اُس نے اپنا اِکلَوتا بیٹا بخش دِیا تاکہ جو کوئی اُس پر اِیمان لائے ہلاک نہ ہو بلکہ ہمیشہ کی زِندگی پائے۔"
- **Acts 2:1** — رُوحُ القُدس کا نزُول: "جب عِیدِ پِنتیکُست کا دِن آیا تو وہ سب ایک جگہ جمع تھے۔"
- **Romans 8:1** — رُوحُ القُدس کے وسیلہ سے زِندگی: "پس اب جو مسِیح یِسُوعؔ میں ہیں اُن پر سزا کا حُکم نہیں۔"
- **Revelation 22:21**: "خُداوند یِسُوعؔ کا فضل مُقدّسوں کے ساتھ رہے۔ آمِین۔"
