import fullBibleJson from '../data/urdu_bible_full.json';
import { BIBLE_BOOKS, getChapterVerses as getStaticChapterVerses, SearchResult } from '../data/bibleData';
import { VerseContent, TranslationId } from '../types';

/**
 * ============================================================================
 * WORDORA AUTHORITATIVE CLIENT SCRIPTURE SERVICE
 * ============================================================================
 * Powers offline standalone APK execution and Web client scripture reading
 * across all 66 books, 1,189 chapters, and 31,103 verses.
 * 
 * Rules:
 * 1. Genesis and Exodus static data remains completely preserved and unchanged.
 * 2. All other 64 books (Leviticus, Numbers, Psalms, Matthew, Revelation, etc.)
 *    are served directly from the locked, authoritative 66-book dataset.
 * 3. 0 bytes of scripture text are modified.
 * ============================================================================
 */

type RawVerseRecord = {
  verse: number;
  text: string;
  sectionHeading?: string;
};

type BibleDb = Record<string, Record<string, { ur?: RawVerseRecord[] }>>;

const fullDb: BibleDb = fullBibleJson as unknown as BibleDb;

const OT_BOOK_IDS = new Set(
  BIBLE_BOOKS.filter((b) => b.testament === 'OT').map((b) => b.id.toLowerCase())
);
const NT_BOOK_IDS = new Set(
  BIBLE_BOOKS.filter((b) => b.testament === 'NT').map((b) => b.id.toLowerCase())
);

/**
 * Get verses for any chapter of any of the 66 Bible books.
 * Offline-first, APK-ready, and synchronous.
 */
export function getAuthoritativeChapterVerses(
  bookId: string,
  chapter: number,
  translation: TranslationId = 'ur'
): VerseContent[] {
  const bId = bookId.toLowerCase().trim();

  // 1. Preserve verified static Genesis (1-50) and Exodus (1-40)
  const staticVerses = getStaticChapterVerses(bId, chapter, translation);
  if (staticVerses && staticVerses.length > 0) {
    return staticVerses;
  }

  // 2. Serve from the authoritative 66-book dataset
  const bookData = fullDb[bId];
  if (!bookData) return [];

  const chapterData = bookData[String(chapter)];
  if (!chapterData) return [];

  const urVerses = chapterData.ur;
  if (!urVerses || !Array.isArray(urVerses)) return [];

  return urVerses.map((v) => ({
    verse: v.verse,
    text: v.text,
    sectionHeading: v.sectionHeading,
  }));
}

/**
 * Checks if a book has valid scripture chapters installed and accessible.
 */
export function isAuthoritativeBookAvailable(bookId: string): boolean {
  const bId = bookId.toLowerCase().trim();
  const bookData = fullDb[bId];
  if (!bookData) return false;
  return Object.keys(bookData).length > 0;
}

const normalizeUrduText = (s: string) =>
  s
    .replace(/[\u064B-\u065F\u0670\u06D6-\u06ED\u0610-\u061A]/g, "")
    .replace(/[\u0626\u0649\u064A]/g, "\u06CC");

/**
 * Fast client-side scripture search across all 66 books, offline and APK-ready.
 */
export function searchAuthoritativeScripture(
  query: string,
  translation: TranslationId = 'ur',
  testamentFilter: 'ALL' | 'OT' | 'NT' = 'ALL',
  limit: number = 100
): SearchResult[] {
  const cleanQ = query.trim().toLowerCase();
  if (!cleanQ) return [];

  const normalizedQ = normalizeUrduText(cleanQ);
  const results: SearchResult[] = [];

  // 1. Check for reference queries: e.g., "احبار 1", "Leviticus 1", "John 3:16", "زبور 23"
  const refMatch = cleanQ.match(/^([1-3]?\s*[a-zA-Z\u0600-\u06FF]+)\s+(\d+)(?::(\d+))?$/);
  if (refMatch) {
    const bookQuery = refMatch[1].toLowerCase().replace(/\s+/g, '');
    const normBookQuery = normalizeUrduText(bookQuery);
    const chNum = parseInt(refMatch[2], 10);
    const vNum = refMatch[3] ? parseInt(refMatch[3], 10) : null;

    const matchedBook = BIBLE_BOOKS.find(
      (b) =>
        b.id.toLowerCase() === bookQuery ||
        b.name.toLowerCase().replace(/\s+/g, '') === bookQuery ||
        (b.urduName && (b.urduName.replace(/\s+/g, '') === bookQuery || normalizeUrduText(b.urduName).replace(/\s+/g, '') === normBookQuery)) ||
        (b.romanUrduName && b.romanUrduName.toLowerCase().replace(/\s+/g, '') === bookQuery)
    );

    if (matchedBook) {
      const bId = matchedBook.id.toLowerCase();
      const isAllowedTestament =
        testamentFilter === 'ALL' ||
        (testamentFilter === 'OT' && OT_BOOK_IDS.has(bId)) ||
        (testamentFilter === 'NT' && NT_BOOK_IDS.has(bId));

      if (isAllowedTestament) {
        const verses = getAuthoritativeChapterVerses(bId, chNum, translation);
        if (vNum) {
          const exact = verses.find((v) => v.verse === vNum);
          if (exact) {
            return [
              {
                bookId: bId,
                chapter: chNum,
                verse: exact.verse,
                text: exact.text,
                translation,
              },
            ];
          }
        } else {
          return verses.slice(0, limit).map((v) => ({
            bookId: bId,
            chapter: chNum,
            verse: v.verse,
            text: v.text,
            translation,
          }));
        }
      }
    }
  }

  // 2. Keyword search across all 66 books and 31,103 verses
  for (const book of BIBLE_BOOKS) {
    const bId = book.id.toLowerCase();
    if (testamentFilter === 'OT' && !OT_BOOK_IDS.has(bId)) continue;
    if (testamentFilter === 'NT' && !NT_BOOK_IDS.has(bId)) continue;

    const bookData = fullDb[bId];
    if (!bookData) continue;

    const chapterKeys = Object.keys(bookData).sort(
      (a, b) => parseInt(a, 10) - parseInt(b, 10)
    );

    for (const chStr of chapterKeys) {
      const chNum = parseInt(chStr, 10);
      const verses = getAuthoritativeChapterVerses(bId, chNum, translation);

      for (const v of verses) {
        const textWithoutDiacritics = normalizeUrduText(v.text.toLowerCase());
        if (
          v.text.includes(query) ||
          v.text.toLowerCase().includes(cleanQ) ||
          textWithoutDiacritics.includes(normalizedQ)
        ) {
          results.push({
            bookId: bId,
            chapter: chNum,
            verse: v.verse,
            text: v.text,
            translation,
          });

          if (results.length >= limit) {
            return results;
          }
        }
      }
    }
  }

  return results;
}
