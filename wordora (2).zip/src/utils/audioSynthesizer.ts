// Sacred Audio Engine for WordOra

class SacredAudioEngine {
  private ctx: AudioContext | null = null;
  private isPlaying: boolean = false;
  private masterGain: GainNode | null = null;
  private activeOscillators: OscillatorNode[] = [];
  private chordInterval: number | null = null;

  private initContext() {
    if (!this.ctx) {
      const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
      if (AudioCtx) {
        this.ctx = new AudioCtx();
        this.masterGain = this.ctx.createGain();
        this.masterGain.gain.setValueAtTime(0.2, this.ctx.currentTime);
        this.masterGain.connect(this.ctx.destination);
      }
    }
    if (this.ctx && this.ctx.state === 'suspended') {
      this.ctx.resume();
    }
  }

  public playSacredMeditation() {
    try {
      this.initContext();
      if (!this.ctx || !this.masterGain) return;
      this.stop();
      this.isPlaying = true;

      // Gentle Sacred Chords (D major - A - Bm - G progression)
      const chords = [
        [146.83, 220.00, 293.66, 369.99, 440.00], // D Maj (D3, A3, D4, F#4, A4)
        [110.00, 164.81, 220.00, 277.18, 329.63], // A Maj (A2, E3, A3, C#4, E4)
        [123.47, 185.00, 246.94, 293.66, 369.99], // B Min (B2, F#3, B3, D4, F#4)
        [98.00, 146.83, 196.00, 246.94, 293.66],  // G Maj (G2, D3, G3, B3, D4)
      ];

      let chordIndex = 0;

      const playChord = (frequencies: number[]) => {
        if (!this.ctx || !this.masterGain || !this.isPlaying) return;

        // Clean up previous chord
        this.activeOscillators.forEach(osc => {
          try {
            osc.stop(this.ctx!.currentTime + 0.8);
          } catch (_) {}
        });
        this.activeOscillators = [];

        frequencies.forEach((freq, idx) => {
          const osc = this.ctx!.createOscillator();
          const gain = this.ctx!.createGain();

          // Soft sine wave with a warm second harmonic
          osc.type = idx % 2 === 0 ? 'sine' : 'triangle';
          osc.frequency.setValueAtTime(freq, this.ctx!.currentTime);

          // Attack - Decay - Sustain
          gain.gain.setValueAtTime(0.001, this.ctx!.currentTime);
          gain.gain.exponentialRampToValueAtTime(0.06 / (idx + 1), this.ctx!.currentTime + 1.2);

          osc.connect(gain);
          gain.connect(this.masterGain!);

          osc.start();
          this.activeOscillators.push(osc);
        });
      };

      playChord(chords[0]);
      this.chordInterval = window.setInterval(() => {
        chordIndex = (chordIndex + 1) % chords.length;
        playChord(chords[chordIndex]);
      }, 5500);

    } catch (e) {
      console.warn("Sacred audio could not start:", e);
    }
  }

  public stop() {
    this.isPlaying = false;
    if (this.chordInterval) {
      clearInterval(this.chordInterval);
      this.chordInterval = null;
    }
    if (this.activeOscillators.length > 0 && this.ctx) {
      this.activeOscillators.forEach(osc => {
        try {
          osc.stop();
          osc.disconnect();
        } catch (_) {}
      });
      this.activeOscillators = [];
    }
  }

  public getIsPlaying(): boolean {
    return this.isPlaying;
  }
}

export const sacredAudio = new SacredAudioEngine();

// Speech Synthesis Reader
export function speakVerses(text: string, onEnd?: () => void): () => void {
  if (typeof window === 'undefined' || !window.speechSynthesis) {
    if (onEnd) onEnd();
    return () => {};
  }

  window.speechSynthesis.cancel();
  const utterance = new SpeechSynthesisUtterance(text);
  utterance.rate = 0.9;
  utterance.pitch = 1.0;
  if (onEnd) {
    utterance.onend = onEnd;
    utterance.onerror = onEnd;
  }

  window.speechSynthesis.speak(utterance);

  return () => {
    window.speechSynthesis.cancel();
  };
}
