import { BookmarkItem, HighlightItem, NoteItem, PrayerItem, ReadingProgress, TranslationId } from '../types';

const STORAGE_KEYS = {
  CURRENT_PROGRESS: 'wordora_reading_progress',
  BOOKMARKS: 'wordora_bookmarks',
  HIGHLIGHTS: 'wordora_highlights',
  NOTES: 'wordora_notes',
  PRAYERS: 'wordora_prayers',
  PRAYER_REMINDER: 'wordora_prayer_reminder',
  READER_CONFIG: 'wordora_reader_config',
  DOWNLOADED_TRANSLATIONS: 'wordora_downloaded_trans',
};

export interface ReaderConfig {
  fontSize: number; // e.g. 17
  fontFamily: 'sans' | 'serif';
  lineHeight: number; // e.g. 1.7
}

export const defaultReaderConfig: ReaderConfig = {
  fontSize: 17,
  fontFamily: 'sans',
  lineHeight: 1.7,
};

export function getStoredProgress(): ReadingProgress {
  try {
    const data = localStorage.getItem(STORAGE_KEYS.CURRENT_PROGRESS);
    if (data) {
      const parsed = JSON.parse(data);
      return {
        ...parsed,
        translation: parsed.translation || '',
      };
    }
  } catch (_) {}
  return {
    bookId: 'genesis',
    chapter: 1,
    percent: 0,
    translation: '',
    updatedAt: new Date().toISOString(),
  };
}

export function saveStoredProgress(progress: ReadingProgress) {
  try {
    localStorage.setItem(STORAGE_KEYS.CURRENT_PROGRESS, JSON.stringify(progress));
  } catch (_) {}
}

export function getStoredBookmarks(): BookmarkItem[] {
  try {
    const data = localStorage.getItem(STORAGE_KEYS.BOOKMARKS);
    if (data) return JSON.parse(data);
  } catch (_) {}
  return [];
}

export function saveStoredBookmarks(items: BookmarkItem[]) {
  try {
    localStorage.setItem(STORAGE_KEYS.BOOKMARKS, JSON.stringify(items));
  } catch (_) {}
}

export function getStoredHighlights(): HighlightItem[] {
  try {
    const data = localStorage.getItem(STORAGE_KEYS.HIGHLIGHTS);
    if (data) return JSON.parse(data);
  } catch (_) {}
  return [];
}

export function saveStoredHighlights(items: HighlightItem[]) {
  try {
    localStorage.setItem(STORAGE_KEYS.HIGHLIGHTS, JSON.stringify(items));
  } catch (_) {}
}

export function getStoredNotes(): NoteItem[] {
  try {
    const data = localStorage.getItem(STORAGE_KEYS.NOTES);
    if (data) return JSON.parse(data);
  } catch (_) {}
  return [];
}

export function saveStoredNotes(items: NoteItem[]) {
  try {
    localStorage.setItem(STORAGE_KEYS.NOTES, JSON.stringify(items));
  } catch (_) {}
}

// Clears cached translation downloads while preserving all user records (prayers, settings, bookmarks)
export function resetBibleDatasetsCache() {
  try {
    localStorage.removeItem(STORAGE_KEYS.DOWNLOADED_TRANSLATIONS);
    localStorage.removeItem('wordora_bible_cache');
    localStorage.removeItem('wordora_active_translation');
  } catch (_) {}
}

export function getStoredPrayers(): PrayerItem[] {
  try {
    const data = localStorage.getItem(STORAGE_KEYS.PRAYERS);
    if (data) return JSON.parse(data);
  } catch (_) {}
  return [
    {
      id: 'pr-1',
      title: 'Peace & Healing for Family',
      content: 'Praying for good health, divine protection, and deep joy in Christ for parents and siblings.',
      category: 'family',
      isAnswered: false,
      prayerCount: 14,
      createdAt: '2026-09-12T07:00:00Z',
    },
    {
      id: 'pr-2',
      title: 'Spiritual Growth & Wisdom',
      content: 'Asking the Lord for wisdom in daily decisions and faithfulness in Scripture reading.',
      category: 'personal',
      isAnswered: true,
      prayerCount: 28,
      createdAt: '2026-09-05T06:30:00Z',
      answeredAt: '2026-09-10T12:00:00Z',
      testimony: 'Khuda ne dua suni aur dil mein azeem itminaan bakhsha.',
    },
    {
      id: 'pr-3',
      title: 'World Church & Every Nation',
      content: 'May the Gospel reach every tribe, nation, and language with power and grace.',
      category: 'community',
      isAnswered: false,
      prayerCount: 42,
      createdAt: '2026-09-08T09:00:00Z',
    },
  ];
}

export function saveStoredPrayers(items: PrayerItem[]) {
  try {
    localStorage.setItem(STORAGE_KEYS.PRAYERS, JSON.stringify(items));
  } catch (_) {}
}

export interface PrayerReminderConfig {
  enabled: boolean;
  time: string; // e.g. "07:00 AM"
}

export function getStoredPrayerReminder(): PrayerReminderConfig {
  try {
    const data = localStorage.getItem(STORAGE_KEYS.PRAYER_REMINDER);
    if (data) return JSON.parse(data);
  } catch (_) {}
  return { enabled: true, time: '7:00 AM' };
}

export function saveStoredPrayerReminder(cfg: PrayerReminderConfig) {
  try {
    localStorage.setItem(STORAGE_KEYS.PRAYER_REMINDER, JSON.stringify(cfg));
  } catch (_) {}
}

export function getStoredReaderConfig(): ReaderConfig {
  try {
    const data = localStorage.getItem(STORAGE_KEYS.READER_CONFIG);
    if (data) return JSON.parse(data);
  } catch (_) {}
  return defaultReaderConfig;
}

export function saveStoredReaderConfig(cfg: ReaderConfig) {
  try {
    localStorage.setItem(STORAGE_KEYS.READER_CONFIG, JSON.stringify(cfg));
  } catch (_) {}
}
