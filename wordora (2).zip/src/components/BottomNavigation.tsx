import React from 'react';
import { Home, BookOpen, Music, Search, Bookmark, Bot } from 'lucide-react';

export type NavTab = 'home' | 'bible' | 'worship' | 'search' | 'saved' | 'ai';

interface BottomNavigationProps {
  currentTab: NavTab;
  onSelectTab: (tab: NavTab) => void;
}

export const BottomNavigation: React.FC<BottomNavigationProps> = ({
  currentTab,
  onSelectTab,
}) => {
  const navItems: { id: NavTab; label: string; icon: React.FC<{ className?: string }> }[] = [
    { id: 'home', label: 'Home', icon: Home },
    { id: 'bible', label: 'Bible', icon: BookOpen },
    { id: 'worship', label: 'Worship', icon: Music },
    { id: 'search', label: 'Search', icon: Search },
    { id: 'saved', label: 'Saved', icon: Bookmark },
    { id: 'ai', label: 'AI Study', icon: Bot },
  ];

  return (
    <nav
      className="sticky bottom-0 z-40 bg-[#081220]/95 backdrop-blur-md border-t border-[#1F2A44] px-1 py-1 flex items-center justify-around select-none"
      aria-label="Main Navigation"
    >
      {navItems.map((item) => {
        const isActive = currentTab === item.id;
        const Icon = item.icon;

        return (
          <button
            key={item.id}
            type="button"
            onClick={() => onSelectTab(item.id)}
            className={`flex-1 min-h-[48px] py-1.5 px-1 flex flex-col items-center justify-center relative transition-all active:scale-95 ${
              isActive
                ? 'text-[#00C6FF]'
                : 'text-[#B6C0D1] hover:text-[#F7F6F2]'
            }`}
            aria-label={item.label}
          >
            {/* Active subtle light indicator bar */}
            {isActive && (
              <span className="absolute -top-[1px] w-8 h-[2px] rounded-full bg-gradient-to-r from-[#D4AF37] via-[#00C6FF] to-[#2563EB] shadow-[0_0_8px_rgba(0,198,255,0.8)]" />
            )}

            <div
              className={`p-1 rounded-lg transition-all ${
                isActive
                  ? 'text-[#00C6FF] drop-shadow-[0_0_8px_rgba(0,198,255,0.6)]'
                  : ''
              }`}
            >
              <Icon className="w-5 h-5 stroke-[2]" />
            </div>

            <span
              className={`text-[10px] font-medium tracking-wide mt-0.5 ${
                isActive ? 'text-[#00C6FF] font-semibold' : 'text-[#7A869A]'
              }`}
            >
              {item.label}
            </span>
          </button>
        );
      })}
    </nav>
  );
};
