import React, { useState } from 'react';
import { X, Check, Cloud, Download, Plus, ChevronLeft, ShieldCheck, Database } from 'lucide-react';
import { TRANSLATIONS } from '../data/bibleData';
import { TranslationId } from '../types';

interface TranslationsModalProps {
  isOpen: boolean;
  onClose: () => void;
  selectedTranslation: TranslationId;
  onSelectTranslation: (id: TranslationId) => void;
  onOpenFullImport?: () => void;
}

export const TranslationsModal: React.FC<TranslationsModalProps> = ({
  isOpen,
  onClose,
  selectedTranslation,
  onSelectTranslation,
  onOpenFullImport,
}) => {
  const [downloadedList, setDownloadedList] = useState<Record<TranslationId, boolean>>({ ur: true });

  const [downloadingId, setDownloadingId] = useState<TranslationId | null>(null);
  const [showAddMoreNotice, setShowAddMoreNotice] = useState(false);

  if (!isOpen) return null;

  const handleDownload = (id: TranslationId, e: React.MouseEvent) => {
    e.stopPropagation();
    if (downloadedList[id]) return;
    setDownloadingId(id);
    setTimeout(() => {
      setDownloadedList(prev => ({ ...prev, [id]: true }));
      setDownloadingId(null);
    }, 1200);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-black/75 backdrop-blur-md">
      <div className="relative w-full max-w-md bg-[#0F1A2E] border border-[#1F2A44] rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        {/* Top Header */}
        <div className="px-5 py-4 border-b border-[#1F2A44] flex items-center justify-between bg-[#081220]/60">
          <button
            type="button"
            onClick={onClose}
            className="flex items-center gap-1.5 text-[#B6C0D1] hover:text-[#F7F6F2] text-sm font-medium transition-colors"
          >
            <ChevronLeft className="w-5 h-5 text-[#F5D77A]" />
            <span>Back</span>
          </button>

          <h2 className="text-base font-semibold text-[#F7F6F2] font-serif-sacred tracking-wide">
            Translations
          </h2>

          <button
            type="button"
            onClick={onClose}
            className="w-8 h-8 rounded-lg flex items-center justify-center text-[#7A869A] hover:text-[#F7F6F2] hover:bg-[#111A2E] transition-colors"
            aria-label="Close"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Translation Cards List */}
        <div className="p-4 overflow-y-auto space-y-3">
          {TRANSLATIONS.length === 0 ? (
            <div className="p-6 rounded-2xl bg-[#081220] border border-[#1F2A44] text-center space-y-3">
              <div className="w-12 h-12 rounded-xl bg-[#0F1A2E] border border-[#D4AF37]/50 flex items-center justify-center text-[#F5D77A] mx-auto shadow-inner">
                <Cloud className="w-6 h-6 stroke-[1.8]" />
              </div>
              <div className="space-y-1">
                <h3 className="text-sm font-bold font-serif-sacred text-[#F7F6F2]">
                  No Bible translation installed.
                </h3>
                <p className="text-xs text-[#7A869A] leading-relaxed">
                  Add an authorized Bible translation to begin reading.
                </p>
              </div>
            </div>
          ) : (
            TRANSLATIONS.map((trans) => {
              const isSelected = selectedTranslation === trans.id;
              const isDownloaded = downloadedList[trans.id];
              const isBusy = downloadingId === trans.id;

              return (
                <div
                  key={trans.id}
                  onClick={() => onSelectTranslation(trans.id)}
                  className={`relative p-4 rounded-xl border cursor-pointer transition-all ${
                    isSelected
                      ? 'bg-[#111A2E] border-[#D4AF37] gold-glow-subtle'
                      : 'bg-[#0F1A2E] border-[#1F2A44] hover:border-[#2563EB]/60 hover:bg-[#111A2E]/70'
                  }`}
                >
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex items-start gap-3">
                      {/* Badge */}
                      <div
                        className={`w-11 h-11 rounded-lg border flex items-center justify-center font-serif-sacred font-bold text-xs uppercase tracking-wider ${
                          isSelected
                            ? 'border-[#D4AF37] text-[#F5D77A] bg-[#081220]'
                            : 'border-[#1F2A44] text-[#B6C0D1] bg-[#081220]'
                        }`}
                      >
                        {trans.code}
                      </div>

                      <div>
                        <div className="flex items-center gap-2">
                          <h3
                            className={`text-sm font-bold tracking-wide ${
                              isSelected ? 'text-[#F7F6F2]' : 'text-[#F7F6F2]'
                            }`}
                          >
                            {trans.name}
                          </h3>
                          {trans.isRTL && (
                            <span className="text-[10px] px-1.5 py-0.5 rounded bg-[#1E3A8A]/60 border border-[#2563EB]/40 text-[#00C6FF]">
                              RTL
                            </span>
                          )}
                        </div>
                        <p className="text-xs text-[#7A869A] mt-0.5 leading-relaxed">
                          {trans.description}
                        </p>

                        <div className="flex items-center gap-3 mt-2 text-[11px] text-[#B6C0D1]">
                          <span className="flex items-center gap-1 text-[#00C6FF]">
                            <ShieldCheck className="w-3.5 h-3.5" />
                            <span>Verified Text</span>
                          </span>
                          <span>•</span>
                          <span className="text-[#7A869A]">{trans.language}</span>
                        </div>
                      </div>
                    </div>

                    {/* Right Action / Selection indicator */}
                    <div className="flex items-center gap-2 flex-shrink-0 mt-1">
                      {/* Offline indicator / button */}
                      <button
                        type="button"
                        onClick={(e) => handleDownload(trans.id, e)}
                        title={isDownloaded ? "Available Offline" : "Download for offline reading"}
                        className={`p-1.5 rounded-lg border text-xs transition-colors ${
                          isDownloaded
                            ? 'text-[#00C6FF] border-[#2563EB]/40 bg-[#081220]'
                            : 'text-[#7A869A] border-[#1F2A44] hover:text-[#00C6FF]'
                        }`}
                      >
                        {isBusy ? (
                          <div className="w-4 h-4 border-2 border-[#00C6FF] border-t-transparent rounded-full animate-spin" />
                        ) : isDownloaded ? (
                          <Cloud className="w-4 h-4 text-[#00C6FF]" />
                        ) : (
                          <Download className="w-4 h-4" />
                        )}
                      </button>

                      {/* Radio selection checkmark */}
                      <div
                        className={`w-6 h-6 rounded-full border flex items-center justify-center transition-all ${
                          isSelected
                            ? 'border-[#D4AF37] bg-[#D4AF37] text-[#081220]'
                            : 'border-[#1F2A44] bg-transparent text-transparent'
                        }`}
                      >
                        <Check className="w-3.5 h-3.5 stroke-[3]" />
                      </div>
                    </div>
                  </div>
                </div>
              );
            })
          )}

          {/* Add More Translations Button */}
          {onOpenFullImport && (
            <button
              type="button"
              onClick={() => {
                onClose();
                onOpenFullImport();
              }}
              className="w-full py-3 px-4 rounded-xl border border-[#D4AF37]/50 bg-[#D4AF37]/10 hover:bg-[#D4AF37]/20 text-xs font-bold text-[#F5D77A] flex items-center justify-center gap-2 transition-all active:scale-[0.99]"
            >
              <Database className="w-4 h-4 text-[#F5D77A]" />
              <span>Full کِتابِ مُقادّس Importer (Bible.com 189)</span>
            </button>
          )}

          <button
            type="button"
            onClick={() => setShowAddMoreNotice(!showAddMoreNotice)}
            className="w-full py-3 px-4 rounded-xl border border-dashed border-[#1F2A44] hover:border-[#00C6FF]/60 hover:bg-[#111A2E] text-xs font-medium text-[#00C6FF] flex items-center justify-center gap-2 transition-all active:scale-[0.99]"
          >
            <Plus className="w-4 h-4" />
            <span>Add More Translations</span>
          </button>

          {showAddMoreNotice && (
            <div className="p-3 rounded-xl bg-[#081220] border border-[#1F2A44] text-xs text-[#B6C0D1] leading-relaxed animate-in fade-in">
              <span className="font-semibold text-[#F5D77A]">Additional Languages Coming:</span> WordOra adheres strictly to authentic, legally authorized Scripture editions. Upcoming verified modules include Punjabi Bible (Gurmukhi & Shahmukhi), Arabic Van Dyck, and Spanish Reina-Valera.
            </div>
          )}

          {/* Offline Information Card */}
          <div className="p-3.5 rounded-xl bg-[#081220]/80 border border-[#1F2A44] flex items-center gap-3">
            <div className="w-9 h-9 rounded-lg bg-[#1E3A8A]/30 border border-[#2563EB]/40 flex items-center justify-center text-[#00C6FF] flex-shrink-0">
              <Cloud className="w-5 h-5" />
            </div>
            <div>
              <h4 className="text-xs font-semibold text-[#F7F6F2]">
                Offline Scripture Access
              </h4>
              <p className="text-[11px] text-[#7A869A] mt-0.5">
                All selected translations are stored locally for fast, distraction-free reading without internet.
              </p>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="p-3 border-t border-[#1F2A44] bg-[#081220] flex justify-end">
          <button
            type="button"
            onClick={onClose}
            className="px-5 py-2 rounded-xl bg-gradient-to-r from-[#D4AF37] to-[#F5D77A] text-[#081220] font-semibold text-xs tracking-wider uppercase hover:opacity-95 active:scale-95 transition-all shadow-md"
          >
            Done
          </button>
        </div>
      </div>
    </div>
  );
};
