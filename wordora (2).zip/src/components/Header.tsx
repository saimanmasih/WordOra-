import React from 'react';
import { Menu, Bell, User } from 'lucide-react';
import { WordOraLogo } from './WordOraLogo';

interface HeaderProps {
  onOpenMenu: () => void;
  onOpenNotifications: () => void;
  onOpenProfile: () => void;
  onLogoClick: () => void;
  reminderActive?: boolean;
}

export const Header: React.FC<HeaderProps> = ({
  onOpenMenu,
  onOpenNotifications,
  onOpenProfile,
  onLogoClick,
  reminderActive = true,
}) => {
  return (
    <header className="sticky top-0 z-40 bg-[#081220]/95 backdrop-blur-md border-b border-[#1F2A44] px-4 py-2.5 flex items-center justify-between transition-colors">
      {/* LEFT: Menu icon */}
      <button
        type="button"
        onClick={onOpenMenu}
        className="w-11 h-11 flex items-center justify-center rounded-xl text-[#F5D77A] hover:bg-[#0F1A2E] hover:text-[#FFF4D0] active:scale-95 transition-all"
        aria-label="Open Navigation Menu"
      >
        <Menu className="w-6 h-6 stroke-[2.2]" />
      </button>

      {/* CENTER: Official WordOra logo / wordmark */}
      <div className="flex-1 flex items-center justify-center">
        <WordOraLogo variant="header" onClick={onLogoClick} />
      </div>

      {/* RIGHT: Prayer notification bell & User profile */}
      <div className="flex items-center gap-1">
        <button
          type="button"
          onClick={onOpenNotifications}
          className="relative w-11 h-11 flex items-center justify-center rounded-xl text-[#F5D77A] hover:bg-[#0F1A2E] hover:text-[#FFF4D0] active:scale-95 transition-all"
          aria-label="Prayer Reminders and Notifications"
        >
          <Bell className="w-5 h-5 stroke-[2.2]" />
          {reminderActive && (
            <span className="absolute top-2.5 right-2.5 w-2 h-2 rounded-full bg-[#00C6FF] cyan-glow" />
          )}
        </button>

        <button
          type="button"
          onClick={onOpenProfile}
          className="w-11 h-11 flex items-center justify-center rounded-xl text-[#B6C0D1] hover:bg-[#0F1A2E] hover:text-[#F7F6F2] active:scale-95 transition-all"
          aria-label="User Profile"
        >
          <div className="w-7 h-7 rounded-full bg-gradient-to-tr from-[#1E3A8A] to-[#D4AF37]/50 border border-[#D4AF37]/60 flex items-center justify-center text-xs font-semibold text-[#F7F6F2] shadow-sm">
            <User className="w-4 h-4 text-[#F7F6F2]" />
          </div>
        </button>
      </div>
    </header>
  );
};
