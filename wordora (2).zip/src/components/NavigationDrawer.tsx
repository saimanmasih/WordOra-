import React from 'react';
import {
  X,
  Home,
  BookOpen,
  Music,
  Search,
  Bookmark,
  Bot,
  Globe,
  Settings,
  Info,
  ChevronRight,
  Shield,
  Heart,
  Database,
} from 'lucide-react';
import { WordOraLogo } from './WordOraLogo';
import { NavTab } from './BottomNavigation';

interface NavigationDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectTab: (tab: NavTab) => void;
  onOpenTranslations: () => void;
  onOpenAbout: () => void;
  onOpenPrayer: () => void;
  onOpenFullImport: () => void;
}

export const NavigationDrawer: React.FC<NavigationDrawerProps> = ({
  isOpen,
  onClose,
  onSelectTab,
  onOpenTranslations,
  onOpenAbout,
  onOpenPrayer,
  onOpenFullImport,
}) => {
  if (!isOpen) return null;

  const handleNav = (tab: NavTab) => {
    onSelectTab(tab);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex bg-black/75 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="w-4/5 max-w-xs h-full bg-[#081220] border-r border-[#1F2A44] flex flex-col justify-between overflow-y-auto shadow-2xl animate-in slide-in-from-left duration-200">
        <div>
          {/* Top Brand Header */}
          <div className="p-5 border-b border-[#1F2A44] flex items-center justify-between bg-[#0F1A2E]/60">
            <WordOraLogo variant="compact" showTagline={false} />
            <button
              type="button"
              onClick={onClose}
              className="p-1.5 rounded-lg text-[#7A869A] hover:text-[#F7F6F2] hover:bg-[#1F2A44]"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Mission Tagline Banner */}
          <div className="px-5 py-3 bg-[#111A2E]/50 border-b border-[#1F2A44]">
            <p className="text-[10px] uppercase tracking-[0.2em] text-[#D4AF37] font-semibold">
              ONE WORD. EVERY NATION.
            </p>
            <p className="text-[11px] text-[#7A869A] mt-0.5">
              Faithful Scripture for Urdu, Roman Urdu & English speakers.
            </p>
          </div>

          {/* Navigation Links */}
          <div className="p-3 space-y-1">
            <button
              type="button"
              onClick={() => handleNav('home')}
              className="w-full px-3 py-2.5 rounded-xl flex items-center justify-between text-xs font-semibold text-[#F7F6F2] hover:bg-[#0F1A2E] hover:text-[#00C6FF] transition-colors"
            >
              <div className="flex items-center gap-3">
                <Home className="w-4 h-4 text-[#F5D77A]" />
                <span>Home</span>
              </div>
              <ChevronRight className="w-4 h-4 text-[#7A869A]" />
            </button>

            <button
              type="button"
              onClick={() => handleNav('bible')}
              className="w-full px-3 py-2.5 rounded-xl flex items-center justify-between text-xs font-semibold text-[#F7F6F2] hover:bg-[#0F1A2E] hover:text-[#00C6FF] transition-colors"
            >
              <div className="flex items-center gap-3">
                <BookOpen className="w-4 h-4 text-[#00C6FF]" />
                <span>Holy Bible</span>
              </div>
              <ChevronRight className="w-4 h-4 text-[#7A869A]" />
            </button>

            <button
              type="button"
              onClick={() => handleNav('worship')}
              className="w-full px-3 py-2.5 rounded-xl flex items-center justify-between text-xs font-semibold text-[#F7F6F2] hover:bg-[#0F1A2E] hover:text-[#00C6FF] transition-colors"
            >
              <div className="flex items-center gap-3">
                <Music className="w-4 h-4 text-[#F5D77A]" />
                <span>Worship, Geet & Zaboor</span>
              </div>
              <ChevronRight className="w-4 h-4 text-[#7A869A]" />
            </button>

            <button
              type="button"
              onClick={() => {
                onOpenPrayer();
                onClose();
              }}
              className="w-full px-3 py-2.5 rounded-xl flex items-center justify-between text-xs font-semibold text-[#F7F6F2] hover:bg-[#0F1A2E] hover:text-[#00C6FF] transition-colors"
            >
              <div className="flex items-center gap-3">
                <span className="text-base">🙏</span>
                <span>Prayer Petitions</span>
              </div>
              <ChevronRight className="w-4 h-4 text-[#7A869A]" />
            </button>

            <button
              type="button"
              onClick={() => handleNav('search')}
              className="w-full px-3 py-2.5 rounded-xl flex items-center justify-between text-xs font-semibold text-[#F7F6F2] hover:bg-[#0F1A2E] hover:text-[#00C6FF] transition-colors"
            >
              <div className="flex items-center gap-3">
                <Search className="w-4 h-4 text-[#00C6FF]" />
                <span>Search Scripture</span>
              </div>
              <ChevronRight className="w-4 h-4 text-[#7A869A]" />
            </button>

            <button
              type="button"
              onClick={() => handleNav('saved')}
              className="w-full px-3 py-2.5 rounded-xl flex items-center justify-between text-xs font-semibold text-[#F7F6F2] hover:bg-[#0F1A2E] hover:text-[#00C6FF] transition-colors"
            >
              <div className="flex items-center gap-3">
                <Bookmark className="w-4 h-4 text-[#F5D77A]" />
                <span>Saved (Bookmarks & Notes)</span>
              </div>
              <ChevronRight className="w-4 h-4 text-[#7A869A]" />
            </button>

            <button
              type="button"
              onClick={() => handleNav('ai')}
              className="w-full px-3 py-2.5 rounded-xl flex items-center justify-between text-xs font-semibold text-[#00C6FF] bg-[#1E3A8A]/20 border border-[#2563EB]/40 hover:bg-[#1E3A8A]/40 transition-colors"
            >
              <div className="flex items-center gap-3">
                <Bot className="w-4 h-4 text-[#00C6FF]" />
                <span>AI Bible Assistant</span>
              </div>
              <ChevronRight className="w-4 h-4 text-[#00C6FF]" />
            </button>
          </div>

          <div className="px-4 py-2 border-t border-[#1F2A44] my-2 space-y-1">
            <button
              type="button"
              onClick={() => {
                onOpenTranslations();
                onClose();
              }}
              className="w-full px-3 py-2.5 rounded-xl flex items-center justify-between text-xs text-[#B6C0D1] hover:text-[#F7F6F2] hover:bg-[#0F1A2E] transition-colors"
            >
              <div className="flex items-center gap-3">
                <Globe className="w-4 h-4 text-[#00C6FF]" />
                <span>Translations</span>
              </div>
              <span className="text-[10px] text-[#D4AF37] font-semibold">KJV • RU • UR</span>
            </button>

            <button
              type="button"
              onClick={() => {
                onOpenFullImport();
                onClose();
              }}
              className="w-full px-3 py-2.5 rounded-xl flex items-center justify-between text-xs font-semibold text-[#F5D77A] bg-[#D4AF37]/10 border border-[#D4AF37]/30 hover:bg-[#D4AF37]/20 transition-colors"
            >
              <div className="flex items-center gap-3">
                <Database className="w-4 h-4 text-[#F5D77A]" />
                <div className="text-left">
                  <span className="block leading-none">Full کِتابِ مُقادّس Importer</span>
                  <span className="text-[10px] text-[#7A869A]">66 Books • Version 189</span>
                </div>
              </div>
              <ChevronRight className="w-4 h-4 text-[#D4AF37]" />
            </button>

            <button
              type="button"
              onClick={() => {
                onOpenAbout();
                onClose();
              }}
              className="w-full px-3 py-2.5 rounded-xl flex items-center justify-between text-xs text-[#B6C0D1] hover:text-[#F7F6F2] hover:bg-[#0F1A2E] transition-colors"
            >
              <div className="flex items-center gap-3">
                <Info className="w-4 h-4 text-[#F5D77A]" />
                <span>About WordOra</span>
              </div>
              <ChevronRight className="w-4 h-4 text-[#7A869A]" />
            </button>
          </div>
        </div>

        {/* Footer Brand Verification */}
        <div className="p-4 border-t border-[#1F2A44] bg-[#0F1A2E]/50">
          <div className="flex items-center gap-2 text-[11px] text-[#B6C0D1]">
            <Shield className="w-3.5 h-3.5 text-[#00C6FF]" />
            <span>Scripture Integrity Guaranteed</span>
          </div>
          <p className="text-[10px] text-[#7A869A] mt-1 font-mono">
            WordOra v2.4 • Sacred Modern
          </p>
        </div>
      </div>

      <div className="flex-1" onClick={onClose} />
    </div>
  );
};
