import React, { useState, useEffect } from 'react';
import {
  X,
  Database,
  CheckCircle2,
  AlertCircle,
  PauseCircle,
  Play,
  ShieldCheck,
  RotateCw,
  BookOpen,
  Sparkles,
} from 'lucide-react';

interface FullBibleImportModalProps {
  isOpen: boolean;
  onClose: () => void;
  onImportComplete?: () => void;
}

interface ImportStatusResponse {
  status: 'idle' | 'in_progress' | 'paused' | 'verifying' | 'completed' | 'error';
  totalChapters: number;
  completedChapters: number;
  currentBook: string;
  currentChapter: number;
  totalVerses: number;
  preservedGenesis1To4: boolean;
  errors: string[];
  isActive: boolean;
  updatedAt?: string;
}

export const FullBibleImportModal: React.FC<FullBibleImportModalProps> = ({
  isOpen,
  onClose,
  onImportComplete,
}) => {
  const [status, setStatus] = useState<ImportStatusResponse | null>(null);
  const [isTriggering, setIsTriggering] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const fetchStatus = async () => {
    try {
      const res = await fetch('/api/importer/status');
      if (res.ok) {
        const data: ImportStatusResponse = await res.json();
        setStatus(data);
        if (data.status === 'completed' && onImportComplete) {
          onImportComplete();
        }
      }
    } catch (e: any) {
      console.warn('Could not poll importer status', e);
    }
  };

  useEffect(() => {
    if (!isOpen) return;
    fetchStatus();

    const interval = setInterval(() => {
      fetchStatus();
    }, 2000);

    return () => clearInterval(interval);
  }, [isOpen]);

  if (!isOpen) return null;

  const handleStart = async () => {
    setIsTriggering(true);
    setErrorMsg(null);
    try {
      const res = await fetch('/api/importer/start', { method: 'POST' });
      const data = await res.json();
      if (data.progress) {
        setStatus(data.progress);
      }
    } catch (e: any) {
      setErrorMsg(e.message || 'Failed to start importer');
    } finally {
      setIsTriggering(false);
    }
  };

  const handleStop = async () => {
    setIsTriggering(true);
    try {
      const res = await fetch('/api/importer/stop', { method: 'POST' });
      const data = await res.json();
      if (data.progress) {
        setStatus(data.progress);
      }
    } catch (e: any) {
      setErrorMsg(e.message || 'Failed to stop importer');
    } finally {
      setIsTriggering(false);
    }
  };

  const percent = status
    ? Math.min(100, Math.round((status.completedChapters / (status.totalChapters || 1189)) * 100))
    : 0;

  const isRunning = status?.isActive || status?.status === 'in_progress' || status?.status === 'verifying';
  const isDone = status?.status === 'completed';

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-black/80 backdrop-blur-md">
      <div className="relative w-full max-w-lg bg-[#0F1A2E] border border-[#1F2A44] rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[92vh]">
        {/* Header */}
        <div className="px-5 py-4 border-b border-[#1F2A44] flex items-center justify-between bg-[#081220]/75">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-[#1E3A8A]/30 border border-[#2563EB]/50 flex items-center justify-center text-[#00C6FF]">
              <Database className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-sm font-bold font-serif-sacred text-[#F7F6F2] tracking-wide">
                کِتابِ مُقادّس Full Bible Importer
              </h2>
              <span className="text-[10px] text-[#D4AF37] block font-mono">
                Bible.com Version 189 • 66 Books • 1,189 Chapters
              </span>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="w-8 h-8 rounded-lg flex items-center justify-center text-[#7A869A] hover:text-[#F7F6F2] hover:bg-[#111A2E] transition-colors"
            aria-label="Close"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body */}
        <div className="p-5 overflow-y-auto space-y-4">
          {/* Verified Full Bible Lock Banner */}
          <div className="p-3.5 rounded-xl bg-[#081220] border border-[#D4AF37]/50 flex items-start gap-3 shadow-inner">
            <ShieldCheck className="w-5 h-5 text-[#F5D77A] flex-shrink-0 mt-0.5" />
            <div className="space-y-0.5 text-xs">
              <span className="font-bold text-[#F5D77A] block font-serif-sacred tracking-wide">
                Authoritative Bible Dataset — Permanently Locked & Verified
              </span>
              <p className="text-[11px] text-[#B6C0D1] leading-relaxed">
                All 66 books, 1,189 chapters, and 31,103 verses of کِتابِ مُقادّس (Urdu Version 189) are permanently locked against modifications, overwrites, and automated edits. Scripture text is immutable and read-only.
              </p>
            </div>
          </div>

          {/* Progress Card */}
          <div className="p-4 rounded-xl bg-[#081220] border border-[#1F2A44] space-y-3">
            <div className="flex items-center justify-between">
              <div>
                <span className="text-xs font-semibold text-[#F7F6F2] block">
                  {status?.status === 'verifying'
                    ? 'Verifying Database Integrity...'
                    : status?.status === 'completed'
                    ? 'Full Bible Installed & Committed'
                    : isRunning
                    ? `Importing ${status?.currentBook} Chapter ${status?.currentChapter}...`
                    : 'Ready to Import Full کِتابِ مُقادّس'}
                </span>
                <span className="text-[11px] text-[#7A869A]">
                  {status
                    ? `${status.completedChapters} of ${status.totalChapters} chapters (${status.totalVerses.toLocaleString()} verses)`
                    : 'Awaiting status...'}
                </span>
              </div>
              <span className="text-sm font-bold font-mono text-[#F5D77A]">{percent}%</span>
            </div>

            {/* Progress Bar */}
            <div className="w-full h-2.5 rounded-full bg-[#111A2E] overflow-hidden border border-[#1F2A44]">
              <div
                className={`h-full transition-all duration-300 ${
                  isDone
                    ? 'bg-emerald-500'
                    : isRunning
                    ? 'bg-gradient-to-r from-[#D4AF37] via-[#00C6FF] to-[#D4AF37] animate-pulse'
                    : 'bg-[#D4AF37]'
                }`}
                style={{ width: `${percent}%` }}
              />
            </div>

            {/* Sub-status badges */}
            <div className="flex items-center justify-between text-[11px] text-[#7A869A] pt-1">
              <div className="flex items-center gap-1.5">
                <span
                  className={`w-2 h-2 rounded-full ${
                    isRunning ? 'bg-emerald-400 animate-ping' : isDone ? 'bg-emerald-500' : 'bg-gray-500'
                  }`}
                />
                <span className="capitalize">{status?.status || 'idle'}</span>
              </div>
              <span>Bible.com URD / 189</span>
            </div>
          </div>

          {/* Error messages if any */}
          {errorMsg && (
            <div className="p-3 rounded-xl bg-rose-500/10 border border-rose-500/40 text-rose-300 text-xs flex items-center gap-2">
              <AlertCircle className="w-4 h-4 flex-shrink-0" />
              <span>{errorMsg}</span>
            </div>
          )}

          {status?.errors && status.errors.length > 0 && (
            <div className="p-3 rounded-xl bg-amber-500/10 border border-amber-500/40 text-amber-200 text-xs space-y-1">
              <div className="font-semibold flex items-center gap-1">
                <AlertCircle className="w-3.5 h-3.5" />
                <span>Notice during import:</span>
              </div>
              <p className="text-[11px] text-amber-300/80 max-h-24 overflow-y-auto">
                {status.errors.slice(-3).join(' • ')}
              </p>
            </div>
          )}

          {/* Details & Specs */}
          <div className="grid grid-cols-2 gap-2 text-xs">
            <div className="p-3 rounded-xl bg-[#081220] border border-[#1F2A44]">
              <span className="text-[10px] text-[#7A869A] uppercase tracking-wider block">Scope</span>
              <span className="font-semibold text-[#F7F6F2]">66 Books (OT & NT)</span>
            </div>
            <div className="p-3 rounded-xl bg-[#081220] border border-[#1F2A44]">
              <span className="text-[10px] text-[#7A869A] uppercase tracking-wider block">Target Chapters</span>
              <span className="font-semibold text-[#F7F6F2]">1,189 Chapters</span>
            </div>
          </div>
        </div>

        {/* Footer Actions */}
        <div className="p-4 border-t border-[#1F2A44] bg-[#081220] flex items-center justify-between">
          <button
            type="button"
            onClick={fetchStatus}
            className="p-2 rounded-xl text-[#7A869A] hover:text-[#F7F6F2] hover:bg-[#111A2E] transition-colors"
            title="Refresh Status"
          >
            <RotateCw className="w-4 h-4" />
          </button>

          <div className="flex items-center gap-2">
            {isRunning ? (
              <button
                type="button"
                onClick={handleStop}
                disabled={isTriggering}
                className="px-4 py-2 rounded-xl bg-[#1E293B] border border-[#334155] text-amber-300 font-semibold text-xs flex items-center gap-1.5 hover:bg-[#334155] transition-all"
              >
                <PauseCircle className="w-4 h-4" />
                <span>Pause Import</span>
              </button>
            ) : (
              <button
                type="button"
                onClick={handleStart}
                disabled={isTriggering || isDone}
                className={`px-5 py-2 rounded-xl font-bold text-xs uppercase tracking-wider flex items-center gap-2 shadow-lg transition-all active:scale-95 ${
                  isDone
                    ? 'bg-emerald-600 text-white cursor-default'
                    : 'bg-gradient-to-r from-[#D4AF37] to-[#F5D77A] text-[#081220] hover:opacity-95'
                }`}
              >
                {isDone ? (
                  <>
                    <ShieldCheck className="w-4 h-4 text-emerald-300" />
                    <span>Locked & Immutable</span>
                  </>
                ) : (
                  <>
                    <Play className="w-4 h-4 fill-current" />
                    <span>{status?.completedChapters && status.completedChapters > 4 ? 'Resume Import' : '1-Click Full Import'}</span>
                  </>
                )}
              </button>
            )}

            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-xl bg-[#0F1A2E] border border-[#1F2A44] text-[#B6C0D1] hover:text-[#F7F6F2] text-xs font-semibold"
            >
              Close
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
