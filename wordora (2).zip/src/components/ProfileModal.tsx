import React from 'react';
import { X, User, Flame, BookOpen, Heart, Bell, CheckCircle2, Shield } from 'lucide-react';
import { TranslationId } from '../types';
import { TRANSLATIONS } from '../data/bibleData';

interface ProfileModalProps {
  isOpen: boolean;
  onClose: () => void;
  selectedTranslation: TranslationId;
  onSelectTranslation: (id: TranslationId) => void;
  prayerReminderEnabled: boolean;
  onTogglePrayerReminder: () => void;
  savedCount: number;
  prayerCount: number;
}

export const ProfileModal: React.FC<ProfileModalProps> = ({
  isOpen,
  onClose,
  selectedTranslation,
  onSelectTranslation,
  prayerReminderEnabled,
  onTogglePrayerReminder,
  savedCount,
  prayerCount,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-black/80 backdrop-blur-md">
      <div className="relative w-full max-w-sm bg-[#0F1A2E] border border-[#1F2A44] rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="px-5 py-3.5 border-b border-[#1F2A44] flex items-center justify-between bg-[#081220]/70">
          <span className="text-xs font-bold uppercase tracking-wider text-[#F5D77A]">
            User Profile
          </span>
          <button
            type="button"
            onClick={onClose}
            className="p-1 rounded-lg text-[#7A869A] hover:text-[#F7F6F2]"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-5 overflow-y-auto space-y-4">
          {/* Avatar & Name */}
          <div className="flex items-center gap-3.5 pb-2 border-b border-[#1F2A44]/60">
            <div className="w-14 h-14 rounded-full bg-gradient-to-tr from-[#1E3A8A] to-[#D4AF37]/50 border-2 border-[#D4AF37] flex items-center justify-center text-xl text-[#F7F6F2] shadow-lg">
              ✝
            </div>
            <div>
              <h3 className="text-sm font-bold text-[#F7F6F2]">
                WordOra Disciple
              </h3>
              <p className="text-xs text-[#00C6FF]">
                Daily Devotee • Premium Member
              </p>
            </div>
          </div>

          {/* Stats Bento */}
          <div className="grid grid-cols-3 gap-2 text-center">
            <div className="p-3 rounded-xl bg-[#081220] border border-[#1F2A44]">
              <Flame className="w-4 h-4 text-[#D4AF37] mx-auto mb-1" />
              <div className="text-sm font-bold text-[#F7F6F2]">14</div>
              <div className="text-[10px] text-[#7A869A]">Day Streak</div>
            </div>

            <div className="p-3 rounded-xl bg-[#081220] border border-[#1F2A44]">
              <BookOpen className="w-4 h-4 text-[#00C6FF] mx-auto mb-1" />
              <div className="text-sm font-bold text-[#F7F6F2]">{savedCount}</div>
              <div className="text-[10px] text-[#7A869A]">Saved Verses</div>
            </div>

            <div className="p-3 rounded-xl bg-[#081220] border border-[#1F2A44]">
              <Heart className="w-4 h-4 text-rose-400 mx-auto mb-1" />
              <div className="text-sm font-bold text-[#F7F6F2]">{prayerCount}</div>
              <div className="text-[10px] text-[#7A869A]">Prayers</div>
            </div>
          </div>

          {/* Settings Section */}
          <div className="space-y-2 pt-2">
            <span className="text-xs font-bold uppercase tracking-wider text-[#7A869A]">
              Preferences
            </span>

            {/* Default Translation */}
            <div className="p-3 rounded-xl bg-[#081220] border border-[#1F2A44] flex items-center justify-between">
              <span className="text-xs text-[#B6C0D1]">Primary Translation</span>
              <select
                value={selectedTranslation}
                onChange={(e) => onSelectTranslation(e.target.value as TranslationId)}
                className="bg-[#0F1A2E] border border-[#1F2A44] text-xs font-bold text-[#F5D77A] rounded-lg px-2 py-1 uppercase"
              >
                {TRANSLATIONS.length === 0 ? (
                  <option value="">None</option>
                ) : (
                  TRANSLATIONS.map((t) => (
                    <option key={t.id} value={t.id}>
                      {t.name}
                    </option>
                  ))
                )}
              </select>
            </div>

            {/* Daily Prayer Bell */}
            <div className="p-3 rounded-xl bg-[#081220] border border-[#1F2A44] flex items-center justify-between">
              <div>
                <span className="text-xs text-[#B6C0D1] block">Daily Prayer Bell</span>
                <span className="text-[10px] text-[#7A869A]">7:00 AM Morning Prayer</span>
              </div>
              <button
                type="button"
                onClick={onTogglePrayerReminder}
                className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
                  prayerReminderEnabled ? 'bg-[#00C6FF]' : 'bg-[#1F2A44]'
                }`}
              >
                <span
                  className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                    prayerReminderEnabled ? 'translate-x-6' : 'translate-x-1'
                  }`}
                />
              </button>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="p-3 border-t border-[#1F2A44] bg-[#081220] flex justify-end">
          <button
            type="button"
            onClick={onClose}
            className="px-5 py-2 rounded-xl bg-[#D4AF37] text-[#081220] font-bold text-xs uppercase tracking-wider"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
