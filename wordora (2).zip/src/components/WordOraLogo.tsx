import React from 'react';

interface WordOraLogoProps {
  variant?: 'hero' | 'header' | 'icon' | 'compact';
  showTagline?: boolean;
  className?: string;
  onClick?: () => void;
}

export const WordOraLogo: React.FC<WordOraLogoProps> = ({
  variant = 'header',
  showTagline = true,
  className = '',
  onClick,
}) => {
  // Master Vector Emblem of the Official WordOra Logo:
  // Features:
  // 1. Celestial Dark Navy Sphere / Globe with longitude-latitude lines
  // 2. Glowing Blue Earth Globe
  // 3. Radiant Christian Cross with central golden flare & sunbeams
  // 4. Open Holy Bible resting at cross base with golden pages
  // 5. White Dove of the Holy Spirit soaring upward with holy light
  const emblem = (size: number) => (
    <div
      style={{ width: size, height: size }}
      className="relative flex-shrink-0 select-none flex items-center justify-center rounded-full"
    >
      <svg
        viewBox="0 0 240 240"
        className="w-full h-full drop-shadow-[0_0_15px_rgba(0,198,255,0.35)]"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
      >
        <defs>
          {/* Radial celestial space gradient */}
          <radialGradient id="globeSpace" cx="50%" cy="50%" r="50%">
            <stop offset="0%" stopColor="#1E3A8A" stopOpacity="0.9" />
            <stop offset="60%" stopColor="#0F1A2E" stopOpacity="0.95" />
            <stop offset="100%" stopColor="#081220" stopOpacity="1" />
          </radialGradient>

          {/* Cyan atmosphere aura */}
          <radialGradient id="atmosphereGlow" cx="50%" cy="50%" r="50%">
            <stop offset="70%" stopColor="#00C6FF" stopOpacity="0" />
            <stop offset="95%" stopColor="#00C6FF" stopOpacity="0.65" />
            <stop offset="100%" stopColor="#2563EB" stopOpacity="0.9" />
          </radialGradient>

          {/* Gold cross metallic gradient */}
          <linearGradient id="goldCrossGrad" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#FFF9E6" />
            <stop offset="25%" stopColor="#F5D77A" />
            <stop offset="60%" stopColor="#D4AF37" />
            <stop offset="90%" stopColor="#AA820A" />
            <stop offset="100%" stopColor="#785900" />
          </linearGradient>

          {/* Holy Cross flare glow */}
          <radialGradient id="crossFlare" cx="50%" cy="50%" r="50%">
            <stop offset="0%" stopColor="#FFFFFF" stopOpacity="1" />
            <stop offset="20%" stopColor="#FFF3B0" stopOpacity="0.95" />
            <stop offset="50%" stopColor="#D4AF37" stopOpacity="0.5" />
            <stop offset="100%" stopColor="#D4AF37" stopOpacity="0" />
          </radialGradient>

          {/* Open Bible gold pages */}
          <linearGradient id="biblePagesGrad" x1="0%" y1="0%" x2="0%" y2="100%">
            <stop offset="0%" stopColor="#FFFFFF" />
            <stop offset="40%" stopColor="#FFF4D0" />
            <stop offset="85%" stopColor="#F5D77A" />
            <stop offset="100%" stopColor="#D4AF37" />
          </linearGradient>

          {/* Bible cover leather navy/gold */}
          <linearGradient id="bibleCoverGrad" x1="0%" y1="0%" x2="100%" y2="0%">
            <stop offset="0%" stopColor="#0A1628" />
            <stop offset="50%" stopColor="#1E3A8A" />
            <stop offset="100%" stopColor="#0A1628" />
          </linearGradient>

          {/* White dove feathers gradient */}
          <linearGradient id="doveGrad" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#FFFFFF" />
            <stop offset="50%" stopColor="#F0F8FF" />
            <stop offset="100%" stopColor="#C9E6FF" />
          </linearGradient>
        </defs>

        {/* Outer Circular Ring (Gold + Cyan rim) */}
        <circle cx="120" cy="120" r="115" stroke="url(#goldCrossGrad)" strokeWidth="3" opacity="0.9" />
        <circle cx="120" cy="120" r="111" stroke="#00C6FF" strokeWidth="1.5" opacity="0.6" />

        {/* Celestial Globe Background */}
        <circle cx="120" cy="120" r="109" fill="url(#globeSpace)" />
        <circle cx="120" cy="120" r="109" fill="url(#atmosphereGlow)" />

        {/* Globe Grid Lines (Latitudes / Longitudes) */}
        <ellipse cx="120" cy="120" rx="100" ry="40" stroke="#00C6FF" strokeWidth="0.8" opacity="0.3" />
        <ellipse cx="120" cy="120" rx="100" ry="75" stroke="#00C6FF" strokeWidth="0.8" opacity="0.25" />
        <line x1="20" y1="120" x2="220" y2="120" stroke="#00C6FF" strokeWidth="1" opacity="0.35" />
        <ellipse cx="120" cy="120" rx="42" ry="105" stroke="#00C6FF" strokeWidth="0.8" opacity="0.3" />
        <ellipse cx="120" cy="120" rx="80" ry="105" stroke="#00C6FF" strokeWidth="0.8" opacity="0.25" />

        {/* Continents silhouette stylized */}
        <path
          d="M60 85 Q75 70 95 80 Q105 95 90 115 Q70 120 60 85 Z M145 70 Q170 65 185 85 Q180 110 160 115 Q140 100 145 70 Z M130 135 Q155 145 150 170 Q130 180 120 160 Z"
          fill="#1E3A8A"
          opacity="0.5"
        />

        {/* Radiance Rays from Holy Cross */}
        <g opacity="0.5">
          <line x1="120" y1="75" x2="120" y2="15" stroke="url(#goldCrossGrad)" strokeWidth="2.5" strokeDasharray="3 4" />
          <line x1="120" y1="75" x2="60" y2="35" stroke="url(#goldCrossGrad)" strokeWidth="1.5" strokeDasharray="3 4" />
          <line x1="120" y1="75" x2="180" y2="35" stroke="url(#goldCrossGrad)" strokeWidth="1.5" strokeDasharray="3 4" />
          <line x1="120" y1="75" x2="40" y2="75" stroke="url(#goldCrossGrad)" strokeWidth="2" strokeDasharray="3 4" />
          <line x1="120" y1="75" x2="200" y2="75" stroke="url(#goldCrossGrad)" strokeWidth="2" strokeDasharray="3 4" />
        </g>

        {/* LARGE CHRISTIAN CROSS */}
        {/* Cross Vertical Beam */}
        <path
          d="M112 30 L128 30 L128 155 L112 155 Z"
          fill="url(#goldCrossGrad)"
          stroke="#FFF9E6"
          strokeWidth="1"
        />
        {/* Cross Horizontal Beam */}
        <path
          d="M72 65 L168 65 L168 81 L72 81 Z"
          fill="url(#goldCrossGrad)"
          stroke="#FFF9E6"
          strokeWidth="1"
        />
        {/* Cross Bevel 3D Highlights */}
        <line x1="120" y1="30" x2="120" y2="155" stroke="#FFFFFF" strokeWidth="1.5" opacity="0.75" />
        <line x1="72" y1="73" x2="168" y2="73" stroke="#FFFFFF" strokeWidth="1.5" opacity="0.75" />

        {/* Radiant Center Cross Flare */}
        <circle cx="120" cy="73" r="28" fill="url(#crossFlare)" />
        {/* 4-point star burst at intersection */}
        <path
          d="M120 48 Q120 73 145 73 Q120 73 120 98 Q120 73 95 73 Q120 73 120 48 Z"
          fill="#FFFFFF"
          opacity="0.9"
        />

        {/* OPEN HOLY BIBLE (at the base of the cross) */}
        {/* Open Bible Outer / Cover */}
        <path
          d="M50 188 Q85 174 120 182 Q155 174 190 188 L185 204 Q153 190 120 197 Q87 190 55 204 Z"
          fill="url(#bibleCoverGrad)"
          stroke="#D4AF37"
          strokeWidth="1.5"
        />
        {/* Bible Left Pages */}
        <path
          d="M52 186 Q86 172 119 178 L119 194 Q86 188 54 200 Z"
          fill="url(#biblePagesGrad)"
          stroke="#FFF4D0"
          strokeWidth="0.8"
        />
        {/* Bible Right Pages */}
        <path
          d="M121 178 Q154 172 188 186 L186 200 Q154 188 121 194 Z"
          fill="url(#biblePagesGrad)"
          stroke="#FFF4D0"
          strokeWidth="0.8"
        />
        {/* Page text lines indication */}
        <line x1="65" y1="184" x2="108" y2="179" stroke="#AA820A" strokeWidth="1" opacity="0.6" />
        <line x1="66" y1="188" x2="108" y2="183" stroke="#AA820A" strokeWidth="1" opacity="0.6" />
        <line x1="68" y1="192" x2="108" y2="187" stroke="#AA820A" strokeWidth="1" opacity="0.6" />
        <line x1="132" y1="179" x2="175" y2="184" stroke="#AA820A" strokeWidth="1" opacity="0.6" />
        <line x1="132" y1="183" x2="174" y2="188" stroke="#AA820A" strokeWidth="1" opacity="0.6" />
        <line x1="132" y1="187" x2="172" y2="192" stroke="#AA820A" strokeWidth="1" opacity="0.6" />
        {/* Golden Bookmark Ribbon */}
        <path
          d="M120 180 L120 212 L125 207 L130 212 L130 180 Z"
          fill="url(#goldCrossGrad)"
          stroke="#AA820A"
          strokeWidth="0.5"
        />

        {/* WHITE DOVE (Representing the Holy Spirit, soaring upwards right) */}
        {/* Dove Body & Wings */}
        <g filter="drop-shadow(0 0 6px rgba(255,255,255,0.9))">
          {/* Left Wing */}
          <path
            d="M148 108 Q158 80 182 66 Q178 88 162 108 Z"
            fill="url(#doveGrad)"
          />
          {/* Right Wing */}
          <path
            d="M165 116 Q188 102 210 94 Q196 116 174 122 Z"
            fill="url(#doveGrad)"
          />
          {/* Dove Body */}
          <path
            d="M152 118 Q162 106 172 112 Q176 116 182 120 Q170 126 156 122 Z"
            fill="#FFFFFF"
          />
          {/* Dove Tail */}
          <path
            d="M145 125 Q135 136 128 142 Q140 134 152 124 Z"
            fill="url(#doveGrad)"
          />
          {/* Olive Branch in Beak */}
          <path
            d="M182 118 Q187 114 192 116 M187 115 Q190 111 193 113"
            stroke="#00C6FF"
            strokeWidth="1.2"
            strokeLinecap="round"
          />
        </g>
      </svg>
    </div>
  );

  // Wordmark: WORD in metallic gold, ORA in luminous cyan/blue
  const wordmark = (
    <div className="flex flex-col items-center justify-center">
      <div className="flex items-center tracking-wider font-serif-sacred font-extrabold leading-none">
        <span className="gold-text-gradient text-[26px] sm:text-[28px] tracking-[0.08em] drop-shadow-[0_2px_10px_rgba(212,175,55,0.4)]">
          WORD
        </span>
        <span className="cyan-text-gradient text-[26px] sm:text-[28px] tracking-[0.08em] ml-1 drop-shadow-[0_2px_12px_rgba(0,198,255,0.45)]">
          ORA
        </span>
      </div>
      {showTagline && (
        <span className="text-[9px] sm:text-[10px] tracking-[0.24em] uppercase text-[#F7F6F2]/80 mt-0.5 font-medium font-sans">
          ONE WORD. EVERY NATION.
        </span>
      )}
    </div>
  );

  if (variant === 'icon') {
    return (
      <div className={`inline-flex items-center justify-center ${className}`} onClick={onClick}>
        {emblem(42)}
      </div>
    );
  }

  if (variant === 'hero') {
    return (
      <div
        className={`flex flex-col items-center justify-center text-center select-none ${className}`}
        onClick={onClick}
      >
        <div className="relative mb-3.5">
          {emblem(120)}
          {/* Ambient sacred backdrop glow */}
          <div className="absolute inset-0 bg-gradient-to-t from-[#2563EB]/25 to-[#D4AF37]/20 rounded-full blur-xl -z-10 pointer-events-none" />
        </div>
        <div className="flex items-center tracking-wider font-serif-sacred font-black leading-none">
          <span className="gold-text-gradient text-[34px] sm:text-[40px] tracking-[0.1em] drop-shadow-[0_2px_12px_rgba(212,175,55,0.45)]">
            WORD
          </span>
          <span className="cyan-text-gradient text-[34px] sm:text-[40px] tracking-[0.1em] ml-2 drop-shadow-[0_2px_14px_rgba(0,198,255,0.5)]">
            ORA
          </span>
        </div>
        {showTagline && (
          <div className="text-[11px] sm:text-[12px] tracking-[0.28em] uppercase text-[#F7F6F2]/90 mt-1.5 font-medium">
            ONE WORD. EVERY NATION.
          </div>
        )}
      </div>
    );
  }

  if (variant === 'compact') {
    return (
      <div
        className={`inline-flex items-center gap-2 cursor-pointer select-none ${className}`}
        onClick={onClick}
      >
        {emblem(32)}
        <div className="flex items-center font-serif-sacred font-bold text-lg leading-none">
          <span className="gold-text-gradient tracking-wide">WORD</span>
          <span className="cyan-text-gradient tracking-wide ml-0.5">ORA</span>
        </div>
      </div>
    );
  }

  // Default: Header lockup exactly matching the approved mobile header in reference image
  return (
    <div
      className={`inline-flex flex-col items-center justify-center select-none cursor-pointer ${className}`}
      onClick={onClick}
    >
      <div className="flex items-center gap-1.5">
        {emblem(26)}
        <div className="flex items-center font-serif-sacred font-extrabold text-[19px] leading-tight">
          <span className="gold-text-gradient tracking-[0.06em]">WORD</span>
          <span className="cyan-text-gradient tracking-[0.06em] ml-0.5">ORA</span>
        </div>
      </div>
      {showTagline && (
        <span className="text-[7.5px] tracking-[0.22em] uppercase text-[#F7F6F2]/75 font-medium font-sans">
          ONE WORD. EVERY NATION.
        </span>
      )}
    </div>
  );
};
