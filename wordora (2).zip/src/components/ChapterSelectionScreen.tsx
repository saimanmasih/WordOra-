import React, { useState, useMemo } from 'react';
import { ChevronLeft, Search, BookOpen, Sparkles, Check, ArrowRight } from 'lucide-react';
import { BIBLE_BOOKS } from '../data/bibleData';
import { TranslationId } from '../types';

export interface ChapterSelectionScreenProps {
  bookId: string;
  onSelectChapter: (chapter: number) => void;
  onBack: () => void;
  selectedTranslation?: TranslationId;
  currentChapter?: number;
}

const URDU_DIGITS = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];
function toUrduDigits(num: number): string {
  return String(num)
    .split('')
    .map((d) => URDU_DIGITS[parseInt(d, 10)] ?? d)
    .join('');
}

export const ChapterSelectionScreen: React.FC<ChapterSelectionScreenProps> = ({
  bookId,
  onSelectChapter,
  onBack,
  selectedTranslation = 'ur',
  currentChapter,
}) => {
  const [filterQuery, setFilterQuery] = useState('');
  const [selectedRange, setSelectedRange] = useState<string>('ALL');

  // Authoritative book lookup from locked metadata
  const book = useMemo(() => {
    return BIBLE_BOOKS.find((b) => b.id.toLowerCase() === bookId.toLowerCase()) || BIBLE_BOOKS[0];
  }, [bookId]);

  const isOT = book.testament === 'OT';
  const accentColor = isOT ? '#D4AF37' : '#00C6FF';
  const accentGoldOrCyan = isOT ? 'text-[#F5D77A]' : 'text-[#00C6FF]';
  const borderAccent = isOT ? 'border-[#D4AF37]' : 'border-[#00C6FF]';

  // Generate dynamic chapter numbers: exactly 1 to chaptersCount
  const allChapters = useMemo(() => {
    return Array.from({ length: book.chaptersCount }, (_, i) => i + 1);
  }, [book.chaptersCount]);

  // Compute segment ranges for books with many chapters (e.g., Psalms with 150, Genesis with 50)
  const ranges = useMemo(() => {
    if (book.chaptersCount <= 25) return [];

    const chunkSize = book.chaptersCount > 80 ? 30 : 25;
    const list: { id: string; label: string; start: number; end: number }[] = [];
    for (let i = 1; i <= book.chaptersCount; i += chunkSize) {
      const end = Math.min(i + chunkSize - 1, book.chaptersCount);
      list.push({
        id: `${i}-${end}`,
        label: `${i}–${end}`,
        start: i,
        end,
      });
    }
    return list;
  }, [book.chaptersCount]);

  // Filtered chapters
  const displayedChapters = useMemo(() => {
    let list = allChapters;

    // Filter by range if selected
    if (selectedRange !== 'ALL') {
      const matched = ranges.find((r) => r.id === selectedRange);
      if (matched) {
        list = list.filter((ch) => ch >= matched.start && ch <= matched.end);
      }
    }

    // Filter by query (e.g., user typed "5" or "50")
    if (filterQuery.trim()) {
      const q = filterQuery.trim();
      list = list.filter((ch) => String(ch).startsWith(q) || String(ch) === q);
    }

    return list;
  }, [allChapters, selectedRange, ranges, filterQuery]);

  const secondaryName =
    selectedTranslation === 'ru'
      ? book.romanUrduName
      : selectedTranslation === 'ur'
      ? book.urduName
      : book.romanUrduName;

  return (
    <div className="flex-1 overflow-y-auto px-4 py-3 space-y-4 pb-24 bg-[#081220] text-[#F7F6F2]">
      {/* Top Bar with Back Button */}
      <div className="flex items-center justify-between pt-1 border-b border-[#1F2A44] pb-3">
        <button
          type="button"
          onClick={onBack}
          id="btn-back-to-books"
          className="flex items-center gap-2 px-3 py-2 rounded-xl bg-[#0F1A2E] border border-[#1F2A44] hover:border-[#D4AF37]/60 text-[#B6C0D1] hover:text-[#F7F6F2] active:scale-95 transition-all"
          aria-label="Back to Books list"
        >
          <ChevronLeft className="w-5 h-5 text-[#F5D77A]" />
          <span className="text-xs font-semibold">Books</span>
        </button>

        {/* Translation Indicator */}
        <div className="flex items-center gap-2">
          <span
            className={`text-xs px-2.5 py-1 rounded-lg bg-[#0F1A2E] border font-sans font-semibold uppercase ${
              isOT ? 'border-[#D4AF37]/50 text-[#F5D77A]' : 'border-[#00C6FF]/50 text-[#00C6FF]'
            }`}
          >
            {isOT ? 'Old Testament' : 'New Testament'}
          </span>
        </div>
      </div>

      {/* Book Summary Card */}
      <div
        className={`p-4 rounded-2xl border bg-[#0F1A2E] relative overflow-hidden shadow-lg ${
          isOT ? 'border-[#D4AF37]/40' : 'border-[#00C6FF]/40'
        }`}
      >
        <div className="flex items-center justify-between">
          <div>
            <div className="flex items-center gap-2.5">
              <h1 className="text-xl font-bold font-serif-sacred text-[#F7F6F2] tracking-wide">
                {book.name}
              </h1>
              {secondaryName && (
                <span
                  className={`text-base font-serif-sacred ${accentGoldOrCyan}`}
                  dir={selectedTranslation === 'ur' ? 'rtl' : 'ltr'}
                >
                  {secondaryName}
                </span>
              )}
            </div>

            <p className="text-xs text-[#7A869A] mt-1 flex items-center gap-2">
              <span>{book.category}</span>
              <span>•</span>
              <span className="font-semibold text-[#B6C0D1]">
                {book.chaptersCount} {book.chaptersCount === 1 ? 'Chapter' : 'Chapters'}
              </span>
              {book.romanUrduName && selectedTranslation === 'ur' && (
                <>
                  <span>•</span>
                  <span>{book.romanUrduName}</span>
                </>
              )}
            </p>
          </div>

          {/* Sacred Symbol */}
          <div
            className={`w-12 h-12 rounded-xl bg-[#081220] border flex items-center justify-center flex-shrink-0 ${
              isOT ? 'border-[#D4AF37]/50 text-[#F5D77A]' : 'border-[#00C6FF]/50 text-[#00C6FF]'
            }`}
          >
            {isOT ? (
              <svg viewBox="0 0 24 24" className="w-6 h-6 fill-none stroke-current stroke-[1.8]">
                <rect x="4" y="5" width="7" height="14" rx="3" />
                <rect x="13" y="5" width="7" height="14" rx="3" />
                <line x1="6" y1="9" x2="9" y2="9" />
                <line x1="6" y1="12" x2="9" y2="12" />
                <line x1="15" y1="9" x2="18" y2="9" />
                <line x1="15" y1="12" x2="18" y2="12" />
              </svg>
            ) : (
              <span className="text-2xl font-serif-sacred font-bold leading-none">✝</span>
            )}
          </div>
        </div>

        {/* Action Prompt */}
        <div className="mt-3 pt-3 border-t border-[#1F2A44]/70 flex items-center justify-between text-xs text-[#B6C0D1]">
          <span>Select a chapter to read:</span>
          {currentChapter && (
            <span className="text-[11px] text-[#D4AF37] flex items-center gap-1 font-medium">
              <Check className="w-3.5 h-3.5 text-[#F5D77A]" />
              Currently on Chapter {currentChapter}
            </span>
          )}
        </div>
      </div>

      {/* Range Filter Pills (Only shown for books with > 25 chapters like Psalms, Genesis, Isaiah) */}
      {ranges.length > 0 && (
        <div className="space-y-1.5">
          <div className="flex items-center justify-between px-1 text-xs text-[#7A869A]">
            <span>Chapter Range</span>
            <span>{displayedChapters.length} shown</span>
          </div>
          <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none">
            <button
              type="button"
              onClick={() => setSelectedRange('ALL')}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition-all ${
                selectedRange === 'ALL'
                  ? isOT
                    ? 'bg-[#D4AF37] text-[#081220] font-bold shadow-sm'
                    : 'bg-[#00C6FF] text-[#081220] font-bold shadow-sm'
                  : 'bg-[#0F1A2E] text-[#B6C0D1] border border-[#1F2A44] hover:text-[#F7F6F2]'
              }`}
            >
              All (1–{book.chaptersCount})
            </button>
            {ranges.map((r) => (
              <button
                key={r.id}
                type="button"
                onClick={() => setSelectedRange(r.id)}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition-all ${
                  selectedRange === r.id
                    ? isOT
                      ? 'bg-[#D4AF37] text-[#081220] font-bold shadow-sm'
                      : 'bg-[#00C6FF] text-[#081220] font-bold shadow-sm'
                    : 'bg-[#0F1A2E] text-[#B6C0D1] border border-[#1F2A44] hover:text-[#F7F6F2]'
                }`}
              >
                {r.label}
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Optional Quick Chapter Search Filter (for books with many chapters) */}
      {book.chaptersCount > 15 && (
        <div className="relative">
          <input
            type="number"
            min="1"
            max={book.chaptersCount}
            value={filterQuery}
            onChange={(e) => setFilterQuery(e.target.value)}
            placeholder={`Filter chapter number (1 to ${book.chaptersCount})...`}
            className="w-full bg-[#0F1A2E] border border-[#1F2A44] rounded-xl px-4 py-2 pl-10 text-xs text-[#F7F6F2] placeholder-[#7A869A] focus:outline-none focus:border-[#D4AF37] transition-colors"
          />
          <Search className="w-4 h-4 text-[#7A869A] absolute left-3.5 top-2.5" />
          {filterQuery && (
            <button
              type="button"
              onClick={() => setFilterQuery('')}
              className="absolute right-3 top-2 text-xs text-[#7A869A] hover:text-[#F7F6F2]"
            >
              Clear
            </button>
          )}
        </div>
      )}

      {/* Dynamic Responsive Chapter Selection Grid */}
      <div className="grid grid-cols-5 gap-2.5 sm:gap-3" id="chapter-selection-grid">
        {displayedChapters.map((ch) => {
          const isCurrent = currentChapter === ch;

          return (
            <button
              key={ch}
              id={`chapter-btn-${book.id}-${ch}`}
              type="button"
              onClick={() => onSelectChapter(ch)}
              className={`h-14 rounded-xl border flex flex-col items-center justify-center cursor-pointer transition-all active:scale-95 group shadow-sm ${
                isCurrent
                  ? isOT
                    ? 'bg-[#18263D] border-[#D4AF37] text-[#FFF4D0] ring-2 ring-[#D4AF37]/30'
                    : 'bg-[#18263D] border-[#00C6FF] text-[#E0F7FF] ring-2 ring-[#00C6FF]/30'
                  : 'bg-[#0F1A2E] border-[#1F2A44] text-[#F7F6F2] hover:bg-[#15233D] hover:border-[#D4AF37]/60'
              }`}
              title={`Read ${book.name} Chapter ${ch}`}
            >
              {/* Western Numeral (1, 2, 5, 50, etc.) */}
              <span className="text-base font-bold font-sans tracking-tight group-hover:scale-105 transition-transform">
                {ch}
              </span>

              {/* Urdu Numeral underneath (۱, ۲, ۵, ۵۰, etc.) */}
              <span
                className={`text-[10px] font-serif-sacred mt-0.5 leading-none ${
                  isCurrent
                    ? isOT
                      ? 'text-[#F5D77A]'
                      : 'text-[#00C6FF]'
                    : 'text-[#7A869A] group-hover:text-[#B6C0D1]'
                }`}
              >
                {toUrduDigits(ch)}
              </span>
            </button>
          );
        })}
      </div>

      {displayedChapters.length === 0 && (
        <div className="text-center py-10 bg-[#0F1A2E] border border-[#1F2A44] rounded-2xl p-6">
          <p className="text-sm text-[#7A869A]">No chapters match "{filterQuery}".</p>
          <button
            type="button"
            onClick={() => {
              setFilterQuery('');
              setSelectedRange('ALL');
            }}
            className="mt-3 px-4 py-2 rounded-xl bg-[#081220] border border-[#1F2A44] text-xs text-[#F5D77A] hover:border-[#D4AF37]"
          >
            Show All Chapters
          </button>
        </div>
      )}
    </div>
  );
};
