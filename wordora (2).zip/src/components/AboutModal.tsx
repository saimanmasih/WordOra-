import React from 'react';
import { X, ShieldCheck, Heart, Sparkles, Globe, BookOpen } from 'lucide-react';
import { WordOraLogo } from './WordOraLogo';

interface AboutModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const AboutModal: React.FC<AboutModalProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-black/80 backdrop-blur-md">
      <div className="relative w-full max-w-md bg-[#0F1A2E] border border-[#1F2A44] rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="px-5 py-3.5 border-b border-[#1F2A44] flex items-center justify-between bg-[#081220]/70">
          <span className="text-xs font-bold uppercase tracking-wider text-[#F5D77A]">
            About WordOra
          </span>
          <button
            type="button"
            onClick={onClose}
            className="p-1 rounded-lg text-[#7A869A] hover:text-[#F7F6F2]"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 overflow-y-auto space-y-5 text-center">
          <WordOraLogo variant="hero" />

          <div className="p-4 rounded-xl bg-[#081220] border border-[#1F2A44] text-left space-y-2">
            <h4 className="text-xs font-bold text-[#F5D77A] uppercase tracking-wider flex items-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5" />
              <span>Sacred Modern Vision</span>
            </h4>
            <p className="text-xs text-[#B6C0D1] leading-relaxed">
              WordOra is a premium Christian Bible application crafted to bring the uncompromised Word of God to every nation, tribe, and tongue. Built specifically for English, Roman Urdu (Kitab-e-Muqaddas), and Nastaliq Urdu speakers with holy reverence and modern elegance.
            </p>
          </div>

          <div className="grid grid-cols-2 gap-3 text-left">
            <div className="p-3 rounded-xl bg-[#081220] border border-[#1F2A44]">
              <ShieldCheck className="w-5 h-5 text-[#00C6FF] mb-1" />
              <h5 className="text-xs font-bold text-[#F7F6F2]">
                Verified Scripture
              </h5>
              <p className="text-[11px] text-[#7A869A] mt-0.5">
                Authentic historical biblical texts with zero fabricated verse wording.
              </p>
            </div>

            <div className="p-3 rounded-xl bg-[#081220] border border-[#1F2A44]">
              <Globe className="w-5 h-5 text-[#F5D77A] mb-1" />
              <h5 className="text-xs font-bold text-[#F7F6F2]">
                Roman Urdu & Nastaliq
              </h5>
              <p className="text-[11px] text-[#7A869A] mt-0.5">
                Dedicated support for subcontinental believers worldwide.
              </p>
            </div>
          </div>

          <p className="text-[11px] text-[#D4AF37] font-serif-sacred uppercase tracking-widest font-semibold">
            One Word. Every Nation.
          </p>
        </div>

        {/* Footer */}
        <div className="p-3 border-t border-[#1F2A44] bg-[#081220] flex justify-end">
          <button
            type="button"
            onClick={onClose}
            className="px-5 py-2 rounded-xl bg-[#D4AF37] text-[#081220] font-bold text-xs uppercase tracking-wider"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
