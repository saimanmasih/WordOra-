import React, { useState } from 'react';
import { Play, Pause, X, Music, ChevronUp, ChevronDown, Volume2, Sparkles } from 'lucide-react';
import { WorshipTrack } from '../types';

interface AudioPlayerBarProps {
  currentTrack: WorshipTrack | null;
  isPlaying: boolean;
  onTogglePlay: () => void;
  onCloseTrack: () => void;
}

export const AudioPlayerBar: React.FC<AudioPlayerBarProps> = ({
  currentTrack,
  isPlaying,
  onTogglePlay,
  onCloseTrack,
}) => {
  const [isExpanded, setIsExpanded] = useState(false);

  if (!currentTrack) return null;

  return (
    <div className="fixed bottom-[58px] left-0 right-0 z-30 px-3 max-w-lg mx-auto pointer-events-auto transition-all">
      {/* Expanded Lyrics & Player Drawer */}
      {isExpanded && (
        <div className="mb-2 p-4 rounded-2xl bg-[#0F1A2E] border border-[#1F2A44] shadow-2xl backdrop-blur-lg animate-in slide-in-from-bottom-5">
          <div className="flex items-center justify-between border-b border-[#1F2A44] pb-3 mb-3">
            <div className="flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-[#F5D77A]" />
              <span className="text-xs font-semibold uppercase tracking-wider text-[#F5D77A]">
                Lyrics & Reflection
              </span>
            </div>
            <button
              type="button"
              onClick={() => setIsExpanded(false)}
              className="p-1 rounded-lg text-[#7A869A] hover:text-[#F7F6F2]"
            >
              <ChevronDown className="w-4 h-4" />
            </button>
          </div>

          <div className="max-h-48 overflow-y-auto pr-1 text-center font-sans space-y-2">
            <h4 className="text-sm font-bold text-[#F7F6F2]">{currentTrack.title}</h4>
            <p className="text-xs text-[#00C6FF] font-medium">{currentTrack.subtitle}</p>
            <div className="mt-3 text-xs leading-relaxed text-[#B6C0D1] whitespace-pre-line">
              {currentTrack.lyrics}
            </div>
          </div>
        </div>
      )}

      {/* Mini Player Bar */}
      <div className="p-2.5 rounded-xl bg-[#0F1A2E]/95 border border-[#1F2A44] shadow-xl flex items-center justify-between gap-3 backdrop-blur-md">
        {/* Track info */}
        <div
          onClick={() => setIsExpanded(!isExpanded)}
          className="flex items-center gap-3 flex-1 min-w-0 cursor-pointer"
        >
          <div className="w-9 h-9 rounded-lg bg-gradient-to-tr from-[#1E3A8A] to-[#D4AF37]/40 border border-[#D4AF37]/50 flex items-center justify-center text-[#F5D77A] flex-shrink-0 shadow-sm">
            <Music className="w-4 h-4" />
          </div>

          <div className="min-w-0">
            <h4 className="text-xs font-semibold text-[#F7F6F2] truncate flex items-center gap-1.5">
              <span>{currentTrack.title}</span>
              {isPlaying && (
                <span className="flex gap-0.5 items-end h-3">
                  <span className="w-0.5 h-2 bg-[#00C6FF] rounded-full animate-pulse" />
                  <span className="w-0.5 h-3 bg-[#D4AF37] rounded-full animate-pulse delay-75" />
                  <span className="w-0.5 h-1.5 bg-[#00C6FF] rounded-full animate-pulse delay-150" />
                </span>
              )}
            </h4>
            <p className="text-[11px] text-[#7A869A] truncate">
              {currentTrack.subtitle} • {currentTrack.duration}
            </p>
          </div>
        </div>

        {/* Action Controls */}
        <div className="flex items-center gap-1.5 flex-shrink-0">
          <button
            type="button"
            onClick={() => setIsExpanded(!isExpanded)}
            className="p-1.5 rounded-lg text-[#B6C0D1] hover:text-[#F7F6F2] hover:bg-[#111A2E]"
            title="Lyrics"
          >
            {isExpanded ? <ChevronDown className="w-4 h-4" /> : <ChevronUp className="w-4 h-4" />}
          </button>

          <button
            type="button"
            onClick={onTogglePlay}
            className="w-8 h-8 rounded-lg bg-gradient-to-r from-[#00C6FF] to-[#2563EB] text-[#081220] flex items-center justify-center font-bold active:scale-95 transition-transform shadow-[0_0_10px_rgba(0,198,255,0.4)]"
            aria-label={isPlaying ? 'Pause' : 'Play'}
          >
            {isPlaying ? (
              <Pause className="w-4 h-4 fill-current" />
            ) : (
              <Play className="w-4 h-4 fill-current ml-0.5" />
            )}
          </button>

          <button
            type="button"
            onClick={onCloseTrack}
            className="p-1.5 rounded-lg text-[#7A869A] hover:text-[#F7F6F2] hover:bg-[#111A2E]"
            aria-label="Close Player"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};
