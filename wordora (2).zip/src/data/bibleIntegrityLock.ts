/**
 * ============================================================================
 * WORDORA AUTHORITATIVE BIBLE DATA — IMMUTABLE / READ-ONLY SHIELD
 * ============================================================================
 * CRITICAL RULE:
 * The scripture text in WordOra is PERMANENTLY LOCKED and IMMUTABLE.
 *
 * DO NOT:
 * - Rewrite, translate, paraphrase, or normalize verses
 * - Remove or add diacritics, change punctuation or numbering
 * - Overwrite or re-import any scripture dataset
 * - Execute automated "corrections" or cleanup on scripture text
 *
 * Features may READ scripture. Features may NOT WRITE scripture.
 * ============================================================================
 */

import fs from "fs";
import path from "path";
import crypto from "crypto";

export interface IntegrityCheckResult {
  isValid: boolean;
  locked: boolean;
  status: "LOCKED_VERIFIED" | "INTEGRITY_VIOLATION";
  verifiedAt: string;
  error?: string;
  metrics: {
    books: number;
    chapters: number;
    verses: number;
    fileSha256: string;
    contentHash: string;
    duplicateVerses: number;
    emptyVerses: number;
    unicodeReplacementChars: number;
    htmlLeakage: number;
  };
}

const MANIFEST_PATH = path.join(process.cwd(), "src", "data", "bible_integrity_manifest.json");
const FULL_DB_PATH = path.join(process.cwd(), "src", "data", "urdu_bible_full.json");

let cachedFrozenDb: Record<string, Record<string, { ur: any[] }>> | null = null;
let lastIntegrityResult: IntegrityCheckResult | null = null;

/**
 * Calculates a deterministic content hash of all scripture records in canonical order.
 */
export function computeDeterministicContentHash(db: Record<string, Record<string, { ur: any[] }>>): string {
  const hasher = crypto.createHash("sha256");
  const books = Object.keys(db);

  for (const b of books) {
    const chs = Object.keys(db[b]).sort((a, b) => parseInt(a, 10) - parseInt(b, 10));
    for (const c of chs) {
      const verses = db[b][c]?.ur || [];
      for (const v of verses) {
        hasher.update(`${b}:${c}:${v.verse}:${v.sectionHeading || ""}:${v.text}\n`);
      }
    }
  }

  return hasher.digest("hex");
}

/**
 * Verifies the authoritative Urdu Bible dataset against the locked manifest.
 * Never attempts to repair or rewrite data if mismatch occurs; instead, flags violation.
 */
export function verifyBibleIntegrity(): IntegrityCheckResult {
  const now = new Date().toISOString();

  if (!fs.existsSync(MANIFEST_PATH)) {
    return {
      isValid: false,
      locked: false,
      status: "INTEGRITY_VIOLATION",
      verifiedAt: now,
      error: `Locked integrity manifest missing at ${MANIFEST_PATH}`,
      metrics: {
        books: 0,
        chapters: 0,
        verses: 0,
        fileSha256: "",
        contentHash: "",
        duplicateVerses: 0,
        emptyVerses: 0,
        unicodeReplacementChars: 0,
        htmlLeakage: 0,
      },
    };
  }

  if (!fs.existsSync(FULL_DB_PATH)) {
    return {
      isValid: false,
      locked: false,
      status: "INTEGRITY_VIOLATION",
      verifiedAt: now,
      error: `Authoritative Bible dataset missing at ${FULL_DB_PATH}`,
      metrics: {
        books: 0,
        chapters: 0,
        verses: 0,
        fileSha256: "",
        contentHash: "",
        duplicateVerses: 0,
        emptyVerses: 0,
        unicodeReplacementChars: 0,
        htmlLeakage: 0,
      },
    };
  }

  try {
    const manifest = JSON.parse(fs.readFileSync(MANIFEST_PATH, "utf8"));
    const fileBuf = fs.readFileSync(FULL_DB_PATH);
    const fileSha256 = crypto.createHash("sha256").update(fileBuf).digest("hex");

    if (fileSha256 !== manifest.authoritativeDataset.sha256) {
      return {
        isValid: false,
        locked: true,
        status: "INTEGRITY_VIOLATION",
        verifiedAt: now,
        error: `File SHA-256 mismatch: expected ${manifest.authoritativeDataset.sha256}, got ${fileSha256}. Authoritative dataset has been altered!`,
        metrics: {
          books: 0,
          chapters: 0,
          verses: 0,
          fileSha256,
          contentHash: "",
          duplicateVerses: 0,
          emptyVerses: 0,
          unicodeReplacementChars: 0,
          htmlLeakage: 0,
        },
      };
    }

    const db = JSON.parse(fileBuf.toString("utf8"));
    const books = Object.keys(db);
    let totalChapters = 0;
    let totalVerses = 0;
    let duplicateVerses = 0;
    let emptyVerses = 0;
    let unicodeReplacementChars = 0;
    let htmlLeakage = 0;

    for (const b of books) {
      const chs = Object.keys(db[b]);
      totalChapters += chs.length;
      for (const c of chs) {
        const verses = db[b][c]?.ur || [];
        const seen = new Set();
        for (const v of verses) {
          totalVerses++;
          if (seen.has(v.verse)) duplicateVerses++;
          seen.add(v.verse);
          if (!v.text || v.text.trim() === "") emptyVerses++;
          if (v.text.includes("\uFFFD")) unicodeReplacementChars++;
          if (/<[^>]+>/.test(v.text)) htmlLeakage++;
        }
      }
    }

    const contentHash = computeDeterministicContentHash(db);
    if (contentHash !== manifest.authoritativeDataset.deterministicContentHash) {
      return {
        isValid: false,
        locked: true,
        status: "INTEGRITY_VIOLATION",
        verifiedAt: now,
        error: `Deterministic content hash mismatch: expected ${manifest.authoritativeDataset.deterministicContentHash}, got ${contentHash}. Scripture content changed!`,
        metrics: {
          books: books.length,
          chapters: totalChapters,
          verses: totalVerses,
          fileSha256,
          contentHash,
          duplicateVerses,
          emptyVerses,
          unicodeReplacementChars,
          htmlLeakage,
        },
      };
    }

    if (books.length !== 66 || totalChapters !== 1189 || totalVerses !== 31103) {
      return {
        isValid: false,
        locked: true,
        status: "INTEGRITY_VIOLATION",
        verifiedAt: now,
        error: `Structure mismatch: 66 books, 1189 chapters, 31103 verses expected. Found ${books.length} books, ${totalChapters} chapters, ${totalVerses} verses.`,
        metrics: {
          books: books.length,
          chapters: totalChapters,
          verses: totalVerses,
          fileSha256,
          contentHash,
          duplicateVerses,
          emptyVerses,
          unicodeReplacementChars,
          htmlLeakage,
        },
      };
    }

    // Verify sample verses
    if (manifest.verifiedSamples) {
      for (const [sampleKey, sample] of Object.entries(manifest.verifiedSamples) as [string, any][]) {
        const actualVerse = db[sample.book]?.[String(sample.chapter)]?.ur?.find((v: any) => v.verse === sample.verse);
        if (!actualVerse) {
          return {
            isValid: false,
            locked: true,
            status: "INTEGRITY_VIOLATION",
            verifiedAt: now,
            error: `Sample verse missing: ${sampleKey} (${sample.book} ${sample.chapter}:${sample.verse})`,
            metrics: {
              books: books.length,
              chapters: totalChapters,
              verses: totalVerses,
              fileSha256,
              contentHash,
              duplicateVerses,
              emptyVerses,
              unicodeReplacementChars,
              htmlLeakage,
            },
          };
        }
        if (actualVerse.text !== sample.text) {
          return {
            isValid: false,
            locked: true,
            status: "INTEGRITY_VIOLATION",
            verifiedAt: now,
            error: `Sample verse text mismatch in ${sampleKey} (${sample.book} ${sample.chapter}:${sample.verse})`,
            metrics: {
              books: books.length,
              chapters: totalChapters,
              verses: totalVerses,
              fileSha256,
              contentHash,
              duplicateVerses,
              emptyVerses,
              unicodeReplacementChars,
              htmlLeakage,
            },
          };
        }
      }
    }

    const result: IntegrityCheckResult = {
      isValid: true,
      locked: true,
      status: "LOCKED_VERIFIED",
      verifiedAt: now,
      metrics: {
        books: books.length,
        chapters: totalChapters,
        verses: totalVerses,
        fileSha256,
        contentHash,
        duplicateVerses,
        emptyVerses,
        unicodeReplacementChars,
        htmlLeakage,
      },
    };

    lastIntegrityResult = result;
    return result;
  } catch (err: any) {
    return {
      isValid: false,
      locked: true,
      status: "INTEGRITY_VIOLATION",
      verifiedAt: now,
      error: `Integrity check failed with error: ${err.message}`,
      metrics: {
        books: 0,
        chapters: 0,
        verses: 0,
        fileSha256: "",
        contentHash: "",
        duplicateVerses: 0,
        emptyVerses: 0,
        unicodeReplacementChars: 0,
        htmlLeakage: 0,
      },
    };
  }
}

/**
 * Returns the read-only, in-memory cached authoritative Bible database.
 * Every book, chapter, and verse array is frozen with Object.freeze to guarantee runtime immutability.
 */
export function getLockedBibleDb(): Record<string, Record<string, { ur: any[] }>> {
  if (cachedFrozenDb) {
    return cachedFrozenDb;
  }

  const check = verifyBibleIntegrity();
  if (!check.isValid) {
    console.error("[WORDORA SHIELD CRITICAL ERROR]: Bible integrity check failed:", check.error);
    throw new Error(`Authoritative Bible text integrity check failed: ${check.error}`);
  }

  const raw = fs.readFileSync(FULL_DB_PATH, "utf8");
  const parsed = JSON.parse(raw);

  // Recursively freeze in-memory structures to guarantee runtime immutability
  for (const book of Object.keys(parsed)) {
    const chMap = parsed[book];
    for (const ch of Object.keys(chMap)) {
      const record = chMap[ch];
      if (record && record.ur) {
        for (const v of record.ur) {
          Object.freeze(v);
        }
        Object.freeze(record.ur);
        Object.freeze(record);
      }
    }
    Object.freeze(chMap);
  }
  Object.freeze(parsed);

  cachedFrozenDb = parsed;
  return cachedFrozenDb;
}

/**
 * Rejection helper to block any write or import operation attempting to modify scripture.
 */
export function rejectScriptureWrite(operationName: string): never {
  const msg = `[WORDORA PERMANENT LOCK]: Operation "${operationName}" REJECTED. The authoritative 66-book Urdu Bible dataset is permanently locked and immutable. Writes, imports, and modifications are strictly forbidden.`;
  console.error(msg);
  throw new Error(msg);
}

/**
 * Returns the latest integrity verification result or re-checks if not yet evaluated.
 */
export function getLastIntegrityResult(): IntegrityCheckResult {
  if (!lastIntegrityResult) {
    return verifyBibleIntegrity();
  }
  return lastIntegrityResult;
}
