import https from "https";
import fs from "fs";
import path from "path";
import { BIBLE_BOOKS } from "./bibleData";

export interface VerseContent {
  verse: number;
  text: string;
  sectionHeading?: string;
}

export interface ImportProgress {
  status: "idle" | "in_progress" | "paused" | "verifying" | "completed" | "error";
  totalChapters: number;
  completedChapters: number;
  booksProcessed: number;
  totalBooks: number;
  currentBook: string;
  currentChapter: number;
  totalVerses: number;
  preservedGenesis1To4: boolean;
  errors: string[];
  retries: number;
  skippedExisting: number;
  startedAt?: string;
  updatedAt?: string;
}

const STAGING_DIR = path.join(process.cwd(), "src", "data", "urdu_bible_staging");
const PROGRESS_FILE = path.join(STAGING_DIR, "import_progress.json");
const FULL_DB_FILE = path.join(process.cwd(), "src", "data", "urdu_bible_full.json");
const VERIFIED_GENESIS_FILE = path.join(process.cwd(), "src", "data", "genesis_verified_1_4.json");

export function getImportProgress(): ImportProgress {
  try {
    if (fs.existsSync(PROGRESS_FILE)) {
      return JSON.parse(fs.readFileSync(PROGRESS_FILE, "utf8"));
    }
  } catch (e) {
    console.error("Error reading import progress:", e);
  }
  return {
    status: fs.existsSync(FULL_DB_FILE) ? "completed" : "idle",
    totalChapters: 1189,
    completedChapters: fs.existsSync(FULL_DB_FILE) ? 1189 : 4,
    booksProcessed: fs.existsSync(FULL_DB_FILE) ? 66 : 1,
    totalBooks: 66,
    currentBook: "Genesis",
    currentChapter: 4,
    totalVerses: fs.existsSync(FULL_DB_FILE) ? 31102 : 106,
    preservedGenesis1To4: true,
    errors: [],
    retries: 0,
    skippedExisting: 0,
  };
}

export function saveImportProgress(progress: ImportProgress) {
  try {
    if (!fs.existsSync(STAGING_DIR)) {
      fs.mkdirSync(STAGING_DIR, { recursive: true });
    }
    progress.updatedAt = new Date().toISOString();
    fs.writeFileSync(PROGRESS_FILE, JSON.stringify(progress, null, 2), "utf8");
  } catch (e) {
    console.error("Error saving import progress:", e);
  }
}

export function fetchChapterHtml(usfm: string): Promise<string> {
  return new Promise((resolve) => {
    https.get(
      {
        hostname: "www.bible.com",
        path: `/bible/189/${usfm}.URD`,
        headers: {
          "User-Agent": "curl/8.4.0",
          Accept: "*/*",
        },
      },
      (res) => {
        const chunks: Buffer[] = [];
        res.on("data", (c: Buffer) => chunks.push(c));
        res.on("end", () => resolve(Buffer.concat(chunks).toString("utf8")));
      }
    ).on("error", (err) => {
      console.warn(`Network error fetching ${usfm}:`, err.message);
      resolve("");
    });
  });
}

export function parseChapterHtml(html: string): VerseContent[] {
  if (!html || !html.includes("ChapterContent-module")) {
    return [];
  }
  const raw = html.replace(/\\"/g, '"');
  const elementRegex =
    /(?:<div class="[^"]*__s[^"]*"><span class="[^"]*heading">([^<]+)<\/span><\/div>|<span class="[^"]*verse" data-usfm="([^"]+)">([\s\S]*?)(?=(?:<span class="[^"]*verse" data-usfm=|<\/div>|$)))/g;
  const matches = [...raw.matchAll(elementRegex)];
  let currentHeading: string | null = null;
  const verseMap = new Map<number, string>();
  const verseHeadings = new Map<number, string>();

  for (const m of matches) {
    if (m[1]) {
      currentHeading = m[1].trim();
    } else if (m[2] && m[3]) {
      const parts = m[2].split(".");
      const vNum = parseInt(parts[2], 10);
      if (isNaN(vNum)) continue;
      const clean = m[3]
        .replace(/<span class="[^"]*label">[^<]*<\/span>/g, "")
        .replace(/<[^>]+>/g, "")
        .replace(/\\n/g, "\n")
        .replace(/&nbsp;/g, " ")
        .trim();
      if (!verseMap.has(vNum)) {
        verseMap.set(vNum, clean);
        if (currentHeading) {
          verseHeadings.set(vNum, currentHeading);
          currentHeading = null;
        }
      } else {
        verseMap.set(vNum, (verseMap.get(vNum) + " " + clean).trim());
      }
    }
  }

  const maxV = Math.max(...Array.from(verseMap.keys()), 0);
  const verses: VerseContent[] = [];
  for (let i = 1; i <= maxV; i++) {
    if (verseMap.has(i)) {
      const obj: VerseContent = { verse: i, text: verseMap.get(i)! };
      if (verseHeadings.has(i)) obj.sectionHeading = verseHeadings.get(i);
      verses.push(obj);
    }
  }
  return verses;
}

export function getVerifiedGenesis1To4(): Record<number, { ur: VerseContent[] }> {
  if (fs.existsSync(VERIFIED_GENESIS_FILE)) {
    return JSON.parse(fs.readFileSync(VERIFIED_GENESIS_FILE, "utf8"));
  }
  throw new Error("genesis_verified_1_4.json snapshot missing! Preserved Genesis 1-4 required.");
}

// Stage a single chapter to disk
export function stageChapter(bookId: string, chapter: number, verses: VerseContent[]) {
  const bookDir = path.join(STAGING_DIR, bookId);
  if (!fs.existsSync(bookDir)) {
    fs.mkdirSync(bookDir, { recursive: true });
  }
  const filePath = path.join(bookDir, `${chapter}.json`);
  fs.writeFileSync(filePath, JSON.stringify(verses, null, 2), "utf8");
}

export function getStagedChapter(bookId: string, chapter: number): VerseContent[] | null {
  const filePath = path.join(STAGING_DIR, bookId, `${chapter}.json`);
  if (fs.existsSync(filePath)) {
    try {
      return JSON.parse(fs.readFileSync(filePath, "utf8"));
    } catch (e) {
      return null;
    }
  }
  return null;
}
