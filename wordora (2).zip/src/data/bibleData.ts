/**
 * ============================================================================
 * WORDORA AUTHORITATIVE BIBLE DATA — IMMUTABLE / READ-ONLY
 * ============================================================================
 * CRITICAL DIRECTIVE FOR DEVELOPERS AND AI CODING AGENTS:
 * The scripture text in WordOra is PERMANENTLY LOCKED and IMMUTABLE.
 *
 * All 66 books, 1,189 chapters, and 31,103 verses are verified and locked.
 * DO NOT:
 * - Rewrite, translate, paraphrase, or normalize verses
 * - Remove or add diacritics, change punctuation or verse numbers
 * - Overwrite or re-import any scripture dataset
 * - Execute automated "corrections" or cleanup on scripture text
 *
 * Features may READ scripture. Features may NOT WRITE scripture.
 * ============================================================================
 */

import { BibleBook, BibleTranslation, TranslationId } from '../types';
import { GENESIS_21_TO_50 } from './genesis21to50';
import { EXODUS_DATA } from './exodusData';

// Active Bible Translations Catalog (Reset state: 0 installed Bible datasets)
export const TRANSLATIONS: BibleTranslation[] = [
  {
    id: 'ur',
    code: 'UR',
    name: 'Urdu Bible',
    fullName: 'Original Urdu Bible (انجیل مقدس)',
    language: 'Urdu',
    isDownloaded: true,
    isRTL: true,
    description: 'Authentic Urdu Bible translation (Genesis 1 verified).',
  },
];

export const BIBLE_BOOKS: BibleBook[] = [
  // Old Testament (39 Books)
  { id: 'genesis', name: 'Genesis', testament: 'OT', chaptersCount: 50, abbreviation: 'Gen', romanUrduName: 'Paidaish', urduName: 'پیدائش', category: 'Law' },
  { id: 'exodus', name: 'Exodus', testament: 'OT', chaptersCount: 40, abbreviation: 'Exo', romanUrduName: 'Khuruj', urduName: 'خروج', category: 'Law' },
  { id: 'leviticus', name: 'Leviticus', testament: 'OT', chaptersCount: 27, abbreviation: 'Lev', romanUrduName: 'Ahbar', urduName: 'احبار', category: 'Law' },
  { id: 'numbers', name: 'Numbers', testament: 'OT', chaptersCount: 36, abbreviation: 'Num', romanUrduName: 'Ginti', urduName: 'گنتی', category: 'Law' },
  { id: 'deuteronomy', name: 'Deuteronomy', testament: 'OT', chaptersCount: 34, abbreviation: 'Deu', romanUrduName: 'Istisna', urduName: 'استثنا', category: 'Law' },
  { id: 'joshua', name: 'Joshua', testament: 'OT', chaptersCount: 24, abbreviation: 'Jos', romanUrduName: 'Yashua', urduName: 'یشوع', category: 'History' },
  { id: 'judges', name: 'Judges', testament: 'OT', chaptersCount: 21, abbreviation: 'Jdg', romanUrduName: 'Qazis', urduName: 'قضاۃ', category: 'History' },
  { id: 'ruth', name: 'Ruth', testament: 'OT', chaptersCount: 4, abbreviation: 'Rut', romanUrduName: 'Ruth', urduName: 'روت', category: 'History' },
  { id: '1samuel', name: '1 Samuel', testament: 'OT', chaptersCount: 31, abbreviation: '1Sa', romanUrduName: '1 Samual', urduName: '۱ سموئیل', category: 'History' },
  { id: '2samuel', name: '2 Samuel', testament: 'OT', chaptersCount: 24, abbreviation: '2Sa', romanUrduName: '2 Samual', urduName: '۲ سموئیل', category: 'History' },
  { id: '1kings', name: '1 Kings', testament: 'OT', chaptersCount: 22, abbreviation: '1Ki', romanUrduName: '1 Salatin', urduName: '۱ سلاطین', category: 'History' },
  { id: '2kings', name: '2 Kings', testament: 'OT', chaptersCount: 25, abbreviation: '2Ki', romanUrduName: '2 Salatin', urduName: '۲ سلاطین', category: 'History' },
  { id: '1chronicles', name: '1 Chronicles', testament: 'OT', chaptersCount: 29, abbreviation: '1Ch', romanUrduName: '1 Tawarikh', urduName: '۱ تواریخ', category: 'History' },
  { id: '2chronicles', name: '2 Chronicles', testament: 'OT', chaptersCount: 36, abbreviation: '2Ch', romanUrduName: '2 Tawarikh', urduName: '۲ تواریخ', category: 'History' },
  { id: 'ezra', name: 'Ezra', testament: 'OT', chaptersCount: 10, abbreviation: 'Ezr', romanUrduName: 'Ezra', urduName: 'عزرا', category: 'History' },
  { id: 'nehemiah', name: 'Nehemiah', testament: 'OT', chaptersCount: 13, abbreviation: 'Neh', romanUrduName: 'Nehemiah', urduName: 'نحمیاہ', category: 'History' },
  { id: 'esther', name: 'Esther', testament: 'OT', chaptersCount: 10, abbreviation: 'Est', romanUrduName: 'Astar', urduName: 'ایستر', category: 'History' },
  { id: 'job', name: 'Job', testament: 'OT', chaptersCount: 42, abbreviation: 'Job', romanUrduName: 'Ayyub', urduName: 'ایوب', category: 'Poetry' },
  { id: 'psalms', name: 'Psalms', testament: 'OT', chaptersCount: 150, abbreviation: 'Psa', romanUrduName: 'Zaboor', urduName: 'زبور', category: 'Poetry' },
  { id: 'proverbs', name: 'Proverbs', testament: 'OT', chaptersCount: 31, abbreviation: 'Pro', romanUrduName: 'Amsal', urduName: 'امثال', category: 'Poetry' },
  { id: 'ecclesiastes', name: 'Ecclesiastes', testament: 'OT', chaptersCount: 12, abbreviation: 'Ecc', romanUrduName: 'Waiz', urduName: 'واعظ', category: 'Poetry' },
  { id: 'songofsolomon', name: 'Song of Solomon', testament: 'OT', chaptersCount: 8, abbreviation: 'Sng', romanUrduName: 'Ghazal-ul-Ghazlaat', urduName: 'غزل الغزلات', category: 'Poetry' },
  { id: 'isaiah', name: 'Isaiah', testament: 'OT', chaptersCount: 66, abbreviation: 'Isa', romanUrduName: 'Yashayah', urduName: 'یسعیاہ', category: 'Major Prophets' },
  { id: 'jeremiah', name: 'Jeremiah', testament: 'OT', chaptersCount: 52, abbreviation: 'Jer', romanUrduName: 'Yarmiah', urduName: 'یرمیاہ', category: 'Major Prophets' },
  { id: 'lamentations', name: 'Lamentations', testament: 'OT', chaptersCount: 5, abbreviation: 'Lam', romanUrduName: 'Nauha', urduName: 'نوحہ', category: 'Major Prophets' },
  { id: 'ezekiel', name: 'Ezekiel', testament: 'OT', chaptersCount: 48, abbreviation: 'Ezk', romanUrduName: 'Hizqiel', urduName: 'حزقی ایل', category: 'Major Prophets' },
  { id: 'daniel', name: 'Daniel', testament: 'OT', chaptersCount: 12, abbreviation: 'Dan', romanUrduName: 'Daniyel', urduName: 'دانی ایل', category: 'Major Prophets' },
  { id: 'hosea', name: 'Hosea', testament: 'OT', chaptersCount: 14, abbreviation: 'Hos', romanUrduName: 'Hoshea', urduName: 'ہوسیع', category: 'Minor Prophets' },
  { id: 'joel', name: 'Joel', testament: 'OT', chaptersCount: 3, abbreviation: 'Jol', romanUrduName: 'Yoel', urduName: 'یوئیل', category: 'Minor Prophets' },
  { id: 'amos', name: 'Amos', testament: 'OT', chaptersCount: 9, abbreviation: 'Amo', romanUrduName: 'Amoos', urduName: 'عاموس', category: 'Minor Prophets' },
  { id: 'obadiah', name: 'Obadiah', testament: 'OT', chaptersCount: 1, abbreviation: 'Oba', romanUrduName: 'Obadiah', urduName: 'عوبدیاہ', category: 'Minor Prophets' },
  { id: 'jonah', name: 'Jonah', testament: 'OT', chaptersCount: 4, abbreviation: 'Jon', romanUrduName: 'Yunas', urduName: 'یونس', category: 'Minor Prophets' },
  { id: 'micah', name: 'Micah', testament: 'OT', chaptersCount: 7, abbreviation: 'Mic', romanUrduName: 'Mika', urduName: 'میکاہ', category: 'Minor Prophets' },
  { id: 'nahum', name: 'Nahum', testament: 'OT', chaptersCount: 3, abbreviation: 'Nam', romanUrduName: 'Nahoom', urduName: 'ناحوم', category: 'Minor Prophets' },
  { id: 'habakkuk', name: 'Habakkuk', testament: 'OT', chaptersCount: 3, abbreviation: 'Hab', romanUrduName: 'Habaqquq', urduName: 'حبقوق', category: 'Minor Prophets' },
  { id: 'zephaniah', name: 'Zephaniah', testament: 'OT', chaptersCount: 3, abbreviation: 'Zep', romanUrduName: 'Saffaniah', urduName: 'صفنیاہ', category: 'Minor Prophets' },
  { id: 'haggai', name: 'Haggai', testament: 'OT', chaptersCount: 2, abbreviation: 'Hag', romanUrduName: 'Hajji', urduName: 'حجی', category: 'Minor Prophets' },
  { id: 'zechariah', name: 'Zechariah', testament: 'OT', chaptersCount: 14, abbreviation: 'Zec', romanUrduName: 'Zakaria', urduName: 'زکریاہ', category: 'Minor Prophets' },
  { id: 'malachi', name: 'Malachi', testament: 'OT', chaptersCount: 4, abbreviation: 'Mal', romanUrduName: 'Malaki', urduName: 'ملاکی', category: 'Minor Prophets' },

  // New Testament (27 Books)
  { id: 'matthew', name: 'Matthew', testament: 'NT', chaptersCount: 28, abbreviation: 'Mat', romanUrduName: 'Matti', urduName: 'متی', category: 'Gospels' },
  { id: 'mark', name: 'Mark', testament: 'NT', chaptersCount: 16, abbreviation: 'Mrk', romanUrduName: 'Marqus', urduName: 'مرقس', category: 'Gospels' },
  { id: 'luke', name: 'Luke', testament: 'NT', chaptersCount: 24, abbreviation: 'Luk', romanUrduName: 'Luqa', urduName: 'لوقا', category: 'Gospels' },
  { id: 'john', name: 'John', testament: 'NT', chaptersCount: 21, abbreviation: 'Jhn', romanUrduName: 'Yuhanna', urduName: 'یوحنا', category: 'Gospels' },
  { id: 'acts', name: 'Acts', testament: 'NT', chaptersCount: 28, abbreviation: 'Act', romanUrduName: 'Rasulon ke Amaal', urduName: 'اعمال', category: 'History' },
  { id: 'romans', name: 'Romans', testament: 'NT', chaptersCount: 16, abbreviation: 'Rom', romanUrduName: 'Romiyon', urduName: 'رومیوں', category: 'Pauline Epistles' },
  { id: '1corinthians', name: '1 Corinthians', testament: 'NT', chaptersCount: 16, abbreviation: '1Co', romanUrduName: '1 Kurinthiyon', urduName: '۱ کرنتھیوں', category: 'Pauline Epistles' },
  { id: '2corinthians', name: '2 Corinthians', testament: 'NT', chaptersCount: 13, abbreviation: '2Co', romanUrduName: '2 Kurinthiyon', urduName: '۲ کرنتھیوں', category: 'Pauline Epistles' },
  { id: 'galatians', name: 'Galatians', testament: 'NT', chaptersCount: 6, abbreviation: 'Gal', romanUrduName: 'Galatiyon', urduName: 'گلتیوں', category: 'Pauline Epistles' },
  { id: 'ephesians', name: 'Ephesians', testament: 'NT', chaptersCount: 6, abbreviation: 'Eph', romanUrduName: 'Afisiyon', urduName: 'افسیوں', category: 'Pauline Epistles' },
  { id: 'philippians', name: 'Philippians', testament: 'NT', chaptersCount: 4, abbreviation: 'Php', romanUrduName: 'Filippiyon', urduName: 'فلپیوں', category: 'Pauline Epistles' },
  { id: 'colossians', name: 'Colossians', testament: 'NT', chaptersCount: 4, abbreviation: 'Col', romanUrduName: 'Kulussiyon', urduName: 'کلسیوں', category: 'Pauline Epistles' },
  { id: '1thessalonians', name: '1 Thessalonians', testament: 'NT', chaptersCount: 5, abbreviation: '1Th', romanUrduName: '1 Thissalunikiya', urduName: '۱ تھسلنیکیوں', category: 'Pauline Epistles' },
  { id: '2thessalonians', name: '2 Thessalonians', testament: 'NT', chaptersCount: 3, abbreviation: '2Th', romanUrduName: '2 Thissalunikiya', urduName: '۲ تھسلنیکیوں', category: 'Pauline Epistles' },
  { id: '1timothy', name: '1 Timothy', testament: 'NT', chaptersCount: 6, abbreviation: '1Ti', romanUrduName: '1 Timitiyus', urduName: '۱ تیمتھیس', category: 'Pauline Epistles' },
  { id: '2timothy', name: '2 Timothy', testament: 'NT', chaptersCount: 4, abbreviation: '2Ti', romanUrduName: '2 Timitiyus', urduName: '۲ تیمتھیس', category: 'Pauline Epistles' },
  { id: 'titus', name: 'Titus', testament: 'NT', chaptersCount: 3, abbreviation: 'Tit', romanUrduName: 'Titus', urduName: 'ططس', category: 'Pauline Epistles' },
  { id: 'philemon', name: 'Philemon', testament: 'NT', chaptersCount: 1, abbreviation: 'Phm', romanUrduName: 'Filemun', urduName: 'فلیمون', category: 'Pauline Epistles' },
  { id: 'hebrews', name: 'Hebrews', testament: 'NT', chaptersCount: 13, abbreviation: 'Heb', romanUrduName: 'Ibraniyon', urduName: 'عبرانیوں', category: 'General Epistles' },
  { id: 'james', name: 'James', testament: 'NT', chaptersCount: 5, abbreviation: 'Jas', romanUrduName: 'Yaqoob', urduName: 'یعقوب', category: 'General Epistles' },
  { id: '1peter', name: '1 Peter', testament: 'NT', chaptersCount: 5, abbreviation: '1Pe', romanUrduName: '1 Patras', urduName: '۱ پطرس', category: 'General Epistles' },
  { id: '2peter', name: '2 Peter', testament: 'NT', chaptersCount: 3, abbreviation: '2Pe', romanUrduName: '2 Patras', urduName: '۲ پطرس', category: 'General Epistles' },
  { id: '1john', name: '1 John', testament: 'NT', chaptersCount: 5, abbreviation: '1Jn', romanUrduName: '1 Yuhanna', urduName: '۱ یوحنا', category: 'General Epistles' },
  { id: '2john', name: '2 John', testament: 'NT', chaptersCount: 1, abbreviation: '2Jn', romanUrduName: '2 Yuhanna', urduName: '۲ یوحنا', category: 'General Epistles' },
  { id: '3john', name: '3 John', testament: 'NT', chaptersCount: 1, abbreviation: '3Jn', romanUrduName: '3 Yuhanna', urduName: '۳ یوحنا', category: 'General Epistles' },
  { id: 'jude', name: 'Jude', testament: 'NT', chaptersCount: 1, abbreviation: 'Jud', romanUrduName: 'Yahudah', urduName: 'یہوداہ', category: 'General Epistles' },
  { id: 'revelation', name: 'Revelation', testament: 'NT', chaptersCount: 22, abbreviation: 'Rev', romanUrduName: 'Mukashafa', urduName: 'مکاشفہ', category: 'Prophecy' },
];

export interface VerseContent {
  verse: number;
  text: string;
  sectionHeading?: string;
}

// Scripture database across translations (Reset state: 0 verses bundled)
export const SCRIPTURE_DATA: Record<string, Record<number, Record<string, VerseContent[]>>> = {
  genesis: {
    1: {
      ur: [
            {
                  "verse": 1,
                  "sectionHeading": "تخلیق کا بیان",
                  "text": "خُدا نے اِبتدا میں زمِین و آسمان کو پَیدا کِیا۔"
            },
            {
                  "verse": 2,
                  "text": "اور زمِین وِیران اور سُنسان تھی اور گہراؤ کے اُوپر اندھیرا تھا اور خُدا کی رُوح پانی کی سطح پر جُنبِش کرتی تھی۔"
            },
            {
                  "verse": 3,
                  "text": "اور خُدا نے کہا کہ رَوشنی ہو جا اور رَوشنی ہو گئی۔"
            },
            {
                  "verse": 4,
                  "text": "اور خُدا نے دیکھا کہ رَوشنی اچھّی ہے اور خُدا نے رَوشنی کو تارِیکی سے جُدا کِیا۔"
            },
            {
                  "verse": 5,
                  "text": "اور خُدا نے رَوشنی کو تو دِن کہا اور تارِیکی کو رات اور شام ہُوئی اور صُبح ہُوئی۔ سو پہلا دِن ہُؤا۔"
            },
            {
                  "verse": 6,
                  "text": "اور خُدا نے کہا کہ پانیوں کے درمیان فضا ہو تاکہ پانی پانی سے جُدا ہو جائے۔"
            },
            {
                  "verse": 7,
                  "text": "پس خُدا نے فضا کو بنایا اور فضا کے نِیچے کے پانی کو فضا کے اُوپر کے پانی سے جُدا کِیا اور اَیسا ہی ہُؤا۔"
            },
            {
                  "verse": 8,
                  "text": "اور خُدا نے فضا کو آسمان کہا اور شام ہُوئی اور صُبح ہُوئی۔ سو دُوسرا دِن ہُؤا۔"
            },
            {
                  "verse": 9,
                  "text": "اور خُدا نے کہا کہ آسمان کے نِیچے کا پانی ایک جگہ جمع ہو کہ خُشکی نظر آئے اور اَیسا ہی ہُؤا۔"
            },
            {
                  "verse": 10,
                  "text": "اور خُدا نے خُشکی کو زمِین کہا اور جو پانی جمع ہو گیا تھا اُس کو سمُندر اور خُدا نے دیکھا کہ اچھّا ہے۔"
            },
            {
                  "verse": 11,
                  "text": "اور خُدا نے کہا کہ زمِین گھاس اور بیِج دار بوٹِیوں کو اور پَھل دار درختوں کو جو اپنی اپنی جِنس کے مُوافِق پَھلیں اور جو زمِین پر اپنے آپ ہی میں بیِج رکھّیں اُگائے اور اَیسا ہی ہُؤا۔"
            },
            {
                  "verse": 12,
                  "text": "تب زمِین نے گھاس اور بوٹِیوں کو جو اپنی اپنی جِنس کے مُوافِق بیِج رکھّیں اور پَھل دار درختوں کو جِن کے بیِج اُن کی جِنس کے مُوافِق اُن میں ہیں اُگایا اور خُدا نے دیکھا کہ اچھّا ہے۔"
            },
            {
                  "verse": 13,
                  "text": "اور شام ہُوئی اور صُبح ہُوئی۔ سو تِیسرا دِن ہُؤا۔"
            },
            {
                  "verse": 14,
                  "text": "اور خُدا نے کہا کہ فلک پر نیّر ہوں کہ دِن کو رات سے الگ کریں اور وہ نِشانوں اور زمانوں اور دِنوں اور برسوں کے اِمتیاز کے لِئے ہوں۔"
            },
            {
                  "verse": 15,
                  "text": "اور وہ فلک پر انوار کے لِئے ہوں کہ زمِین پر رَوشنی ڈالیں اور اَیسا ہی ہُؤا۔"
            },
            {
                  "verse": 16,
                  "text": "سو خُدا نے دو بڑے نیّر بنائے۔ ایک نیّرِ اکبر کہ دِن پر حُکم کرے اور ایک نیّرِ اصغر کہ رات پر حُکم کرے اور اُس نے سِتاروں کو بھی بنایا۔"
            },
            {
                  "verse": 17,
                  "text": "اور خُدا نے اُن کو فلک پر رکھّا کہ زمِین پر رَوشنی ڈالیں۔"
            },
            {
                  "verse": 18,
                  "text": "اور دِن پر اور رات پر حُکم کریں اور اُجالے کو اندھیرے سے جُدا کریں اور خُدا نے دیکھا کہ اچھّا ہے۔"
            },
            {
                  "verse": 19,
                  "text": "اور شام ہُوئی اور صُبح ہُوئی۔ سو چَوتھا دِن ہُؤا۔"
            },
            {
                  "verse": 20,
                  "text": "اور خُدا نے کہا کہ پانی جان داروں کو کثرت سے پَیدا کرے اور پرِندے زمِین کے اُوپر فضا میں اُڑیں۔"
            },
            {
                  "verse": 21,
                  "text": "اور خُدا نے بڑے بڑے دریائی جانوروں کو اور ہر قِسم کے جاندار کو جو پانی سے بکثرت پَیدا ہوئے تھے اُن کی جِنس کے مُوافِق اور ہر قِسم کے پرِندوں کو اُن کی جِنس کے مُوافِق پَیدا کِیا اور خُدا نے دیکھا کہ اچھّا ہے۔"
            },
            {
                  "verse": 22,
                  "text": "اور خُدا نے اُن کو یہ کہہ کر برکت دی کہ پَھلو اور بڑھو اور اِن سمُندروں کے پانی کو بھر دو اور پرِندے زمِین پر بہُت بڑھ جائیں۔"
            },
            {
                  "verse": 23,
                  "text": "اور شام ہُوئی اور صُبح ہُوئی۔ سو پانچواں دِن ہُؤا۔"
            },
            {
                  "verse": 24,
                  "text": "اور خُدا نے کہا کہ زمِین جان داروں کو اُن کی جِنس کے مُوافِق چَوپائے اور رینگنے والے جاندار اور جنگلی جانور اُن کی جِنس کے مُوافِق پَیدا کرے اور اَیسا ہی ہُؤا۔"
            },
            {
                  "verse": 25,
                  "text": "اور خُدا نے جنگلی جانوروں اور چَوپایوں کو اُن کی جِنس کے مُوافِق اور زمِین کے رینگنے والے جان داروں کو اُن کی جِنس کے مُوافِق بنایا اور خُدا نے دیکھا کہ اچھّا ہے۔"
            },
            {
                  "verse": 26,
                  "text": "پِھر خُدا نے کہا کہ ہم اِنسان کو اپنی صُورت پر اپنی شبِیہ کی مانِند بنائیں اور وہ سمُندر کی مچھلیوں اور آسمان کے پرِندوں اور چَوپایوں اور تمام زمِین اور سب جان داروں پر جو زمِین پر رینگتے ہیں اِختیار رکھّیں۔"
            },
            {
                  "verse": 27,
                  "text": "اور خُدا نے اِنسان کو اپنی صُورت پر پَیدا کِیا۔ خُدا کی صُورت پر اُس کو پَیدا کِیا۔ نر و ناری اُن کو پَیدا کِیا۔"
            },
            {
                  "verse": 28,
                  "text": "اور خُدا نے اُن کو برکت دی اور کہا کہ پَھلو اور بڑھو اور زمِین کو معمُور و محکُوم کرو اور سمُندر کی مچھلیوں اور ہوا کے پرِندوں اور کُل جانوروں پر جو زمِین پر چلتے ہیں اِختیار رکھّو۔"
            },
            {
                  "verse": 29,
                  "text": "اور خُدا نے کہا کہ دیکھو مَیں تمام رُویِ زمِین کی کُل بیِج دار سبزی اور ہر درخت جِس میں اُس کا بیِج دار پَھل ہو تُم کو دیتا ہُوں۔ یہ تُمہارے کھانے کو ہوں۔"
            },
            {
                  "verse": 30,
                  "text": "اور زمِین کے کُل جانوروں کے لِئے اور ہوا کے کُل پرِندوں کے لِئے اور اُن سب کے لِئے جو زمِین پر رینگنے والے ہیں جِن میں زِندگی کا دَم ہے کُل ہری بوٹِیاں کھانے کو دیتا ہُوں اور اَیسا ہی ہُؤا۔"
            },
            {
                  "verse": 31,
                  "text": "اور خُدا نے سب پر جو اُس نے بنایا تھا نظر کی اور دیکھا کہ بہت اچھّا ہے اور شام ہُوئی اور صُبح ہُوئی۔ سو چھٹا دِن ہُؤا۔"
            }
      ],
    },
    2: {
      ur: [
            {
                  "verse": 1,
                  "text": "سو آسمان اور زمِین اور اُن کے کُل لشکر کا بنانا ختم ہُؤا۔"
            },
            {
                  "verse": 2,
                  "text": "اور خُدا نے اپنے کام کو جِسے وہ کرتا تھا ساتویں دِن ختم کِیا اور اپنے سارے کام سے جِسے وہ کر رہا تھا ساتویں دِن فارِغ ہُؤا۔"
            },
            {
                  "verse": 3,
                  "text": "اور خُدا نے ساتویں دِن کو برکت دی اور اُسے مُقدّس ٹھہرایا کیونکہ اُس میں خُدا ساری کائِنات سے جِسے اُس نے پَیدا کِیا اور بنایا فارِغ ہُؤا۔"
            },
            {
                  "verse": 4,
                  "sectionHeading": "باغِ عدن",
                  "text": "یہ ہے آسمان اور زمِین کی پَیدایش جب وہ خلق ہُوئے جِس دِن خُداوند خُدا نے زمِین اور آسمان کو بنایا۔"
            },
            {
                  "verse": 5,
                  "text": "اور زمِین پر اب تک کھیت کا کوئی پَودا نہ تھا اور نہ مَیدان کی کوئی سبزی اب تک اُگی تھی کیونکہ خُداوند خُدا نے زمِین پر پانی نہیں برسایا تھا اور نہ زمِین جوتنے کو کوئی اِنسان تھا۔"
            },
            {
                  "verse": 6,
                  "text": "بلکہ زمِین سے کُہر اُٹھتی تھی اور تمام رُویِ زمِین کو سیراب کرتی تھی۔"
            },
            {
                  "verse": 7,
                  "text": "اور خُداوند خُدا نے زمِین کی مِٹّی سے اِنسان کو بنایا اور اُس کے نتھنوں میں زِندگی کا دَم پُھونکا تو اِنسان جِیتی جان ہُؤا۔"
            },
            {
                  "verse": 8,
                  "text": "اور خُداوند خُدا نے مشرِق کی طرف عدن میں ایک باغ لگایا اور اِنسان کو جِسے اُس نے بنایا تھا وہاں رکھّا۔"
            },
            {
                  "verse": 9,
                  "text": "اور خُداوند خُدا نے ہر درخت کو جو دیکھنے میں خُوش نُما اور کھانے کے لِئے اچھّا تھا زمِین سے اُگایا اور باغ کے بیِچ میں حیات کا درخت اور نیک و بَد کی پہچان کا درخت بھی لگایا۔"
            },
            {
                  "verse": 10,
                  "text": "اور عدن سے ایک دریا باغ کے سیراب کرنے کو نِکلا اور وہاں سے چار ندِیوں میں تقسِیم ہُؤا۔"
            },
            {
                  "verse": 11,
                  "text": "پہلی کا نام فیسونؔ ہے جو حویِلہ کی ساری زمِین کو جہاں سونا ہوتا ہے گھیرے ہُوئے ہے۔"
            },
            {
                  "verse": 12,
                  "text": "اور اِس زمِین کا سونا چوکھا ہے اور وہاں موتی اور سنگِ سُلیمانی بھی ہیں۔"
            },
            {
                  "verse": 13,
                  "text": "اور دُوسری ندی کا نام جیحوؔن ہے جو کُوؔش کی ساری زمِین کو گھیرے ہُوئے ہے۔"
            },
            {
                  "verse": 14,
                  "text": "اور تِیسری ندی کا نام دِجلہؔ ہے جو اَسُورؔ کے مشرِق کو جاتی ہے اور چَوتھی ندی کا نام فراتؔ ہے۔"
            },
            {
                  "verse": 15,
                  "text": "اور خُداوند خُدا نے آدمؔ کو لے کر باغِ عدن میں رکھّا کہ اُس کی باغبانی اور نِگہبانی کرے۔"
            },
            {
                  "verse": 16,
                  "text": "اور خُداوند خُدا نے آدمؔ کو حُکم دِیا اور کہا کہ تُو باغ کے ہر درخت کا پَھل بے روک ٹوک کھا سکتا ہے۔"
            },
            {
                  "verse": 17,
                  "text": "لیکن نیک و بَد کی پہچان کے درخت کا کبھی نہ کھانا کیونکہ جِس روز تُو نے اُس میں سے کھایا تُو مَرا۔"
            },
            {
                  "verse": 18,
                  "text": "اور خُداوند خُدا نے کہا کہ آدمؔ کا اکیلا رہنا اچھّا نہیں۔ مَیں اُس کے لِئے ایک مددگار اُس کی مانِند بناؤں گا۔"
            },
            {
                  "verse": 19,
                  "text": "اور خُداوند خُدا نے کُل دشتی جانور اور ہوا کے کُل پرِندے مِٹّی سے بنائے اور اُن کو آدمؔ کے پاس لایا کہ دیکھے کہ وہ اُن کے کیا نام رکھتا ہے اور آدمؔ نے جِس جانور کو جو کہا وُہی اُس کا نام ٹھہرا۔"
            },
            {
                  "verse": 20,
                  "text": "اور آدمؔ نے کُل چَوپایوں اور ہوا کے پرِندوں اور کُل دشتی جانوروں کے نام رکھّے پر آدمؔ کے لِئے کوئی مددگار اُس کی مانِند نہ مِلا۔"
            },
            {
                  "verse": 21,
                  "text": "اور خُداوند خُدا نے آدمؔ پر گہری نِیند بھیجی اور وہ سو گیا اور اُس نے اُس کی پسلیوں میں سے ایک کو نِکال لِیا اور اُس کی جگہ گوشت بھر دِیا۔"
            },
            {
                  "verse": 22,
                  "text": "اور خُداوند خُدا اُس پسلی سے جو اُس نے آدمؔ میں سے نِکالی تھی ایک عَورت بنا کر اُسے آدمؔ کے پاس لایا۔"
            },
            {
                  "verse": 23,
                  "text": "اور آدمؔ نے کہا کہ یہ تو اب میری ہڈِّیوں میں سے ہڈّی اور میرے گوشت میں سے گوشت ہے اِس لِئے وہ ناری کہلائے گی کیونکہ وہ نر سے نِکالی گئی۔"
            },
            {
                  "verse": 24,
                  "text": "اِس واسطے مَرد اپنے ماں باپ کو چھوڑے گا اور اپنی بِیوی سے مِلا رہے گا اور وہ ایک تن ہوں گے۔"
            },
            {
                  "verse": 25,
                  "text": "اور آدمؔ اور اُس کی بِیوی دونوں ننگے تھے اور شرماتے نہ تھے۔"
            }
      ],
    },
    3: {
      ur: [
            {
                  "verse": 1,
                  "sectionHeading": "اِنسان کی نافرمانی",
                  "text": "اور سانپ کُل دشتی جانوروں سے جِن کو خُداوند خُدا نے بنایا تھا چالاک تھا اور اُس نے عَورت سے کہا کیا واقِعی خُدا نے کہا ہے کہ باغ کے کِسی درخت کا پَھل تُم نہ کھانا؟"
            },
            {
                  "verse": 2,
                  "text": "عَورت نے سانپ سے کہا کہ باغ کے درختوں کا پَھل تو ہم کھاتے ہیں۔"
            },
            {
                  "verse": 3,
                  "text": "پر جو درخت باغ کے بیِچ میں ہے اُس کے پَھل کی بابت خُدا نے کہا ہے کہ تُم نہ تو اُسے کھانا اور نہ چُھونا ورنہ مَر جاؤ گے۔"
            },
            {
                  "verse": 4,
                  "text": "تب سانپ نے عَورت سے کہا کہ تُم ہرگِز نہ مَرو گے۔"
            },
            {
                  "verse": 5,
                  "text": "بلکہ خُدا جانتا ہے کہ جِس دِن تُم اُسے کھاؤ گے تُمہاری آنکھیں کُھل جائیں گی اور تُم خُدا کی مانِند نیک و بد کے جاننے والے بن جاؤ گے۔"
            },
            {
                  "verse": 6,
                  "text": "عَورت نے جو دیکھا کہ وہ درخت کھانے کے لِئے اچھّا اور آنکھوں کو خُوش نُما معلُوم ہوتا ہے اور عقل بخشنے کے لِئے خُوب ہے تو اُس کے پَھل میں سے لِیا اور کھایا اور اپنے شَوہر کو بھی دِیا اور اُس نے کھایا۔"
            },
            {
                  "verse": 7,
                  "text": "تب دونوں کی آنکھیں کُھل گئیں اور اُن کو معلُوم ہُؤا کہ وہ ننگے ہیں اور اُنہوں نے انجِیر کے پتّوں کو سی کر اپنے لِئے لُنگِیاں بنائیِں۔"
            },
            {
                  "verse": 8,
                  "text": "اور اُنہوں نے خُداوند خُدا کی آواز جو ٹھنڈے وقت باغ میں پِھرتا تھا سُنی اور آدمؔ اور اُس کی بِیوی نےاپنے آپ کو خُداوند خُدا کے حضُور سے باغ کے درختوں میں چِھپایا۔"
            },
            {
                  "verse": 9,
                  "text": "تب خُداوند خُدا نے آدمؔ کو پُکارا اور اُس سے کہا کہ تُو کہاں ہے؟"
            },
            {
                  "verse": 10,
                  "text": "اُس نے کہا مَیں نے باغ میں تیری آواز سُنی اور مَیں ڈرا کیونکہ مَیں ننگا تھا اور مَیں نے اپنے آپ کو چِھپایا۔"
            },
            {
                  "verse": 11,
                  "text": "اُس نے کہا تُجھے کِس نے بتایا کہ تُو ننگا ہے؟ کیا تُو نے اُس درخت کا پَھل کھایا جِس کی بابت مَیں نے تُجھ کو حُکم دِیا تھا کہ اُسے نہ کھانا؟"
            },
            {
                  "verse": 12,
                  "text": "آدمؔ نے کہا کہ جِس عَورت کو تُو نے میرے ساتھ کِیا ہے اُس نے مُجھے اُس درخت کا پَھل دِیا اور مَیں نے کھایا۔"
            },
            {
                  "verse": 13,
                  "text": "تب خُداوند خُدا نے عَورت سے کہا کہ تُو نے یہ کیا کِیا؟ عَورت نے کہا کہ سانپ نے مُجھ کو بہکایا تو مَیں نے کھایا۔"
            },
            {
                  "verse": 14,
                  "sectionHeading": "خُدا سزا سُناتا ہے",
                  "text": "اور خُداوند خُدا نے سانپ سے کہا اِس لِئے کہ تُو نے یہ کِیا تُو سب چَوپایوں اور دشتی جانوروں میں ملعُون ٹھہرا۔ تُو اپنے پیٹ کے بل چلے گا اور اپنی عُمر بھر خاک چاٹے گا۔"
            },
            {
                  "verse": 15,
                  "text": "اور مَیں تیرے اور عَورت کے درمیان اور تیری نسل اور عَورت کی نسل کے درمِیان عداوت ڈالُوں گا۔ وہ تیرے سر کو کُچلے گا اور تُو اُس کی ایڑی پر کاٹے گا۔"
            },
            {
                  "verse": 16,
                  "text": "پِھر اُس نے عَورت سے کہا کہ مَیں تیرے دردِ حمل کو بُہت بڑھاؤں گا۔ تُو درد کے ساتھ بچّے جنے گی اور تیری رغبت اپنے شَوہر کی طرف ہو گی اور وہ تُجھ پر حُکُومت کرے گا۔"
            },
            {
                  "verse": 17,
                  "text": "اور آدمؔ سے اُس نے کہا چُونکہ تُو نے اپنی بِیوی کی بات مانی اور اُس درخت کا پَھل کھایا جِس کی بابت مَیں نے تُجھے حُکم دِیا تھا کہ اُسے نہ کھانا اِس لِئے زمِین تیرے سبب سے لَعنتی ہُوئی۔ مشقّت کے ساتھ تُو اپنی عُمر بھر اُس کی پَیداوار کھائے گا۔"
            },
            {
                  "verse": 18,
                  "text": "اور وہ تیرے لِئے کانٹے اور اُونٹ کٹارے اُگائے گی اور تُو کھیت کی سبزی کھائے گا۔"
            },
            {
                  "verse": 19,
                  "text": "تُو اپنے مُنہ کے پسِینے کی روٹی کھائے گا جب تک کہ زمِین میں تُو پِھر لَوٹ نہ جائے اِس لِئے کہ تُو اُس سے نِکالا گیا ہے کیونکہ تُو خاک ہے اور خاک میں پِھر لَوٹ جائے گا۔"
            },
            {
                  "verse": 20,
                  "text": "اور آدمؔ نے اپنی بِیوی کا نام حوّؔا رکھّا اِس لِئے کہ وہ سب زِندوں کی ماں ہے۔"
            },
            {
                  "verse": 21,
                  "text": "اور خُداوند خُدا نے آدمؔ اور اُس کی بِیوی کے واسطے چمڑے کے کُرتے بنا کر اُن کو پہنائے۔"
            },
            {
                  "verse": 22,
                  "sectionHeading": "آدمؔ اور حوّاؔ کو باغِ عدن سے نِکالا جاتا ہے",
                  "text": "اور خُداوند خُدا نے کہا دیکھو اِنسان نیک و بَد کی پہچان میں ہم میں سے ایک کی مانِند ہو گیا۔ اب کہِیں اَیسا نہ ہو کہ وہ اپنا ہاتھ بڑھائے اور حیات کے درخت سے بھی کُچھ لے کر کھائے اور ہمیشہ جِیتا رہے۔"
            },
            {
                  "verse": 23,
                  "text": "اِس لِئے خُداوند خُدا نے اُس کو باغِ عدن سے باہر کر دِیا تاکہ وہ اُس زمِین کی جِس میں سے وہ لِیا گیا تھا کھیتی کرے۔"
            },
            {
                  "verse": 24,
                  "text": "چُنانچہ اُس نے آدمؔ کو نِکال دِیا اور باغِ عدن کے مشرِق کی طرف کرُّوبِیوں کو اور چَوگرد گُھومنے والی شُعلہ زن تلوار کو رکھّا کہ وہ زِندگی کے درخت کی راہ کی حِفاظت کریں۔"
            }
      ],
    },
    4: {
      ur: [
            {
                  "verse": 1,
                  "sectionHeading": "قائنؔ اور ہابلؔ",
                  "text": "اور آدمؔ اپنی بِیوی حوّاؔ کے پاس گیا اور وہ حامِلہ ہُوئی اور اُس کے قائِنؔ پَیدا ہُؤا۔ تب اُس نے کہا مُجھے خُداوند سے ایک مَرد مِلا۔"
            },
            {
                  "verse": 2,
                  "text": "پِھر قائِنؔ کا بھائی ہابلؔ پَیدا ہُؤا اور ہابلؔ بھیڑ بکرِیوں کا چرواہا اور قائِنؔ کسان تھا۔"
            },
            {
                  "verse": 3,
                  "text": "چند روز کے بعد یُوں ہُؤا کہ قائِنؔ اپنے کھیت کے پَھل کا ہدیہ خُداوند کے واسطے لایا۔"
            },
            {
                  "verse": 4,
                  "text": "اور ہابلؔ بھی اپنی بھیڑ بکرِیوں کے کُچھ پہلوٹھے بچّوں کا اور کُچھ اُن کی چربی کا ہدیہ لایا اور خُداوند نے ہابلؔ کو اور اُس کے ہدیہ کو منظُور کِیا۔"
            },
            {
                  "verse": 5,
                  "text": "پر قائِنؔ کو اور اُس کے ہدیہ کو منظُور نہ کِیا اِس لِئے قائِنؔ نِہایت غضب ناک ہُؤا اور اُس کا مُنہ بِگڑا۔"
            },
            {
                  "verse": 6,
                  "text": "اور خُداوند نے قائِنؔ سے کہا تُو کیوں غضب ناک ہُؤا؟ اور تیرا مُنہ کیوں بِگڑا ہُؤا ہے؟"
            },
            {
                  "verse": 7,
                  "text": "اگر تُو بھلا کرے تو کیا تُو مقبُول نہ ہو گا؟ اور اگر تُو بھلا نہ کرے تو گُناہ دروازہ پر دبکا بَیٹھا ہے اور تیرا مُشتاق ہے پر تُو اُس پر غالِب آ۔"
            },
            {
                  "verse": 8,
                  "text": "اور قائِنؔ نے اپنے بھائی ہابلؔ کو کُچھ کہا اور جب وہ دونوں کھیت میں تھے تو یُوں ہُؤا کہ قائِنؔ نے اپنے بھائی ہابلؔ پر حملہ کِیا اور اُسے قتل کر ڈالا۔"
            },
            {
                  "verse": 9,
                  "text": "تب خُداوند نے قائِنؔ سے کہا کہ تیرا بھائی ہابلؔ کہاں ہے؟ اُس نے کہا مُجھے معلُوم نہیں۔ کیا مَیں اپنے بھائی کا مُحافِظ ہُوں؟"
            },
            {
                  "verse": 10,
                  "text": "پِھر اُس نے کہا کہ تُو نے یہ کیا کِیا؟ تیرے بھائی کا خُون زمِین سے مُجھ کو پُکارتا ہے۔"
            },
            {
                  "verse": 11,
                  "text": "اور اب تُو زمِین کی طرف سے لَعنتی ہُؤا۔ جِس نے اپنا مُنہ پسارا کہ تیرے ہاتھ سے تیرے بھائی کا خُون لے۔"
            },
            {
                  "verse": 12,
                  "text": "جب تُو زمِین کو جوتے گا تو وہ اب تُجھے اپنی پَیداوار نہ دے گی اور زمِین پر تُو خانہ خراب اور آوارہ ہو گا۔"
            },
            {
                  "verse": 13,
                  "text": "تب قائِنؔ نے خُداوند سے کہا کہ میری سزا برداشت سے باہر ہے۔"
            },
            {
                  "verse": 14,
                  "text": "دیکھ آج تُو نے مُجھے رُویِ زمِین سے نِکال دِیا ہے اور مَیں تیرے حضُور سے رُوپوش ہو جاؤں گا اور زمِین پر خانہ خراب اور آوارہ رہُوں گا اور اَیسا ہو گا کہ جو کوئی مُجھے پائے گا قتل کر ڈالے گا۔"
            },
            {
                  "verse": 15,
                  "text": "تب خُداوند نے اُسے کہا نہیں بلکہ جو قائِنؔ کو قتل کرے اُس سے سات گُنا بدلہ لِیا جائے گا اور خُداوند نے قائِنؔ کے لِئے ایک نِشان ٹھہرایا کہ کوئی اُسے پا کر مار نہ ڈالے۔"
            },
            {
                  "verse": 16,
                  "text": "سو قائِنؔ خُداوند کے حضُور سے نِکل گیا اور عدن کے مشرِق کی طرف نُود کے عِلاقہ میں جا بسا۔"
            },
            {
                  "verse": 17,
                  "sectionHeading": "قائِنؔ کی نسل",
                  "text": "اور قائِنؔ اپنی بِیوی کے پاس گیا اور وہ حامِلہ ہُوئی اور اُس کے حنُوؔک پَیدا ہُؤا اور اُس نے ایک شہر بسایا اور اُس کا نام اپنے بیٹے کے نام پر حنُوکؔ رکھّا۔"
            },
            {
                  "verse": 18,
                  "text": "اور حنُوکؔ سے عیراؔد پَیدا ہُؤا اور عیرادؔ سے محویاؔایل پَیدا ہُؤا اور محویااؔیل سے متوسا ایلؔ پَیدا ہُؤا اور متوسا ایلؔ سے لمکؔ پَیدا ہُؤا۔"
            },
            {
                  "verse": 19,
                  "text": "اور لمکؔ دو عَورتیں بیاہ لایا۔ ایک کا نام عدّہؔ اور دُوسری کا نام ضِلّہ ؔتھا۔"
            },
            {
                  "verse": 20,
                  "text": "اور عدّہؔ کے یابلؔ پَیدا ہُؤا۔ وہ اُن کا باپ تھا جو خَیموں میں رہتے اور جانور پالتے ہیں۔"
            },
            {
                  "verse": 21,
                  "text": "اور اُس کے بھائی کا نام یوبلؔ تھا۔ وہ بِین اور بانسلی بجانے والوں کا باپ تھا۔"
            },
            {
                  "verse": 22,
                  "text": "اور ضِلّہؔ کے بھی توبلقائِنؔ پَیدا ہُؤا جو پِیتل اور لوہے کے سب تیز ہتھیاروں کا بنانے والا تھا اور نعمہ توبلقائِنؔ کی بہن تھی۔"
            },
            {
                  "verse": 23,
                  "text": "اور لمکؔ نے اپنی بِیویوں سے کہا کہ\nاَے عدّہؔ اور ضِلّہؔ میری بات سُنو\nاَے لمکؔ کی بِیویو میرے سخن پر کان لگاؤ۔\nمَیں نے ایک مَرد کو جِس نے مُجھے زخمی کِیا مار ڈالا اور ایک جوان کو جِس نے میرے چوٹ لگائی قتل کر ڈالا۔"
            },
            {
                  "verse": 24,
                  "text": "اگر قائِنؔ کا بدلہ سات گُنا لِیا جائے گا\nتو لمکؔ کا ستّر اور سات گُنا۔"
            },
            {
                  "verse": 25,
                  "sectionHeading": "سیتؔ ا ورانُوسؔ",
                  "text": "اور آدمؔ پِھر اپنی بِیوی کے پاس گیا اور اُس کے ایک اَور بیٹا ہُؤا اور اُس کا نام سیتؔ رکھّا اور وہ کہنے لگی کہ خُدا نے ہابلؔ کے عِوض جِس کو قائِنؔ نے قتل کِیا مُجھے دُوسرا فرزند دِیا۔"
            },
            {
                  "verse": 26,
                  "text": "اور سیتؔ کے ہاں بھی ایک بیٹا پَیدا ہُؤا جِس کا نام اُس نے انُوس رکھّا۔ اُس وقت سے لوگ یہوواؔہ کا نام لے کر دُعا کرنے لگے۔"
            }
      ],
    },
    5: {
      ur: [
        {
          verse: 1,
          sectionHeading: "آدمؔ کی نسل",
          text: "یہ آدمؔ کا نسب نامہ ہے۔ جِس دِن خُدا نے آدمؔ کو پَیدا کِیا تو اُسے اپنی شبِیہ پر بنایا۔",
        },
        {
          verse: 2,
          text: "نر اور ناری اُن کو پَیدا کِیا اور اُن کو برکت دی اور جِس روز وہ خلق ہُوئے اُن کا نام آدمؔ رکھّا۔",
        },
        {
          verse: 3,
          text: "اور آدمؔ ایک سَو تِیس برس کا تھا جب اُس کی صُورت و شبِیہ کا ایک بیٹا اُس کے ہاں پَیدا ہُؤا اور اُس نے اُس کا نام سیتؔ رکھّا۔",
        },
        {
          verse: 4,
          text: "اور سیتؔ کی پَیدایش کے بعد آدمؔ آٹھ سَو برس جِیتا رہا اور اُس سے بیٹے اور بیٹیاں پَیدا ہُوئیں۔",
        },
        {
          verse: 5,
          text: "اور آدمؔ کی کُل عُمر نو سَو تِیس برس کی ہُوئی۔ تب وہ مَرا۔",
        },
        {
          verse: 6,
          text: "اور سیتؔ ایک سَو پانچ برس کا تھا جب اُس سے انُوسؔ پَیدا ہُؤا۔",
        },
        {
          verse: 7,
          text: "اور انُوسؔ کی پَیدایش کے بعد سیتؔ آٹھ سَو سات برس جِیتا رہا اور اُس سے بیٹے اور بیٹِیاں پَیدا ہُوئیں۔",
        },
        {
          verse: 8,
          text: "اور سیتؔ کی کُل عُمر نو سَو بارہ برس کی ہُوئی۔ تب وہ مَرا۔",
        },
        {
          verse: 9,
          text: "اور انُوسؔ نوّے برس کا تھا جب اُس سے قِینانؔ پَیدا ہُؤا۔",
        },
        {
          verse: 10,
          text: "اور قِینانؔ کی پَیدایش کے بعد انُوسؔ آٹھ سَو پندرہ برس جِیتا رہا اور اُس سے بیٹے اور بیٹِیاں پَیدا ہُوئیِں۔",
        },
        {
          verse: 11,
          text: "اور انُوسؔ کی کُل عُمر نو سَو پانچ برس کی ہُوئی۔ تب وہ مَرا۔",
        },
        {
          verse: 12,
          text: "اور قِینانؔ ستّر برس کا تھا جب اُس سے مَحَلَل ایلؔ پَیدا ہُؤا۔",
        },
        {
          verse: 13,
          text: "اور مَحَلَل ایلؔ کی پَیدایش کے بعد قِینانؔ آٹھ سَو چالِیس برس جِیتا رہا اور اُس سے بیٹے اور بیٹِیاں پَیدا ہُوئیِں۔",
        },
        {
          verse: 14,
          text: "اور قِینانؔ کی کُل عُمر نو سَو دس برس کی ہُوئی۔ تب وہ مَرا۔",
        },
        {
          verse: 15,
          text: "اور مَحَلَل ایلؔ پَینسٹھ برس کا تھا جب اُس سے یارد پَیدا ہُؤا۔",
        },
        {
          verse: 16,
          text: "اور یارد کی پَیدایش کے بعد مَحَلَل ایلؔ آٹھ سَو تِیس برس جِیتا رہا اور اُس سے بیٹے اور بیٹِیاں پَیدا ہُوئیِں۔",
        },
        {
          verse: 17,
          text: "اور مَحَلَل ایلؔ کی کُل عُمر آٹھ سَو پچانوے برس کی ہُوئی۔ تب وہ مَرا۔",
        },
        {
          verse: 18,
          text: "اور یارد ایک سَو باسٹھ برس کا تھا جب اُس سے حنُوؔک پَیدا ہُؤا۔",
        },
        {
          verse: 19,
          text: "اور حنُوؔک کی پَیدایش کے بعد یارد آٹھ سَو برس جِیتا رہا اور اُس سے بیٹے اور بیٹِیاں پَیدا ہُوئیِں۔",
        },
        {
          verse: 20,
          text: "اور یارد کی کُل عُمر نو سَو باسٹھ برس کی ہُوئی۔ تب وہ مَرا۔",
        },
        {
          verse: 21,
          text: "اور حنُوؔک پَینسٹھ برس کا تھا جب اُس سے متوسِلح ؔپَیدا ہُؤا۔",
        },
        {
          verse: 22,
          text: "اور متوسِلحؔ کی پَیدایش کے بعد حنُوؔک تِین سَو برس تک خُدا کے ساتھ ساتھ چلتا رہا اور اُس سے بیٹے اور بیٹِیاں پَیدا ہُوئیِں۔",
        },
        {
          verse: 23,
          text: "اور حنُوؔک کی کُل عُمر تِین سَو پَینسٹھ برس کی ہُوئی۔",
        },
        {
          verse: 24,
          text: "اور حنُوؔک خُدا کے ساتھ ساتھ چلتا رہا اور وہ غائِب ہو گیا کیونکہ خُدا نے اُسے اُٹھا لِیا۔",
        },
        {
          verse: 25,
          text: "اور متوسِلحؔ ایک سَو ستاسی برس کا تھا جب اُس سے لمکؔ پَیدا ہُؤا۔",
        },
        {
          verse: 26,
          text: "اور لمکؔ کی پَیدایش کے بعد متوسِلحؔ سات سَو بیاسی برس جِیتا رہا اور اُس سے بیٹے اور بیٹِیاں پَیدا ہُوئیِں۔",
        },
        {
          verse: 27,
          text: "اور متوسِلحؔ کی کُل عُمر نو سَو اُنہتر برس کی ہُوئی۔ تب وہ مَرا۔",
        },
        {
          verse: 28,
          text: "اور لمکؔ ایک سَو بیاسی برس کا تھا جب اُس سے ایک بیٹا پَیدا ہُؤا۔",
        },
        {
          verse: 29,
          text: "اور اُس نے اُس کا نام نُوحؔ رکھّا اور کہا کہ یہ ہمارے ہاتھوں کی مِحنت اور مشقّت سے جو زمِین کے سبب سے ہے جِس پر خُدا نے لَعنت کی ہے ہمیں آرام دے گا۔",
        },
        {
          verse: 30,
          text: "اور نُوحؔ کی پَیدایش کے بعد لمکؔ پانچ سَو پچانوے برس جِیتا رہا اور اُس سے بیٹے اور بیٹِیاں پَیدا ہُوئیِں۔",
        },
        {
          verse: 31,
          text: "اور لمکؔ کی کُل عُمر سات سَو سَتتَّر برس کی ہُوئی۔ تب وہ مَرا۔",
        },
        {
          verse: 32,
          text: "اور نُوحؔ پانچ سَو برس کا تھا جب اُس سے سم، حام اور یافت پَیدا ہُوئے۔",
        },
      ],
    },
    6: {
      ur: [
        {
          verse: 1,
          sectionHeading: "اِنسان کی بدی",
          text: "جب رُویِ زمِین پر آدمی بُہت بڑھنے لگے اور اُن کے بیٹیاں پَیدا ہُوئیِں۔",
        },
        {
          verse: 2,
          text: "تو خُدا کے بیٹوں نے آدمی کی بیٹیوں کو دیکھا کہ وہ خُوب صُورت ہیں اور جِن کو اُنہوں نے چُنا اُن کو اپنی بیویاں بنا لِیا۔",
        },
        {
          verse: 3,
          text: "اور خُداوند نے کہا کہ میری رُوح اِنسان کے ساتھ ہمیشہ خَفا نہ رہے گی کیونکہ وہ بھی تو بشر ہے تَو بھی اُس کی عُمر ایک سَو بِیس برس کی ہو گی۔",
        },
        {
          verse: 4,
          text: "اُن دِنوں میں زمِین پر جبّار تھے اور بعد میں بھی جب خُدا کے بیٹے بنی آدم کی بیٹیوں کے پاس گئے تو اُن کے لِئے اُن سے بچّے پَیدا ہُوئے۔ یہ وُہی قَدِیم زمانہ کے سورما ہیں جو نامور ہُوئے ہیں۔",
        },
        {
          verse: 5,
          text: "اور خُداوند نے دیکھا کہ زمِین پر اِنسان کی بدی بُہت بڑھ گئی اور اُس کے دِل کے تصوّر کے سب اِرادے اور خیال سدا بُرے ہی ہوتے ہیں۔",
        },
        {
          verse: 6,
          text: "تب خُداوند زمِین پر اِنسان کو پَیدا کرنے سے ملُول ہُؤا اور دِل میں غم کِیا۔",
        },
        {
          verse: 7,
          text: "اور خُداوند نے کہا کہ مَیں اِنسان کو جِسے مَیں نے پَیدا کِیا رُویِ زمِین پر سے مِٹا ڈالُوں گا۔ اِنسان سے لے کر حَیوان اور رینگنے والے جاندار اور ہوا کے پرِندوں تک کیونکہ مَیں اُن کے بنانے سے ملُول ہُوں۔",
        },
        {
          verse: 8,
          text: "مگر نُوحؔ خُداوند کی نظر میں مقبُول ہُؤا۔",
        },
        {
          verse: 9,
          sectionHeading: "نُوحؔ",
          text: "نُوحؔ کا نسب نامہ یہ ہے۔ نُوحؔ مَردِ راست باز اور اپنے زمانہ کے لوگوں میں بے عَیب تھا اور نُوحؔ خُدا کے ساتھ ساتھ چلتا رہا۔",
        },
        {
          verse: 10,
          text: "اور اُس سے تِین بیٹے سِمؔ حامؔ اور یافتؔ پَیدا ہُوئے۔",
        },
        {
          verse: 11,
          text: "پر زمِین خُدا کے آگے ناراست ہو گئی تھی اور وہ ظُلم سے بھری تھی۔",
        },
        {
          verse: 12,
          text: "اور خُدا نے زمِین پر نظر کی اور دیکھا کہ وہ ناراست ہو گئی ہے کیونکہ ہر بشر نے زمِین پر اپنا طرِیقہ بِگاڑ لِیا تھا۔",
        },
        {
          verse: 13,
          text: "اور خُدا نے نُوحؔ سے کہا کہ تمام بشر کا خاتِمہ میرے سامنے آ پُہنچا ہے کیونکہ اُن کے سبب سے زمِین ظُلم سے بھر گئی۔ سو دیکھ مَیں زمِین سمیت اُن کو ہلاک کرُوں گا۔",
        },
        {
          verse: 14,
          text: "تُو گوپھر کی لکڑی کی ایک کشتی اپنے لِئے بنا۔ اُس کشتی میں کوٹھرِیاں تیّار کرنا اور اُس کے اندر اور باہر رال لگانا۔",
        },
        {
          verse: 15,
          text: "اور اَیسا کرنا کہ کشتی کی لمبائی تِین سَو ہاتھ۔ اُس کی چَوڑائی پچاس ہاتھ اور اُس کی اُونچائی تِیس ہاتھ ہو۔",
        },
        {
          verse: 16,
          text: "اور اُس کشتی میں ایک رَوشن دان بنانا اور اُوپر سے ہاتھ بھر چھوڑ کر اُسے ختم کر دینا اور اُس کشتی کا دروازہ اُس کے پہلُو میں رکھنا اور اُس میں تِین درجے بنانا۔ نِچلا۔ دُوسرا اور تِیسرا۔",
        },
        {
          verse: 17,
          text: "اور دیکھ مَیں خود زمِین پر پانی کا طُوفان لانے والا ہُوں تاکہ ہر بشر کو جِس میں زِندگی کا دَم ہے دُنیا سے ہلاک کر ڈالُوں اور سب جو زمِین پر ہیں مَر جائیں گے۔",
        },
        {
          verse: 18,
          text: "پر تیرے ساتھ مَیں اپنا عہد قائِم کرُوں گا اور تُو کشتی میں جانا۔ تُو اور تیرے ساتھ تیرے بیٹے اور تیری بِیوی اور تیرے بیٹوں کی بِیویاں۔",
        },
        {
          verse: 19,
          text: "اور جانوروں کی ہر قِسم میں سے دو دو اپنے ساتھ کشتی میں لے لینا کہ وہ تیرے ساتھ جیتے بچیں۔ وہ نر و مادہ ہوں۔",
        },
        {
          verse: 20,
          text: "اور پرِندوں کی ہر قِسم میں سے اور چرندوں کی ہر قِسم میں سے اور زمِین پر رینگنے والوں کی ہر قِسم میں سے دو دو تیرے پاس آئیں تاکہ وہ جِیتے بچیں۔",
        },
        {
          verse: 21,
          text: "اور تُو ہر طرح کی کھانے کی چِیز لے کر اپنے پاس جمع کر لینا کیونکہ یِہی تیرے اور اُن کے کھانے کو ہو گا۔",
        },
        {
          verse: 22,
          text: "اور نُوحؔ نے یُوں ہی کِیا۔ جَیسا خُدا نے اُسے حُکم دِیا تھا وَیسا ہی عمل کِیا۔",
        },
      ],
    },
    7: {
      ur: [
        {
          verse: 1,
          sectionHeading: "طُوفان",
          text: "اور خُداوند نے نُوحؔ سے کہا کہ تُو اپنے پُورے خاندان کے ساتھ کشتی میں آ کیونکہ مَیں نے تُجھی کو اپنے سامنے اِس زمانہ میں راست باز دیکھا ہے۔",
        },
        {
          verse: 2,
          text: "کُل پاک جانوروں میں سے سات سات نر اور اُن کی مادہ اور اُن میں سے جو پاک نہیں ہیں دو دو نر اور اُن کی مادہ اپنے ساتھ لے لینا۔",
        },
        {
          verse: 3,
          text: "اور ہوا کے پرِندوں میں سے بھی سات سات نر اور مادہ لینا تاکہ زمِین پر اُن کی نسل باقی رہے۔",
        },
        {
          verse: 4,
          text: "کیونکہ سات دِن کے بعد مَیں زمِین پر چالِیس دِن اور چالِیس رات پانی برساؤں گا اور ہر جاندار شَے کو جِسے مَیں نے بنایا زمِین پر سے مِٹا ڈالُوں گا۔",
        },
        {
          verse: 5,
          text: "اور نُوح نے وہ سب جَیسا خُداوند نے اُسے حُکم دِیا تھا کِیا۔",
        },
        {
          verse: 6,
          text: "اور نُوح چھ سَو برس کا تھا جب پانی کا طُوفان زمِین پر آیا۔",
        },
        {
          verse: 7,
          text: "تب نُوح اور اُس کے بیٹے اور اُس کی بِیوی اور اُس کے بیٹوں کی بِیویاں اُس کے ساتھ طُوفان کے پانی سے بچنے کے لِئے کشتی میں گئے۔",
        },
        {
          verse: 8,
          text: "اور پاک جانوروں میں سے اور اُن جانوروں میں سے جو پاک نہیں اور پرِندوں میں سے اور زمِین پر کے ہر رینگنے والے جاندار میں سے۔",
        },
        {
          verse: 9,
          text: "دو دو نر اور مادہ کشتی میں نُوحؔ کے پاس گئے جَیسا خُدا نے نُوحؔ کو حُکم دِیا تھا۔",
        },
        {
          verse: 10,
          text: "اور سات دِن کے بعد اَیسا ہُؤا کہ طُوفان کا پانی زمِین پر آ گیا۔",
        },
        {
          verse: 11,
          text: "نُوحؔ کی عُمر کا چھ سَواں سال تھا کہ اُس کے دُوسرے مہِینے کی ٹِھیک سترھویں تارِیخ کو بڑے سمُندر کے سب سوتے پُھوٹ نِکلے اور آسمان کی کِھڑکِیاں کُھل گئیں۔",
        },
        {
          verse: 12,
          text: "اور چالِیس دِن اور چالِیس رات زمِین پر بارِش ہوتی رہی۔",
        },
        {
          verse: 13,
          text: "اُسی روز نُوحؔ اور نُوحؔ کے بیٹے سِمؔ اور حامؔ اور یافتؔ اور نُوح کی بِیوی اور اُس کے بیٹوں کی تینوں بِیویاں۔",
        },
        {
          verse: 14,
          text: "اور ہر قِسم کا جانور اور ہر قِسم کا چَوپایہ اور ہر قِسم کا زمِین پر کا رینگنے والا جاندار اور ہر قِسم کا پرِندہ اور ہر قِسم کی چِڑیا یہ سب کشتی میں داخِل ہُوئے۔",
        },
        {
          verse: 15,
          text: "اور جو زِندگی کا دَم رکھتے ہیں اُن میں سے دو دو کشتی میں نُوحؔ کے پاس آئے۔",
        },
        {
          verse: 16,
          text: "اور جو اندر آئے وہ جَیسا خُدا نے اُسے حُکم دِیا تھا سب جانوروں کے نر و مادہ تھے۔ تب خُداوند نے اُس کو باہر سے بند کر دِیا۔",
        },
        {
          verse: 17,
          text: "اور چالِیس دِن تک زمِین پر طُوفان رہا اور پانی بڑھا اور اُس نے کشتی کو اُوپر اُٹھا دِیا۔ سو کشتی زمِین پر سے اُٹھ گئی۔",
        },
        {
          verse: 18,
          text: "اور پانی زمِین پر چڑھتا ہی گیا اور بُہت بڑھا اور کشتی پانی کے اُوپر تَیرتی رہی۔",
        },
        {
          verse: 19,
          text: "اور پانی زمِین پر بُہت ہی زِیادہ چڑھا اور سب اُونچے پہاڑ جو دُنیا میں ہیں چُھپ گئے۔",
        },
        {
          verse: 20,
          text: "پانی اُن سے پندرہ ہاتھ اَور اُوپر چڑھا اور پہاڑ ڈُوب گئے۔",
        },
        {
          verse: 21,
          text: "اور سب جانور جو زمِین پر چلتے تھے پرِندے اور چَوپائے اور جنگلی جانور اور زمِین پر کے سب رینگنے والے جاندار اور سب آدمی مَر گئے۔",
        },
        {
          verse: 22,
          text: "اور خُشکی کے سب جاندار جِن کے نتھنوں میں زِندگی کا دَم تھا مَر گئے۔",
        },
        {
          verse: 23,
          text: "بلکہ ہر جاندار شَے جو رُویِ زمِین پر تھی مَر مِٹی۔ کیا اِنسان کیا حَیوان۔ کیا رینگنے والا جاندار کیا ہوا کا پرِندہ یہ سب کے سب زمِین پر سے مَر مِٹے۔ فقط ایک نُوح باقی بچایا وہ جو اُس کے ساتھ کشتی میں تھے۔",
        },
        {
          verse: 24,
          text: "اور پانی زمِین پر ایک سَو پچاس دِن تک چڑھتا رہا۔",
        },
      ],
    },
    8: {
      ur: [
        {
          verse: 1,
          sectionHeading: "طُوفان کا خاتمہ",
          text: "پِھر خُدا نے نُوحؔ کو اور کُل جان داروں اور کُل چَوپایوں کو جو اُس کے ساتھ کشتی میں تھے یاد کِیا اور خُدا نے زمِین پر ایک ہوا چلائی اور پانی رُک گیا۔",
        },
        {
          verse: 2,
          text: "اور سمُندر کے سوتے اور آسمان کے درِیچے بند کِئے گئے اور آسمان سے جو بارِش ہو رہی تھی تھم گئی۔",
        },
        {
          verse: 3,
          text: "اور پانی زمِین پر سے گھٹتے گھٹتے ایک سَو پچاس دِن کے بعد کم ہُؤا۔",
        },
        {
          verse: 4,
          text: "اور ساتویں مہِینے کی سترھویں تارِیخ کو کشتی اَراراؔط کے پہاڑوں پر ٹِک گئی۔",
        },
        {
          verse: 5,
          text: "اور پانی دسویں مہینے تک برابر گھٹتا رہا اور دسویں مہِینے کی پہلی تارِیخ کو پہاڑوں کی چوٹِیاں نظر آئیِں۔",
        },
        {
          verse: 6,
          text: "اور چالِیس دِن کے بعد یُوں ہُؤا کہ نُوحؔ نے کشتی کی کھِڑکی جو اُس نے بنائی تھی کھولی۔",
        },
        {
          verse: 7,
          text: "اور اُس نے ایک کوّے کو اُڑا دِیا۔ سو وہ نِکلا اور جب تک کہ زمِین پر سے پانی سُوکھ نہ گیا اِدھر اُدھر پِھرتا رہا۔",
        },
        {
          verse: 8,
          text: "پِھر اُس نے ایک کبُوتری اپنے پاس سے اُڑا دی تاکہ دیکھے کہ زمِین پر پانی گھٹا یا نہیں۔",
        },
        {
          verse: 9,
          text: "پر کبُوتری نے پنجہ ٹیکنے کی جگہ نہ پائی اور اُس کے پاس کشتی کو لَوٹ آئی کیونکہ تمام رُویِ زمِین پر پانی تھا۔ تب اُس نے ہاتھ بڑھا کر اُسے لے لِیا اور اپنے پاس کشتی میں رکھّا۔",
        },
        {
          verse: 10,
          text: "اور سات دِن ٹھہر کر اُس نے اُس کبُوتری کو پِھر کشتی سے اُڑا دِیا۔",
        },
        {
          verse: 11,
          text: "اور وہ کبُوتری شام کے وقت اُس کے پاس لَوٹ آئی اور دیکھا تو زَیتُونؔ کی ایک تازہ پتّی اُس کی چونچ میں تھی۔ تب نُوحؔ نے معلُوم کِیا کہ پانی زمِین پر سے کم ہو گیا۔",
        },
        {
          verse: 12,
          text: "تب وہ سات دِن اور ٹھہرا۔ اِس کے بعد پِھر اُس کبُوتری کو اُڑایا پر وہ اُس کے پاس پِھر کبھی نہ لَوٹی۔",
        },
        {
          verse: 13,
          text: "اور چھ سَو پہلے برس کے پہلے مہِینے کی پہلی تارِیخ کو یُوں ہُؤا کہ زمِین پر سے پانی سُوکھ گیا اور نُوح نے کشتی کی چھت کھولی اور دیکھا کہ زمِین کی سطح سُوکھ گئی ہے۔",
        },
        {
          verse: 14,
          text: "اور دُوسرے مہِینے کی ستائِیسویں تارِیخ کو زمِین بِالکُل سُوکھ گئی۔",
        },
        {
          verse: 15,
          text: "تب خُدا نے نُوحؔ سے کہا کہ",
        },
        {
          verse: 16,
          text: "کشتی سے باہر نِکل آ۔ تُو اور تیرے ساتھ تیری بِیوی اور تیرے بیٹے اور تیرے بیٹوں کی بِیویاں۔",
        },
        {
          verse: 17,
          text: "اور اُن جان داروں کو بھی باہر نِکال لا جو تیرے ساتھ ہیں کیا پرِندے کیا چَوپائے کیا زمِین کے رینگنے والے جاندار تاکہ وہ زمِین پر کثرت سے بچّے دیں اور باروَر ہوں اور زمِین پر بڑھ جائیں۔",
        },
        {
          verse: 18,
          text: "تب نُوح اپنی بِیوی اور اپنے بیٹوں اور اپنے بیٹوں کی بِیویوں کے ساتھ باہر نِکلا۔",
        },
        {
          verse: 19,
          text: "اور سب جانور سب رینگنے والے جاندار۔ سب پرِندے اور سب جو زمِین پر چلتے ہیں اپنی اپنی جِنس کے ساتھ کشتی سے نِکل گئے۔",
        },
        {
          verse: 20,
          sectionHeading: "نُوحؔ قُربانی چڑھاتا ہے",
          text: "تب نُوحؔ نے خُداوند کے لِئے ایک مذبح بنایا اور سب پاک چَوپایوں اور پاک پرِندوں میں سے تھوڑے سے لے کر اُس مذبح پر سوختنی قُربانِیاں چڑھائیِں۔",
        },
        {
          verse: 21,
          text: "اور خُداوند نے اُن کی راحت انگیز خُوشبو لی اور خُداوند نے اپنے دِل میں کہا کہ اِنسان کے سبب سے مَیں پِھر کبھی زمِین پر لَعنت نہیں بھیجوں گا کیونکہ اِنسان کے دِل کا خیال لڑکپن سے بُرا ہے اور نہ پِھر سب جان داروں کو جَیسا اب کِیا ہے مارُوں گا۔",
        },
        {
          verse: 22,
          text: "بلکہ جب تک زمِین قائِم ہے بیِج بونا اور فصل کاٹنا۔ سردی اور تپش۔ گرمی اور جاڑا دِن اور رات مَوقُوف نہ ہوں گے۔",
        },
      ],
    },
    9: {
      ur: [
        {
          verse: 1,
          sectionHeading: "نُوحؔ کے ساتھ خُدا کا عہد",
          text: "اور خُدا نے نُوح ؔاور اُس کے بیٹوں کو برکت دی اور اُن کو کہا کہ باروَر ہو اور بڑھو اور زمِین کو معمُور کرو۔",
        },
        {
          verse: 2,
          text: "اور زمِین کے سب جانور اور ہوا کے سب پرِندے اور سب رینگنے والے جاندار اور سمُندر کی سب مچھلِیاں تم سے ڈرتی اور کانپتی رہیں گی کیونکہ وہ تمہارے ہاتھ میں کر دِئے گئے ہیں۔",
        },
        {
          verse: 3,
          text: "ہر ایک متحرِک جان دار تمہارے کھانے کو ہو گا۔ جِس طرح مَیں نے سَبز پودے دِئے تھے اُسی طرح اب سب کُچھ دِیا۔",
        },
        {
          verse: 4,
          text: "مگر گوشت کے ساتھ اُس کا خُون جو اُس کی جان ہے مت کھانا۔",
        },
        {
          verse: 5,
          text: "اور تمہارے خُون کا جو تمہاری جان ہے مَیں ضرُور بدلہ لُوں گا۔ ہر جانور سے لُوں گا اور اِنسان سے بھی لُوں گا۔ ہاں ہر ایک سے اُس کے بھائی کے خُون کا بدلہ لُوں گا۔",
        },
        {
          verse: 6,
          text: "جو اِنسان کا خُون کرے گا اُس کا خُون اِنسان کے ہاتھ سے بہے گا کیونکہ خُدا نے اِنسان کو اپنی ہی صُورت پر بنایا ہے۔",
        },
        {
          verse: 7,
          text: "اور تُم باروَر ہو اور بڑھو اور زمِین پر کثرت سے اَولاد پَیدا کرو اور اُس میں بُہت ہو جاؤ۔",
        },
        {
          verse: 8,
          text: "اور خُدا نے نُوحؔ سے اور اُس کے ساتھ اُس کے بیٹوں سے کہا کہ۔",
        },
        {
          verse: 9,
          text: "دیکھو مَیں آپ تمہارے ساتھ اور تمہارے بعد تمہاری نسل کے ساتھ اپنا عہد قائِم کرتا ہُوں۔",
        },
        {
          verse: 10,
          text: "اور ہر جاندار کے ساتھ بھی جو تمہارے ساتھ ہے کیا پرِندہ کیا چَوپایہ کیا زمِین کا ہر جانور جو تمہارے ساتھ ہے۔ غرض کُل جانداروں کے ساتھ جو کشتی سے نِکلے یعنی زمِین کے ہر ایک جانور کے ساتھ۔",
        },
        {
          verse: 11,
          text: "اور مَیں تمہارے ساتھ اپنا عہد قائِم رکھُوں گا کہ سب بشر پِھر طُوفان کے پانی سے ہلاک نہ ہوں گے اور زمِین کی بربادی کے لِئے پِھر طُوفان نہ ہو گا۔",
        },
        {
          verse: 12,
          text: "اور خُدا نے کہا کہ جو عہد مَیں اپنے اور تمہارے درمِیان اور ہر جاندار کے درمِیان جو تمہارے ساتھ ہے پُشت در پُشت ہمیشہ کے لِئے باندھتا ہُوں اُس کا نِشان یہ ہے۔",
        },
        {
          verse: 13,
          text: "کہ مَیں نے اپنی کمان کو بادل میں رکھّا ہے اور وہ میرے اور زمِین کے درمِیان عہد کا نِشان ہو گی۔",
        },
        {
          verse: 14,
          text: "اور یُوں ہو گا کہ جب مَیں زمِین پر بادل لاؤُں گا تو وہ کمان بادل میں دِکھائی دے گی۔",
        },
        {
          verse: 15,
          text: "اور مَیں اپنے اُس عہد کو جو میرے اور تمہارے اور ہر جِنس کے جاندار کے درمِیان ہے یاد کرُوں گا اور سب بشر کی ہلاکت کے لِئے پِھر طُوفان کا پانی نہ ہو گا۔",
        },
        {
          verse: 16,
          text: "اور وہ کمان بادل میں ہو گی اور مَیں اُس پر نِگاہ کرُوں گا تاکہ اُس ابدی عہد کو یاد کرُوں جو خُدا کے اور زمِین پر کے سب بشر کے درمِیان ہے۔",
        },
        {
          verse: 17,
          text: "اور خُدا نے نُوحؔ سے کہا یہ اُس عہد کا نِشان ہے جو مَیں نے اپنے اور رُویِ زمِین کے سب بشر کے درمِیان قائِم کِیا ہے۔",
        },
        {
          verse: 18,
          sectionHeading: "نُوحؔ اور اُس کے بیٹے",
          text: "نُوحؔ کے بیٹے جو کشتی سے نِکلے سِمؔ حامؔ اور یافتؔ تھے اور حام کنعانؔ کا باپ تھا۔",
        },
        {
          verse: 19,
          text: "یہ تِینوں نُوحؔ کے بیٹے تھے اور اِن ہی کی نسل تمام زمِین پر پَھیل گئی۔",
        },
        {
          verse: 20,
          text: "اور نُوحؔ کاشت کاری کرنے لگا اور اُس نے انگُور کا ایک باغ لگایا۔",
        },
        {
          verse: 21,
          text: "اور اُس نے مَے پی اور اُسے نشہ آیا اور وہ اپنے ڈیرے کے اندر برہنہ ہو گیا۔",
        },
        {
          verse: 22,
          text: "اور کنعانؔ کے باپ حامؔ نے اپنے باپ کو برہنہ دیکھا اور اپنے دونوں بھائِیوں کو باہر آ کر خبر دی۔",
        },
        {
          verse: 23,
          text: "تب سِمؔ اور یافتؔ نے ایک کپڑا لِیا اور اُسے اپنے کندھوں پر دھرا اور پیچھے کو اُلٹے چل کر گئے اور اپنے باپ کی برہنگی ڈھانکی۔ سو اُن کے مُنہ اُلٹی طرف تھے اور اُنہوں نے اپنے باپ کی برہنگی نہ دیکھی۔",
        },
        {
          verse: 24,
          text: "جب نُوحؔ اپنی مَے کے نشہ سے ہوش میں آیا تو جو اُس کے چھوٹے بیٹے نے اُس کے ساتھ کِیا تھا اُسے معلُوم ہُؤا۔",
        },
        {
          verse: 25,
          text: "اور اُس نے کہا کہ کنعانؔ ملعُون ہو۔ وہ اپنے بھائِیوں کے غُلاموں کا غُلام ہو گا۔",
        },
        {
          verse: 26,
          text: "پِھر کہا خُداوند سِمؔ کا خُدا مُبارک ہو اور کنعاؔن سِمؔ کا غُلام ہو۔",
        },
        {
          verse: 27,
          text: "خُدا یافتؔ کو پَھیلائے کہ وہ سِمؔ کے ڈیروں میں بسے اور کنعاؔن اُس کا غُلام ہو۔",
        },
        {
          verse: 28,
          text: "اورطُوفان کے بعد نُوحؔ ساڑھے تِین سَو برس اور جیتا رہا۔",
        },
        {
          verse: 29,
          text: "اور نُوحؔ کی کُل عُمر ساڑھے نو سَو برس کی ہُوئی۔ تب اُس نے وفات پائی۔",
        },
      ],
    },
    10: {
      ur: [
        {
          verse: 1,
          sectionHeading: "نُوح کے بیٹوں کی نسل",
          text: "نُوحؔ کے بیٹوں سِمؔ حامؔ اور یافتؔ کی اَولاد یہ ہیں۔ طُوفان کے بعد اُن کے ہاں بیٹے پَیدا ہُوئے۔",
        },
        {
          verse: 2,
          text: "بنی یافت یہ ہیں۔ جُمرؔ اور ماجوؔج اور مادیؔ اور یاوان ؔاور توبلؔ اور مسکؔ اور تِیراسؔ۔",
        },
        {
          verse: 3,
          text: "اور جُمرؔ کے بیٹے اَشکنازؔ اور رِیفتؔ اور تُجرمہؔ۔",
        },
        {
          verse: 4,
          text: "اور یاوانؔ کے بیٹے اِلیِسہؔ اور تَرسِیسؔ۔ کِتّی ؔاور دوداؔنی۔",
        },
        {
          verse: 5,
          text: "قَوموں کے جزِیرے اِن ہی کی نسل میں بٹ کر ہر ایک کی زُبان اور قبِیلہ کے مُطابِق مُختلِف مُلک اور گُروہ ہو گئے۔",
        },
        {
          verse: 6,
          text: "اور بنی حام یہ ہیں۔ کُوؔش اور مِصرؔ اور فوؔط اور کنعاؔن۔",
        },
        {
          verse: 7,
          text: "اور بنی کُوش یہ ہیں۔ سباؔ اور حوِیلہؔ اور سبتہؔ اور رعماہؔ اور سبتیکہؔ۔ اور بنی رعماہ یہ ہیں۔ سباؔ اور دداؔن۔",
        },
        {
          verse: 8,
          text: "اور کُوؔش سے نِمرُؔود پَیدا ہُؤا۔ وہ رُویِ زمِین پر ایک سُورما ہُؤا ہے۔",
        },
        {
          verse: 9,
          text: "خُداوند کے سامنے وہ ایک شِکاری سُورما ہُؤا ہے اِس لِئے یہ مثل چلی کہ خُداوند کے سامنے نِمرُؔود سا شِکاری سُورما۔",
        },
        {
          verse: 10,
          text: "اور اُس کی بادشاہی کی اِبتدا مُلکِ سنعار میں بابلؔ اور ارک ؔاور اکّاؔد اور کلنہ ؔسے ہُوئی۔",
        },
        {
          verse: 11,
          text: "اُسی مُلک سے نِکل کر وہ اسور میں آیا اور نینوہؔ اور رحوبوؔت عیر ؔاور کلحؔ کو۔",
        },
        {
          verse: 12,
          text: "اور نینوہؔ اور کلحؔ کے درمِیان رسن کو جو بڑا شہر ہے بنایا۔",
        },
        {
          verse: 13,
          text: "اور مِصرؔ سے لُودؔی اور عَنامیؔ اور لہابیؔ اور نفتوحیؔ۔",
        },
        {
          verse: 14,
          text: "اور فتروسیؔ اور کَسلوحیؔ (جِن سے فلستی نِکلے) اور کفتورؔی پَیدا ہُوئے۔",
        },
        {
          verse: 15,
          text: "اور کنعانؔ سے صَیداؔ جو اُس کا پہلوٹھا تھا اور حِتّؔ۔",
        },
        {
          verse: 16,
          text: "اور یبوسیؔ اور اموریؔ اور جِرجاسیؔ۔",
        },
        {
          verse: 17,
          text: "اور حوّیؔ اور عرقی ؔاور سینیؔ۔",
        },
        {
          verse: 18,
          text: "اور اروادیؔ اور صماری ؔاور حماتیؔ پَیدا ہُوئے اور بعد میں کنعانی قبِیلے پَھیل گئے۔",
        },
        {
          verse: 19,
          text: "اور کنعانِیوں کی حد یہ ہے۔ صَیدا ؔسے غَزّہ ؔتک جو جرار ؔکے راستے پر ہے۔ پِھر وہاں سے لسعؔ تک جو سدُوؔم اور عمُورہؔ اور ادمہؔ اور ضِبیان ؔکی راہ پر ہے۔",
        },
        {
          verse: 20,
          text: "سو بنی حام یہ ہیں جو اپنے اپنے مُلک اور گروہوں میں اپنے قبِیلوں اور اپنی زُبانوں کے مُطابِق آباد ہیں۔",
        },
        {
          verse: 21,
          text: "اور سِم ؔکے ہاں بھی جو تمام بنی عِبر کا باپ اور یافتؔ کا بڑا بھائی تھا اَولاد ہُوئی۔",
        },
        {
          verse: 22,
          text: "بنی سِم یہ ہیں۔ عَیلامؔ اور اسُور ؔاور ارفکسَد ؔاور لُود ؔاور اراؔم۔",
        },
        {
          verse: 23,
          text: "اور بنی ارام یہ ہیں۔ عُوض اؔور حوؔل اور جتر ؔاور مسؔ۔",
        },
        {
          verse: 24,
          text: "اور ارفکسَدؔ سے سِلح ؔپَیدا ہُؤا اور سِلح ؔسے عِبرؔ۔",
        },
        {
          verse: 25,
          text: "اور عِبر ؔکے ہاں دو بیٹے پَیدا ہُوئے۔ ایک کا نام فلجؔ تھا کیونکہ زمِین اُس کے ایّام میں بِٹّی اور اُس کے بھائی کا نام یُقطانؔ تھا۔",
        },
        {
          verse: 26,
          text: "اور یُقطانؔ سے المودؔاد اور سلفؔ اور حصار ماوتؔ اور اِرَاخؔ۔",
        },
        {
          verse: 27,
          text: "اور ہدوراؔم اور اوزاؔل اور دِقلہؔ۔",
        },
        {
          verse: 28,
          text: "اور عوبلؔ اور ابی مائیلؔ اور سِباؔ۔",
        },
        {
          verse: 29,
          text: "اور اوفیرؔ اور حویلہؔ اور یُوباؔب پَیدا ہُوئے۔ یہ سب بنی یُقطانؔ تھے۔",
        },
        {
          verse: 30,
          text: "اور اِن کی آبادی میسا سے مشرِق کے ایک پہاڑ سفارؔ کی طرف تھی۔",
        },
        {
          verse: 31,
          text: "سو بنی سِم یہ ہیں جو اپنے اپنے مُلک اور گروہوں میں اپنے قبِیلوں اور اپنی زُبانوں کے مُطابِق آباد ہیں۔",
        },
        {
          verse: 32,
          text: "نُوحؔ کے بیٹوں کے خاندان اُن کی گروہوں اور نسلوں کے اِعتبار سے یِہی ہیں اور طُوفان کے بعد جو قَومیں زمِین پر جا بجا مُنقسم ہُوئیِں وہ اِن ہی میں سے تِھیں۔",
        },
      ],
    },
    11: {
      ur: [
        {
          verse: 1,
          sectionHeading: "بابل کا بُرج",
          text: "اور تمام زمِین پر ایک ہی زُبان اور ایک ہی بولی تھی۔",
        },
        {
          verse: 2,
          text: "اور اَیسا ہُؤا کہ مشرِق کی طرف سفر کرتے کرتے اُن کو مُلکِ سِنعار میں ایک میدان مِلا اور وہ وہاں بس گئے۔",
        },
        {
          verse: 3,
          text: "اور اُنہوں نے آپس میں کہا آؤ ہم اِینٹیں بنائیں اور اُن کو آگ میں خُوب پکائیں۔ سو اُنہوں نے پتّھر کی جگہ اِینٹ سے اور چونے کی جگہ گارے سے کام لِیا۔",
        },
        {
          verse: 4,
          text: "پِھر وہ کہنے لگے کہ آؤ ہم اپنے واسطے ایک شہر اور ایک بُرج جِس کی چوٹی آسمان تک پُہنچے بنائیں اور یہاں اپنا نام کریں۔ اَیسا نہ ہو کہ ہم تمام رُویِ زمِین پر پراگندہ ہو جائیں۔",
        },
        {
          verse: 5,
          text: "اور خُداوند اِس شہر اور بُرج کو جِسے بنی آدمؔ بنانے لگے دیکھنے کو اُترا۔",
        },
        {
          verse: 6,
          text: "اور خُداوند نے کہا دیکھو یہ لوگ سب ایک ہیں اور اِن سبھوں کی ایک ہی زُبان ہے۔ وہ جو یہ کرنے لگے ہیں تو اب کُچھ بھی جِس کا وہ اِرادہ کریں اُن سے باقی نہ چُھوٹے گا۔",
        },
        {
          verse: 7,
          text: "سو آؤ ہم وہاں جا کر اُن کی زُبان میں اِختلاف ڈالیں تاکہ وہ ایک دُوسرے کی بات سمجھ نہ سکیں۔",
        },
        {
          verse: 8,
          text: "پس خُداوند نے اُن کو وہاں سے تمام رُویِ زمِین میں پراگندہ کِیا سو وہ اُس شہر کے بنانے سے باز آئے۔",
        },
        {
          verse: 9,
          text: "اِس لِئے اُس کا نام بابلؔ ہُؤا کیونکہ خُداوند نے وہاں ساری زمِین کی زُبان میں اِختلاف ڈالا اور وہاں سے خُداوند نے اُن کو تمام رُویِ زمِین پر پراگندہ کِیا۔",
        },
        {
          verse: 10,
          sectionHeading: "سِم کی نسل",
          text: "یہ سِم کا نسب نامہ ہے۔ سِم ایک سَو برس کا تھا جب اُس سے طُوفان کے دو برس بعد ارفکسَدؔ پَیدا ہُؤا۔",
        },
        {
          verse: 11,
          text: "اور ارفکسَدؔ کی پَیدایش کے بعد سِم پانچ سَو برس جیتا رہا اور اُس سے بیٹے اور بیٹِیاں پَیدا ہُوئیِں۔",
        },
        {
          verse: 12,
          text: "جب ارفکسَدؔ پینتِیس برس کا ہُؤا تو اُس سے سِلح پَیدا ہُؤا۔",
        },
        {
          verse: 13,
          text: "اور سِلح کی پَیدایش کے بعد ارفکسَدؔچار سَو تیِن برس اور جیتا رہا اور اُس سے بیٹے اور بیٹِیاں پَیدا ہُوئیِں۔",
        },
        {
          verse: 14,
          text: "سلحؔ جب تِیس برس کا ہُؤا تو اُس سے عِبر ؔپَیدا ہُؤا۔",
        },
        {
          verse: 15,
          text: "اور عِبرؔ کی پَیدایش کے بعد سِلحؔ چار سَو تِین برس اور جیتا رہا اور اُس سے بیٹے اور بیٹِیاں پَیدا ہُوئیِں۔",
        },
        {
          verse: 16,
          text: "جب عِبرؔ چونتیس برس کا تھا تو اُس سے فلجؔ پَیدا ہُؤا۔",
        },
        {
          verse: 17,
          text: "اور فلجؔ کی پَیدایش کے بعد عِبر ؔچار سَو تِیس برس اَور جیتا رہا اور اُس سے بیٹے اور بیٹِیاں پَیدا ہُوئیِں۔",
        },
        {
          verse: 18,
          text: "فلج ؔتِیس برس کا تھا جب اُس سے رعوؔ پَیدا ہُؤا۔",
        },
        {
          verse: 19,
          text: "اور رعوؔ کی پَیدایش کے بعد فلجؔ دو سَو نو برس اور جیتا رہا اور اُس سے بیٹے اور بیٹِیاں پَیدا ہُوئیِں۔",
        },
        {
          verse: 20,
          text: "اور رعوؔ بتَّیس برس کا تھا جب اُس سے سروؔج پَیدا ہُؤا۔",
        },
        {
          verse: 21,
          text: "اور سروؔج کی پَیدایش کے بعد رعو ؔدو سَو سات برس اور جیتا رہا اور اُس سے بیٹے اور بیٹِیاں پَیدا ہُوئیِں۔",
        },
        {
          verse: 22,
          text: "اور سروؔج تِیس برس کا تھا جب اُس سے نحُورؔ پَیدا ہُؤا۔",
        },
        {
          verse: 23,
          text: "اور نحُورؔ کی پَیدایش کے بعد سروؔج دو سَو برس اور جیتا رہا اور اُس سے بیٹے اور بیٹِیاں پَیدا ہُوئیِں۔",
        },
        {
          verse: 24,
          text: "نحُور ؔاُنتیس برس کا تھا جب اُس سے تارحؔ پَیدا ہُؤا۔",
        },
        {
          verse: 25,
          text: "اور تارحؔ کی پَیدایش کے بعد نحُورؔ ایک سَو اُنِّیس برس اور جیتا رہا اور اُس سے بیٹے اور بیٹِیاں پَیدا ہُوئیِں۔",
        },
        {
          verse: 26,
          text: "اور تارحؔ ستّر برس کا تھا جب اُس سے ابرامؔ اور نحُور ؔاور حارانؔ پَیدا ہُوئے۔",
        },
        {
          verse: 27,
          sectionHeading: "تارح کی نسل",
          text: "اور یہ تارؔح کا نسب نامہ ہے۔ تارحؔ سے ابرامؔ اور نحُورؔ اور حارانؔ پَیدا ہُوئے اور حارانؔ سے لُوؔط پَیدا ہُؤا۔",
        },
        {
          verse: 28,
          text: "اور حاراؔن اپنے باپ تارحؔ کے آگے اپنی زادبُوم یعنی کسدِیوں کے اُور ؔمیں مَرا۔",
        },
        {
          verse: 29,
          text: "اور ابرامؔ اور نحُورؔ نے اپنا اپنا بیاہ کر لِیا۔ ابرامؔ کی بِیوی کا نام سارَؔی اور نحُورؔ کی بِیوی کا نام مِلکہ تھا جو حارانؔ کی بیٹی تھی۔ وُہی مِلکہ کا باپ اور اِسکہؔ کا باپ تھا۔",
        },
        {
          verse: 30,
          text: "اور سارَؔی بانجھ تھی۔ اُس کے کوئی بال بچّہ نہ تھا۔",
        },
        {
          verse: 31,
          text: "اور تارؔح نے اپنے بیٹے ابرامؔ کو اور اپنے پوتے لُوط ؔکو جو حارانؔ کا بیٹا تھا اور اپنی بہُو سارَؔی کو جو اُس کے بیٹے ابرامؔ کی بِیوی تھی ساتھ لِیا اور وہ سب کَسدِیوں کے اُور سے روانہ ہُوئے کہ کنعانؔ کے مُلک میں جائیں اور وہ حارانؔ تک آئے اور وہِیں رہنے لگے۔",
        },
        {
          verse: 32,
          text: "اور تارحؔ کی عُمر دو سَو پانچ برس کی ہُوئی اور اُس نے حارانؔ میں وفات پائی۔",
        },
      ],
    },
    12: {
      ur: [
        {
          verse: 1,
          sectionHeading: "خُدا ابرامؔ کو بُلاتا ہے",
          text: "اور خُداوند نے ابرامؔ سے کہا کہ تُو اپنے وطن اور اپنے ناتے داروں کے بیچ سے اور اپنے باپ کے گھر سے نِکل کر اُس مُلک میں جا جو مَیں تجھے دِکھاؤں گا۔",
        },
        {
          verse: 2,
          text: "اور مَیں تُجھے ایک بڑی قَوم بناؤں گا اور برکت دُوں گا اور تیرا نام سرفراز کرُوں گا۔ سو تُو باعِثِ برکت ہو!",
        },
        {
          verse: 3,
          text: "جو تُجھے مُبارک کہیں اُن کو مَیں برکت دُوں گا اور جو تُجھ پر لَعنت کرے اُس پر مَیں لَعنت کرُوں گا اور زمِین کے سب قبیِلے تیرے وسِیلہ سے برکت پائیں گے۔",
        },
        {
          verse: 4,
          text: "سو ابرامؔ خُداوند کے کہنے کے مُطابِق چل پڑا اور لُوؔط اُس کے ساتھ گیا اور ابرامؔ پچھتّر برس کا تھا جب وہ حارانؔ سے روانہ ہُؤا۔",
        },
        {
          verse: 5,
          text: "اور ابرامؔ نے اپنی بِیوی سارَیؔ اور اپنے بھتیجے لُوطؔ کو اور سب مال کو جو اُنہوں نے جمع کِیا تھا اور اُن آدمِیوں کو جو اُن کو حارانؔ میں مِل گئے تھے ساتھ لِیا اور وہ مُلکِ کنعانؔ کو روانہ ہُوئے۔ اور مُلکِ کنعانؔ میں آئے۔",
        },
        {
          verse: 6,
          text: "اور ابرامؔ اُس مُلک میں سے گذرتا ہُؤا مقامِ سِکمؔ میں مورؔہ کے بلُوطؔ تک پُہنچا۔ اُس وقت مُلک میں کنعانی رہتے تھے۔",
        },
        {
          verse: 7,
          text: "تب خُداوند نے ابرامؔ کو دِکھائی دے کر کہا کہ یِہی مُلک مَیں تیری نسل کو دُوں گا اور اُس نے وہاں خُداوند کے لِئے جو اُسے دِکھائی دِیا تھا ایک قُربان گاہ بنائی۔",
        },
        {
          verse: 8,
          text: "اور وہاں سے کُوچ کر کے اُس پہاڑ کی طرف گیا جو بَیت ایلؔ کے مشرِق میں ہے اور اپنا ڈیرا اَیسے لگایا کہ بَیت ایلؔ مغرِب میں اور عیَؔ مشرِق میں پڑا اور وہاں اُس نے خُداوند کے لِئے ایک قُربان گاہ بنائی اور خُداوند سے دُعا کی۔",
        },
        {
          verse: 9,
          text: "اور ابرامؔ سفر کرتا کرتا جنُوب کی طرف بڑھ گیا۔",
        },
        {
          verse: 10,
          sectionHeading: "ابرامؔ مِصرؔ میں",
          text: "اور اُس مُلک میں کال پڑا اور ابرامؔ مِصرؔ کو گیا کہ وہاں ٹِکا رہے کیونکہ مُلک میں سخت کال تھا۔",
        },
        {
          verse: 11,
          text: "اور اَیسا ہُؤا کہ جب وہ مِصرؔ میں داخِل ہونے کو تھا تو اُس نے اپنی بِیوی سارَی سے کہا کہ دیکھ مَیں جانتا ہُوں کہ تُو دیکھنے میں خُوب صُورت عَورت ہے۔",
        },
        {
          verse: 12,
          text: "اور یُوں ہو گا کہ مِصری تُجھے دیکھ کر کہیں گے کہ یہ اُس کی بِیوی ہے۔ سو وہ مُجھے تو مار ڈالیں گے مگر تُجھے زِندہ رکھ لیں گے۔",
        },
        {
          verse: 13,
          text: "سو تُو یہ کہہ دینا کہ مَیں اِس کی بہن ہُوں تاکہ تیرے سبب سے میری خَیر ہو اور میری جان تیری بدَولت بچی رہے۔",
        },
        {
          verse: 14,
          text: "اور یُوں ہُؤا کہ جب ابرامؔ مِصرؔ میں آیا تو مِصریوں نے اُس عَورت کو دیکھا کہ وہ نِہایت خُوب صُورت ہے۔",
        },
        {
          verse: 15,
          text: "اور فرِعونؔ کے اُمرا نے اُسے دیکھ کر فرِعونؔ کے حضُور میں اُس کی تعرِیف کی اور وہ عَورت فرِعونؔ کے گھر میں پُہنچائی گئی۔",
        },
        {
          verse: 16,
          text: "اور اُس نے اُس کی خاطِر ابرامؔ پر اِحسان کِیا اور بھیڑ بکرِیاں اور گائے بَیل اور گدھے اور غُلام اور لَونڈِیاں اور گدِھیاں اور اُونٹ اُس کے پاس ہو گئے۔",
        },
        {
          verse: 17,
          text: "پر خُداوند نے فرِعونؔ اور اُس کے خاندان پر ابرامؔ کی بِیوی سارَؔی کے سبب سے بڑی بڑی بلائیں نازِل کِیں۔",
        },
        {
          verse: 18,
          text: "تب فِرعونؔ نے ابرامؔ کو بُلا کر اُس سے کہا کہ تُو نے مُجھ سے یہ کیا کِیا؟ تُو نے مُجھے کیوں نہ بتایا کہ یہ تیری بِیوی ہے؟",
        },
        {
          verse: 19,
          text: "تُو نے یہ کیوں کہا کہ وہ میری بہن ہے؟ اِسی لِئے مَیں نے اُسے لِیا کہ وہ میری بِیوی بنے۔ سو دیکھ تیری بِیوی حاضِر ہے۔ اُس کو لے اور چلا جا۔",
        },
        {
          verse: 20,
          text: "اور فِرعونؔ نے اُس کے حق میں اپنے آدمِیوں کو ہدایت کی اور اُنہوں نے اُسے اور اُس کی بِیوی کو اُس کے سب مال کے ساتھ روانہ کر دِیا۔",
        },
      ],
    },
    13: {
      ur: [
        {
          verse: 1,
          sectionHeading: "ابرامؔ اور لُوطؔ جُدا ہوتے ہیں",
          text: "اور ابرامؔ مِصرؔ سے اپنی بِیوی اور اپنے سب مال اور لُوؔط کو ساتھ لے کر کنعانؔ کے جنُوب کی طرف چلا۔",
        },
        {
          verse: 2,
          text: "اور ابرامؔ کے پاس چَوپائے اور سونا چاندی بکثرت تھا۔",
        },
        {
          verse: 3,
          text: "اور وہ کنعانؔ کے جنُوب سے سفر کرتا ہُؤا بَیت ایلؔ میں اُس جگہ پُہنچا جہاں پہلے بَیت ایلؔ اور عیؔ کے درمِیان اُس کا ڈیرا تھا۔",
        },
        {
          verse: 4,
          text: "یعنی وہ مقام جہاں اُس نے شرُوع میں قُربان گاہ بنائی تھی اور وہاں ابرامؔ نے خُداوند سے دُعا کی۔",
        },
        {
          verse: 5,
          text: "اور لُوؔط کے پاس بھی جو ابرامؔ کا ہم سفر تھا بھیڑ بکرِیاں گائے بَیل اور ڈیرے تھے۔",
        },
        {
          verse: 6,
          text: "اور اُس مُلک میں اِتنی گُنجایش نہ تھی کہ وہ اِکٹّھے رہیں کیونکہ اُن کے پاس اِتنا مال تھا کہ وہ اِکٹّھے نہیں رہ سکتے تھے۔",
        },
        {
          verse: 7,
          text: "اور ابرامؔ کے چرواہوں اور لُوؔط کے چرواہوں میں جھگڑا ہُؤا اور کنعانی اور فرِزّیؔ اُس وقت مُلک میں رہتے تھے۔",
        },
        {
          verse: 8,
          text: "تب ابرامؔ نے لُوؔط سے کہا کہ میرے اور تیرے درمِیان اور میرے چرواہوں اور تیرے چرواہوں کے درمِیان جھگڑا نہ ہُؤا کرے کیونکہ ہم بھائی ہیں۔",
        },
        {
          verse: 9,
          text: "کیا یہ سارا مُلک تیرے سامنے نہیں؟ سو تُو مُجھ سے الگ ہو جا۔ اگر تُو بائیں جائے تو مَیں دہنے جاؤں گا اور اگر تُو دہنے جائے تو مَیں بائیں جاؤں گا۔",
        },
        {
          verse: 10,
          text: "تب لُوؔط نے آنکھ اُٹھا کر یَردن کی ساری ترائی پر جو ضُغرؔ کی طرف ہے نظر دَوڑائی کیونکہ وہ اِس سے پیشتر کہ خُداوند نے سدُوم ؔاور عمُورؔہ کو تباہ کِیا خُداوند کے باغ اور مِصرؔ کے مُلک کی مانِند خُوب سیراب تھی۔",
        },
        {
          verse: 11,
          text: "سو لُوطؔ نے یَردنؔ کی ساری ترائی کو اپنے لِئے چُن لِیا اور وہ مشرِق کی طرف چلا اور وہ ایک دُوسرے سے جُدا ہو گئے۔",
        },
        {
          verse: 12,
          text: "ابرامؔ تو مُلکِ کنَعاؔن میں رہا اور لُوطؔ نے ترائی کے شہروں میں سکُونت اِختیار کی اور سدُومؔ کی طرف اپنا ڈیرا لگایا۔",
        },
        {
          verse: 13,
          text: "اور سدُومؔ کے لوگ خُداوند کی نظر میں نِہایت بدکار اور گُنہگار تھے۔",
        },
        {
          verse: 14,
          sectionHeading: "ابرامؔ حبرونؔ کو جاتا ہے",
          text: "اور لُوطؔ کے جُدا ہو جانے کے بعد خُداوند نے ابرامؔ سے کہا کہ اپنی آنکھ اُٹھا اور جِس جگہ تُو ہے وہاں سے شِمال اور جنُوب اور مشرِق اور مغرِب کی طرف نظر دَوڑا۔",
        },
        {
          verse: 15,
          text: "کیونکہ یہ تمام مُلک جو تُو دیکھ رہا ہے مَیں تُجھ کو اور تیری نسل کو ہمیشہ کے لِئے دُوں گا۔",
        },
        {
          verse: 16,
          text: "اور مَیں تیری نسل کو خاک کے ذرّوں کی مانِند بناؤں گا اَیسا کہ اگر کوئی شخص خاک کے ذرّوں کو گِن سکے تو تیری نسل بھی گِن لی جائے گی۔",
        },
        {
          verse: 17,
          text: "اُٹھ اور اِس مُلک کے طُول و عرض میں سَیر کر کیونکہ مَیں اِسے تُجھ کو دُوں گا۔",
        },
        {
          verse: 18,
          text: "اور ابرامؔ نے اپنا ڈیرا اُٹھایا اور مَمرؔے کے بلُوطوں میں جو حبرونؔ میں ہیں جا کر رہنے لگا اور وہاں خُداوند کے لِئے ایک قُربان گاہ بنائی۔",
        },
      ],
    },
    14: {
      ur: [
        {
          verse: 1,
          sectionHeading: "ابرامؔ لُوطؔ کو چُھڑاتا ہے",
          text: "اور سنعار کے بادشاہ اَمرافلؔ اور الاسرؔ کے بادشاہ اریوکؔ اور عیلامؔ کے بادشاہ کِدرلاعمرؔ اور جوئیمؔ کے بادشاہ تدعالؔ کے ایّام میں۔",
        },
        {
          verse: 2,
          text: "یُوں ہُؤا کہ اُنہوں نے سدُومؔ کے بادشاہ برَعؔ اور عمُورہؔ کے بادشاہ بِرشعؔ اور اَدمہؔ کے بادشاہ سنیابؔ اور ضبوئِیمؔ کے بادشاہ شمیبرؔ اور بالَعؔ یعنی ضُغر ؔکے بادشاہ سے جنگ کی۔",
        },
        {
          verse: 3,
          text: "یہ سب سدّیم ؔیعنی دریائے شور کی وادی میں اِکٹّھے ہُوئے۔",
        },
        {
          verse: 4,
          text: "بارہ برس تک وہ کِدر لاعمرؔ کے مُطِیع رہے پر تیرھویں برس اُنہوں نے سرکشی کی۔",
        },
        {
          verse: 5,
          text: "اور چودھویں برس کِدر لاعمرؔ اور اُس کے ساتھ کے بادشاہ آئے اور رفائِیمؔ کو عَستاراتؔ قرنیمؔ میں اور زُوزیوں کو ہام ؔمیں اور ایمیمؔ کو سوِی قریتیمؔ میں۔",
        },
        {
          verse: 6,
          text: "اور حوریوں کو اُن کے کوہِ شعیرؔ میں مارتے مارتے ایل فارانؔ تک جو بیابان سے لگا ہُؤا ہے آئے۔",
        },
        {
          verse: 7,
          text: "پِھر وہ لَوٹ کر عَین مصفاؔت یعنی قادِس پہنچے اور عَمالیقِیوں کے تمام مُلک کو اور امورِیوں کو جو حَصےِ صَون تمرؔ میں رہتے تھے مارا۔",
        },
        {
          verse: 8,
          text: "تب سدُوؔم کا بادشاہ اور عمُورہؔ کا بادشاہ اور اَدمہؔ کا بادشاہ اور ضبوئِیم ؔکا بادشاہ اور بالَعؔ یعنی ضُغر ؔکا بادشاہ نِکلے اور اُنہوں نے سدّیمؔ کی وادی میں معرکہ آرائی کی۔",
        },
        {
          verse: 9,
          text: "تاکہ عیلامؔ کے بادشاہ کِدر لاعمرؔ اور جوئِیمؔ کے بادشاہ تِدعالؔ اور سنعارؔ کے بادشاہ اَمرافلؔ اور الاسرؔ کے بادشاہ اریوکؔ سے جنگ کریں۔ یہ چار بادشاہ اُن پانچوں کے مُقابلہ میں تھے۔",
        },
        {
          verse: 10,
          text: "اور سدّیمؔ کی وادی میں جابجا نفت کے گڑھے تھے اور سدُوؔم اور عمُورؔہ کے بادشاہ بھاگتے بھاگتے وہاں گِرے اور جو بچے پہاڑ پر بھاگ گئے۔",
        },
        {
          verse: 11,
          text: "تب وہ سدُوؔم اور عمُورہؔ کا سب مال اور وہاں کا سب اناج لے کر چلے گئے۔",
        },
        {
          verse: 12,
          text: "اور ابرام ؔکے بھتیجے لُوطؔ کو اور اُس کے مال کو بھی لے گئے کیونکہ وہ سدُومؔ میں رہتا تھا۔",
        },
        {
          verse: 13,
          text: "تب ایک نے جو بچ گیا تھا جا کر ابرامؔ عِبرانی کو خبر دی جو اِسکاؔل اور عانیرؔ کے بھائی ممرؔے اموری کے بلُوطوں میں رہتا تھا اور یہ ابرام ؔکے ہم عہد تھے۔",
        },
        {
          verse: 14,
          text: "جب ابرامؔ نے سُنا کہ اُس کا بھائی گرِفتار ہُؤا تو اُس نے اپنے تِین سَو اٹھارہ مشّاق خانہ زادوں کو لے کر دان تک اُن کا تعاقُب کِیا۔",
        },
        {
          verse: 15,
          text: "اور رات کو اُس نے اور اُس کے خادموں نے غول غول ہو کر اُن پر دھاوا کِیا اور اُن کو مارا اور خوبہ تک جو دمِشقؔ کے بائیں ہاتھ ہے اُن کا پِیچھا کِیا۔",
        },
        {
          verse: 16,
          text: "اور وہ سارے مال کو اور اپنے بھائی لُوطؔ کو اور اُس کے مال اور عَورتوں کو بھی اور اَور لوگوں کو واپس پھیر لایا۔",
        },
        {
          verse: 17,
          sectionHeading: "مَلکِ صدق ابرامؔ کو برکت دیتا ہے",
          text: "اور جب وہ کِدر لاعمرؔ اور اُس کے ساتھ کے بادشاہوں کو مار کر پِھرا تو سدُوؔم کا بادشاہ اُس کے اِستِقبال کو سوِی کی وادی تک جو بادشاہی وادی ہے آیا۔",
        },
        {
          verse: 18,
          text: "اور مَلکِ صِدؔق سالم کا بادشاہ روٹی اور مَے لایا اور وہ خُدا تعالےٰ کا کاہِن تھا۔",
        },
        {
          verse: 19,
          text: "اور اُس نے اُس کو برکت دے کر کہا کہ خُدا تعالیٰ کی طرف سے جو آسمان اور زمِین کا مالِک ہے ابرامؔ مُبارک ہو۔",
        },
        {
          verse: 20,
          text: "اور مُبارک ہے خُدا تعالیٰ جِس نے تیرے دُشمنوں کو تیرے ہاتھ میں کر دِیا۔ تب ابرامؔ نے سب کا دسواں حصّہ اُس کو دِیا۔",
        },
        {
          verse: 21,
          text: "اور سدُوؔم کے بادشاہ نے ابرامؔ سے کہا کہ آدمِیوں کو مُجھے دے دے اور مال اپنے لِئے رکھ لے۔",
        },
        {
          verse: 22,
          text: "پر ابرامؔ نے سدُوؔم کے بادشاہ سے کہا کہ مَیں نے خُداوند خُدا تعالیٰ آسمان اور زمِین کے مالِک کی قَسم کھائی ہے۔",
        },
        {
          verse: 23,
          text: "کہ مَیں نہ تو کوئی دھاگا نہ جوتی کا تسمہ نہ تیری اَور کوئی چِیز لُوں تاکہ تُو یہ نہ کہہ سکے کہ مَیں نے ابرامؔ کو دولت مند بنا دیا۔",
        },
        {
          verse: 24,
          text: "سِوا اُس کے جو جوانوں نے کھا لِیا اور اُن آدمِیوں کے حِصّے کے جو میرے ساتھ گئے۔ سو عانیرؔ اور اسکاؔل اور مَمرے اپنا اپنا حِصّہ لے لیں۔",
        },
      ],
    },
    15: {
      ur: [
        {
          verse: 1,
          sectionHeading: "خُدا کا ابرامؔ سے عہد",
          text: "اِن باتوں کے بعد خُداوند کا کلام رویا میں ابرامؔ پر نازِل ہُؤا اور اُس نے فرمایا اَے ابرامؔ تُو مت ڈر۔ مَیں تیری سِپر اور تیرا بُہت بڑا اجر ہُوں۔",
        },
        {
          verse: 2,
          text: "ابرامؔ نے کہا اَے خُداوند خُدا تُو مُجھے کیا دے گا؟ کیونکہ مَیں تو بے اَولاد جاتا ہُوں اور میرے گھر کا مُختار دمِشقی الِیعزرؔ ہے۔",
        },
        {
          verse: 3,
          text: "پِھر ابرامؔ نے کہا دیکھ تُو نے مُجھے کوئی اَولاد نہیں دی اور دیکھ میرا خانہ زاد میرا وارِث ہو گا۔",
        },
        {
          verse: 4,
          text: "تب خُداوند کا کلام اُس پر نازِل ہُؤا اور اُس نے فرمایا یہ تیرا وارِث نہ ہو گا بلکہ وہ جو تیرے صُلب سے پَیدا ہو گا وُہی تیرا وارِث ہو گا۔",
        },
        {
          verse: 5,
          text: "اور وہ اُس کو باہر لے گیا اور کہا کہ اب آسمان کی طرف نِگاہ کر اور اگر تُو ستاروں کو گِن سکتا ہے تو گِن اور اُس سے کہا کہ تیری اَولاد اَیسی ہی ہو گی۔",
        },
        {
          verse: 6,
          text: "اور وہ خُداوند پر اِیمان لایا اور اِسے اُس نے اُس کے حق میں راست بازی شُمار کِیا۔",
        },
        {
          verse: 7,
          text: "اور اُس نے اُس سے کہا کہ مَیں خُداوند ہُوں جو تُجھے کسدیوں کے اُور سے نِکال لایا کہ تُجھ کو یہ مُلک مِیراث میں دُوں۔",
        },
        {
          verse: 8,
          text: "اور اُس نے کہا اَے خُداوند خُدا! مَیں کیوں کر جانُوں کہ مَیں اُس کا وارِث ہُوں گا؟",
        },
        {
          verse: 9,
          text: "اُس نے اُس سے کہا کہ میرے لِئے تِین برس کی ایک بچھِیا اور تِین برس کی ایک بکری اور تِین برس کا ایک مینڈھا اور ایک قُمری اور ایک کبُوتر کا بچہّ لے۔",
        },
        {
          verse: 10,
          text: "اُس نے اُن سبھوں کو لِیا اور اُن کو بیِچ سے دو ٹُکڑے کِیا اور ہر ٹُکڑے کو اُس کے ساتھ کے دُوسرے ٹُکڑے کے مُقابِل رکھّا مگر پرِندوں کے ٹُکڑے نہ کِئے۔",
        },
        {
          verse: 11,
          text: "تب شِکاری پرِندے اُن ٹُکڑوں پر جھپٹنے لگے پر ابرام ؔاُن کو ہنکاتا رہا۔",
        },
        {
          verse: 12,
          text: "سُورج ڈُوبتے وقت ابرامؔ پر گہری نِیند غالِب ہُوئی اور دیکھو ایک بڑی ہَولناک تارِیکی اُس پر چھا گئی۔",
        },
        {
          verse: 13,
          text: "اور اُس نے ابرامؔ سے کہا یقِین جان کہ تیری نسل کے لوگ اَیسے مُلک میں جو اُن کا نہیں پردیسی ہوں گے اور وہاں کے لوگوں کی غُلامی کریں گے اور وہ چار سَو برس تک اُن کو دُکھ دیں گے۔",
        },
        {
          verse: 14,
          text: "لیکن مَیں اُس قَوم کی عدالت کرُوں گا جِس کی وہ غُلامی کریں گے اور بعد میں وہ بڑی دَولت لے کر وہاں سے نِکل آئیں گے۔",
        },
        {
          verse: 15,
          text: "اور تُو صحیح سلامت اپنے باپ دادا سے جا مِلے گا اور نِہایت پِیری میں دفن ہو گا۔",
        },
        {
          verse: 16,
          text: "اور وہ چَوتھی پُشت میں یہاں لَوٹ آئیں گے کیونکہ امورِیوں کے گُناہ اب تک پُورے نہیں ہُوئے۔",
        },
        {
          verse: 17,
          text: "اور جب سُورج ڈُوبا اور اندھیرا چھا گیا تو ایک تنُور جِس میں سے دُھواں اُٹھتا تھا دِکھائی دِیا اور ایک جلتی مشعل اُن ٹُکڑوں کے بیِچ میں سے ہو کر گُذری۔",
        },
        {
          verse: 18,
          text: "اُسی روز خُداوند نے ابرامؔ سے عہد کِیا اور فرمایا کہ یہ مُلک دریائے مِصرؔ سے لے کر اُس بڑے دریا یعنی دریائے فراتؔ تک۔",
        },
        {
          verse: 19,
          text: "قینیوں اور قنیزیوں اور قدمُونیوں۔",
        },
        {
          verse: 20,
          text: "اور حتِّیوں اور فرِزّیوں اور رفائیم۔",
        },
        {
          verse: 21,
          text: "اور اموریوں اور کنعانیوں اور جِرجاسیوں اور یبوسیوں سمیت میں نے تیری اَولاد کو دِیا ہے۔",
        },
      ],
    },
    16: {
      ur: [
        {
          verse: 1,
          sectionHeading: "ہاجرہؔ اور اِسمٰعیلؔ",
          text: "اور ابرامؔ کی بِیوی سارَؔی کے کوئی اَولاد نہ ہُوئی۔ اُس کی ایک مِصری لَونڈی تھی جِس کا نام ہاجرہؔ تھا۔",
        },
        {
          verse: 2,
          text: "اور سارَیؔ نے ابرامؔ سے کہا کہ دیکھ خُداوند نے مُجھے تو اَولاد سے محرُوم رکھّا ہے سو تُو میری لَونڈی کے پاس جا شاید اُس سے میرا گھر آباد ہو اور ابرامؔ نے سارَیؔ کی بات مانی۔",
        },
        {
          verse: 3,
          text: "اور ابرامؔ کو مُلکِ کنعانؔ میں رہتے دس برس ہو گئے تھے جب اُس کی بِیوی سارَؔی نے اپنی مِصری لَونڈی اُسے دی کہ اُس کی بِیوی بنے۔",
        },
        {
          verse: 4,
          text: "اور وہ ہاجرؔہ کے پاس گیا اور وہ حامِلہ ہُوئی اور جب اُسے معلُوم ہُؤا کہ وہ حامِلہ ہو گئی تو اپنی بی بی کو حقیر جاننے لگی۔",
        },
        {
          verse: 5,
          text: "تب سارَؔی نے ابرامؔ سے کہا کہ جو ظُلم مُجھ پر ہُؤا وہ تیری گردن پر ہے۔ مَیں نے اپنی لَونڈی تیرے آغوش میں دی اور اب جو اُس نے آپ کو حامِلہ دیکھا تو مَیں اُس کی نظروں میں حقِیر ہو گئی۔ سو خُداوند میرے اور تیرے درمِیان اِنصاف کرے۔",
        },
        {
          verse: 6,
          text: "ابرامؔ نے سارَؔی سے کہا کہ تیری لَونڈی تیرے ہاتھ میں ہے جو تُجھے بھلا دِکھائی دے سو اُس کے ساتھ کر۔ تب سارَؔی اُس پر سختی کرنے لگی اور وہ اُس کے پاس سے بھاگ گئی۔",
        },
        {
          verse: 7,
          text: "اور وہ خُداوند کے فرِشتہ کو بیابان میں پانی کے ایک چشمہ کے پاس مِلی۔ یہ وُہی چشمہ ہے جو شور کی راہ پر ہے۔",
        },
        {
          verse: 8,
          text: "اور اُس نے کہا اَے سارَؔی کی لَونڈی ہاجرہؔ تُو کہاں سے آئی اور کدھر جاتی ہے؟ اُس نے کہا کہ مَیں اپنی بی بی سارَؔی کے پاس سے بھاگ آئی ہُوں۔",
        },
        {
          verse: 9,
          text: "خُداوند کے فرِشتہ نے اُس سے کہا کہ تُو اپنی بی بی کے پاس لَوٹ جا اور اپنے کو اُس کے قبضہ میں کر دے۔",
        },
        {
          verse: 10,
          text: "اور خُداوند کے فرِشتہ نے اُس سے کہا کہ مَیں تیری اَولاد کو بُہت بڑھاؤں گا یہاں تک کہ کثرت کے سبب سے اُس کا شُمار نہ ہو سکے گا۔",
        },
        {
          verse: 11,
          text: "اور خُداوند کے فرِشتہ نے اُس سے کہا کہ تُو حامِلہ ہے اور تیرے بیٹا ہو گا۔ اُس کا نام اِسمٰعیلؔ رکھنا اِس لِئے کہ خُداوند نے تیرا دُکھ سُن لِیا۔",
        },
        {
          verse: 12,
          text: "وہ گورخر کی طرح آزاد مَرد ہو گا۔ اُس کا ہاتھ سب کے خِلاف اور سب کے ہاتھ اُس کے خِلاف ہوں گے اور وہ اپنے سب بھائِیوں کے سامنے بسا رہے گا۔",
        },
        {
          verse: 13,
          text: "اور ہاجرہؔ نے خُداوند کا جِس نے اُس سے باتیں کِیں اتااؔیل روئی نام رکھّا یعنی اَے خُدا تُو بصیر ہے کیونکہ اُس نے کہا کیا مَیں نے یہاں بھی اپنے دیکھنے والے کو جاتے ہُوئے دیکھا؟",
        },
        {
          verse: 14,
          text: "اِسی سبب سے اُس کنوئیں کا نام بیر لحی روئیؔ پڑ گیا۔ وہ قادِسؔ اور برِدؔ کے درمِیان ہے۔",
        },
        {
          verse: 15,
          text: "اور ابرامؔ سے ہاجرہؔ کے ایک بیٹا ہُؤا اور ابرامؔ نے اپنے اُس بیٹے کا نام جو ہاجرہؔ سے پَیدا ہُؤا اِسمٰعیلؔ رکھّا۔",
        },
        {
          verse: 16,
          text: "اور جب ابرامؔ سے ہاجرہؔ کے اِسمٰعیلؔ پَیدا ہُؤا تب ابرامؔ چھیاسی برس کا تھا۔",
        },
      ],
    },
    17: {
      ur: [
        {
          verse: 1,
          sectionHeading: "خَتنہ-عہد کا نِشان",
          text: "جب ابرامؔ ننانوے برس کا ہُؤا تب خُداوند ابرام کو نظر آیا اور اُس سے کہا کہ مَیں خُدایِ قادِر ہُوں۔ تُو میرے حضُور میں چل اور کامِل ہو۔",
        },
        {
          verse: 2,
          text: "اور مَیں اپنے اور تیرے درمِیان عہد باندُھوں گا اور تُجھے بُہت زِیادہ بڑھاؤں گا۔",
        },
        {
          verse: 3,
          text: "تب ابرامؔ سرنِگُوں ہو گیا اور خُدا نے اُس سے ہم کلام ہو کر فرمایا۔",
        },
        {
          verse: 4,
          text: "کہ دیکھ میرا عہد تیرے ساتھ ہے اور تُو بُہت قَوموں کا باپ ہو گا۔",
        },
        {
          verse: 5,
          text: "اور تیرا نام پِھر ابرام نہیں کہلائے گا بلکہ تیرا نام ابرہامؔ ہو گا کیونکہ مَیں نے تجھے بُہت قَوموں کا باپ ٹھہرا دِیا ہے۔",
        },
        {
          verse: 6,
          text: "اور مَیں تُجھے بُہت برومند کرُوں گا اور قَومیں تیری نسل سے ہوں گی اور بادشاہ تیری اَولاد میں سے برپا ہوں گے۔",
        },
        {
          verse: 7,
          text: "اور مَیں اپنے اور تیرے درمِیان اور تیرے بعد تیری نسل کے درمِیان اُن کی سب پُشتوں کے لِئے اپنا عہد جو ابدی عہد ہو گا باندھوں گا تاکہ مَیں تیرا اور تیرے بعد تیری نسل کا خُدا رہُوں۔",
        },
        {
          verse: 8,
          text: "اور مَیں تُجھ کو اور تیرے بعد تیری نسل کو کنعاؔن کا تمام مُلک جِس میں تُو پردیسی ہے اَیسا دُوں گا کہ وہ دائِمی مِلکِیّت ہو جائے۔ اور مَیں اُن کا خُدا ہُوں گا۔",
        },
        {
          verse: 9,
          text: "پِھر خُدا نے ابرہامؔ سے کہا کہ تُو میرے عہد کو ماننا اور تیرے بعد تیری نسل پُشت در پُشت اُسے مانے۔",
        },
        {
          verse: 10,
          text: "اور میرا عہد جو میرے اور تیرے درمِیان اور تیرے بعد تیری نسل کے درمِیان ہے اور جِسے تُم مانو گے سو یہ ہے کہ تُم میں سے ہر ایک فرزندِ نرِینہ کا خَتنہ کِیا جائے۔",
        },
        {
          verse: 11,
          text: "اور تُم اپنے بدن کی کھلڑی کا خَتنہ کِیا کرنا۔ اور یہ اُس عہد کا نِشان ہو گا جو میرے اور تُمہارے درمِیان ہے۔",
        },
        {
          verse: 12,
          text: "تُمہارے ہاں پُشت در پُشت ہر لڑکے کا خَتنہ جب وہ آٹھ روز کا ہو کِیا جائے۔ خواہ وہ گھر میں پَیدا ہو خواہ اُسے کِسی پردیسی سے خرِیدا ہو جو تیری نسل سے نہیں۔",
        },
        {
          verse: 13,
          text: "لازِم ہے کہ تیرے خانہ زاد اور تیرے زرخرِید کا خَتنہ کِیا جائے اور میرا عہد تُمہارے جِسم میں ابدی عہد ہو گا۔",
        },
        {
          verse: 14,
          text: "اور وہ فرزندِ نرِینہ جِس کا خَتنہ نہ ہُؤا ہو اپنے لوگوں میں سے کاٹ ڈالا جائے کیونکہ اُس نے میرا عہد توڑا۔",
        },
        {
          verse: 15,
          text: "اور خُدا نے ابرہامؔ سے کہا کہ سارَؔی جو تیری بِیوی ہے سو اُس کو سارَؔی نہ پُکارنا۔ اُس کا نام سارہؔ ہو گا۔",
        },
        {
          verse: 16,
          text: "اور مَیں اُسے برکت دُوں گا اور اُس سے بھی تُجھے ایک بیٹا بخشُوں گا۔ یقیناً مَیں اُسے برکت دُوں گا کہ قَومیں اُس کی نسل سے ہوں گی اور عالَم کے بادشاہ اُس سے پَیدا ہوں گے۔",
        },
        {
          verse: 17,
          text: "تب ابرہامؔ سرنِگُوں ہُؤا اور ہنس کر دِل میں کہنے لگا کہ کیا سَو برس کے بُڈّھے سے کوئی بچّہ ہو گا اور کیا سارہؔ کے جو نوّے برس کی ہے اَولاد ہو گی؟",
        },
        {
          verse: 18,
          text: "اور ابرہامؔ نے خُدا سے کہا کہ کاش اِسمٰعیلؔ ہی تیرے حضُور جِیتا رہے۔",
        },
        {
          verse: 19,
          text: "تب خُدا نے فرمایا کہ بیشک تیری بِیوی سارہؔ کے تُجھ سے بیٹا ہو گا۔ تُو اُس کا نام اِضحاقؔ رکھنا اور مَیں اُس سے اور پِھر اُس کی اَولاد سے اپنا عہد جو ابدی عہد ہے باندھوں گا۔",
        },
        {
          verse: 20,
          text: "اور اِسمٰعیلؔ کے حق میں بھی مَیں نے تیری دُعا سُنی۔ دیکھ مَیں اُسے برکت دُوں گا اور اُسے برومند کرُوں گا اور اُسے بُہت بڑھاؤں گا اور اُس سے بارہ سردار پَیدا ہوں گے اور مَیں اُسے بڑی قَوم بناؤں گا۔",
        },
        {
          verse: 21,
          text: "لیکن مَیں اپنا عہد اِضحاقؔ سے باندھوں گا جو اگلے سال اِسی وقتِ مُعیّن پر سارہ سے پَیدا ہو گا۔",
        },
        {
          verse: 22,
          text: "اور جب خُدا ابرہامؔ سے باتیں کر چُکا تو اُس کے پاس سے اُوپر چلا گیا۔",
        },
        {
          verse: 23,
          text: "تب ابرہامؔ نے اپنے بیٹے اِسمٰعیلؔ کو اور سب خانہ زادوں اور اپنے سب زر خرِیدوں کو یعنی اپنے گھر کے سب مَردوں کو لِیا اور اُسی روز خُدا کے حُکم کے مُطابِق اُن کا خَتنہ کِیا۔",
        },
        {
          verse: 24,
          text: "ابرہامؔ نِنانوے برس کا تھا جب اُس کا خَتنہ ہُؤا۔",
        },
        {
          verse: 25,
          text: "اور جب اُس کے بیٹے اِسمٰعیلؔ کا خَتنہ ہُؤا تو وہ تیرہ برس کا تھا۔",
        },
        {
          verse: 26,
          text: "ابرہامؔ اور اُس کے بیٹے اِسمٰعیلؔ کا خَتنہ ایک ہی دِن ہُؤا۔",
        },
        {
          verse: 27,
          text: "اور اُس کے گھر کے سب مَردوں کا خَتنہ خانہ زادوں اور اُن کا بھی جو پردیسیوں سے خرِیدے گئے تھے اُس کے ساتھ ہُؤا۔",
        },
      ],
    },
    18: {
      ur: [
        {
          verse: 1,
          sectionHeading: "ابرہامؔ سے ایک بیٹے کا وعدہ",
          text: "پِھر خُداوند مَمرے کے بلُوطوں میں اُسے نظر آیا اور وہ دِن کو گرمی کے وقت اپنے خَیمہ کے دروازہ پر بَیٹھا تھا۔",
        },
        {
          verse: 2,
          text: "اور اُس نے اپنی آنکھیں اُٹھا کر نظر کی اور کیا دیکھتا ہے کہ تِین مَرد اُس کے سامنے کھڑے ہیں۔ وہ اُن کو دیکھ کر خَیمہ کے دروازہ سے اُن سے مِلنے کو دَوڑا اور زمِین تک جُھکا۔",
        },
        {
          verse: 3,
          text: "اور کہنے لگا کہ اَے میرے خُداوند اگر مُجھ پر آپ نے کرم کی نظر کی ہے تو اپنے خادِم کے پاس سے چلے نہ جائیں۔",
        },
        {
          verse: 4,
          text: "بلکہ تھوڑا سا پانی لایا جائے اور آپ اپنے پاؤں دھو کر اُس درخت کے نِیچے آرام کریں۔",
        },
        {
          verse: 5,
          text: "مَیں کُچھ روٹی لاتا ہُوں۔ آپ تازہ دَم ہو جائیں۔ تب آگے بڑھیں کیونکہ آپ اِسی لِئے اپنے خادِم کے ہاں آئے ہیں۔ اُنہوں نے کہا جَیسا تُو نے کہا ہے وَیسا ہی کر۔",
        },
        {
          verse: 6,
          text: "اور ابرہامؔ ڈیرے میں سارہؔ کے پاس دَوڑا گیا اور کہا کہ تِین پَیمانہ بارِیک آٹا جلد لے اور اُسے گُوندھ کر پُھلکے بنا۔",
        },
        {
          verse: 7,
          text: "اور ابرہامؔ گلّہ کی طرف دَوڑا اور ایک موٹا تازہ بچھڑا لا کر ایک جوان کو دِیا اور اُس نے جلدی جلدی اُسے تیّار کِیا۔",
        },
        {
          verse: 8,
          text: "پِھر اُس نے مکّھن اور دُودھ اور اُس بچھڑے کو جو اُس نے پکوایا تھا لے کر اُن کے سامنے رکھّا اور آپ اُن کے پاس درخت کے نِیچے کھڑا رہا اور اُنہوں نے کھایا۔",
        },
        {
          verse: 9,
          text: "پِھر اُنہوں نے اُس سے پُوچھا کہ تیری بِیوی سارہؔ کہاں ہے؟ اُس نے کہا وہ ڈیرے میں ہے۔",
        },
        {
          verse: 10,
          text: "تب اُس نے کہا مَیں پِھر موسمِ بہار میں تیرے پاس آؤں گا اور دیکھ تیری بِیوی سارہ ؔکے بیٹا ہو گا۔ اُس کے پِیچھے ڈیرے کا دروازہ تھا۔ سارہؔ وہاں سے سُن رہی تھی۔",
        },
        {
          verse: 11,
          text: "اور ابرہامؔ اور سارہؔ ضعِیف اور بڑی عُمر کے تھے اور سارہؔ کی وہ حالت نہیں رہی تھی جو عَورتوں کی ہوتی ہے۔",
        },
        {
          verse: 12,
          text: "تب سارہؔ نے اپنے دِل میں ہنس کر کہا کیا اِس قدر عُمر رسِیدہ ہونے پر بھی میرے لِئے شادمانی ہو سکتی ہے حالانکہ میرا خاوند بھی ضعِیف ہے؟",
        },
        {
          verse: 13,
          text: "پِھر خُداوند نے ابرہامؔ سے کہا کہ سارہؔ کیوں یہ کہہ کر ہنسی کہ کیا میرے جو اَیسی بُڑھیا ہو گئی ہُوں واقِعی بیٹا ہو گا؟",
        },
        {
          verse: 14,
          text: "کیا خُداوند کے نزدِیک کوئی بات مُشکل ہے؟ موسمِ بہار میں مُعیّن وقت پر مَیں تیرے پاس پِھر آؤں گا اور سارہؔ کے بیٹا ہو گا۔",
        },
        {
          verse: 15,
          text: "تب سارہؔ اِنکار کر گئی کہ مَیں نہیں ہنسی کیونکہ وہ ڈرتی تھی۔ پر اُس نے کہا نہیں تُو ضرُور ہنسی تھی۔",
        },
        {
          verse: 16,
          sectionHeading: "ابرہامؔ سدُومؔ کے لِئے التجا کرتا ہے",
          text: "تب وہ مَرد وہاں سے اُٹھے اور اُنہوں نے سدُوؔم کا رُخ کِیا اور ابرہامؔ اُن کو رُخصت کرنے کو اُن کے ساتھ ہو لِیا۔",
        },
        {
          verse: 17,
          text: "اور خُداوند نے کہا کہ جو کُچھ مَیں کرنے کو ہُوں کیا اُسے ابرہامؔ سے پوشِیدہ رکھُّوں؟",
        },
        {
          verse: 18,
          text: "ابرہامؔ سے تو یقیناً ایک بڑی اور زبردست قَوم پَیدا ہو گی اور زمِین کی سب قَومیں اُس کے وسِیلہ سے برکت پائیں گی۔",
        },
        {
          verse: 19,
          text: "کیونکہ مَیں جانتا ہُوں کہ وہ اپنے بیٹوں اور گھرانے کو جو اُس کے پیچھے رہ جائیں گے وصِیّت کرے گا کہ وہ خُداوند کی راہ میں قائِم رہ کر عدل اور اِنصاف کریں تاکہ جو کُچھ خُداوند نے ابرہامؔ کے حق میں فرمایا ہے اُسے پُورا کرے۔",
        },
        {
          verse: 20,
          text: "پِھر خُداوند نے فرمایا چُونکہ سدُوؔم اور عمُورہ ؔکا شور بڑھ گیا اور اُن کا جُرم نِہایت سنگِین ہو گیا ہے۔",
        },
        {
          verse: 21,
          text: "اِس لِئے مَیں اب جا کر دیکُھوں گا کہ کیا اُنہوں نے سراسر وَیسا ہی کِیا ہے جَیسا شور میرے کان تک پُہنچا ہے اور اگر نہیں کِیا تو مَیں معلُوم کر لُوں گا۔",
        },
        {
          verse: 22,
          text: "سو وہ مَرد وہاں سے مُڑے اور سدُوؔم کی طرف چلے پر ابرہامؔ خُداوند کے حضُور کھڑا ہی رہا۔",
        },
        {
          verse: 23,
          text: "تب ابرہامؔ نے نزدِیک جا کر کہا کیا تُو نیک کو بد کے ساتھ ہلاک کرے گا؟",
        },
        {
          verse: 24,
          text: "شاید اُس شہر میں پچاس راست باز ہوں۔ کیا تُو اُسے ہلاک کرے گا اور اُن پچاس راست بازوں کی خاطِر جو اُس میں ہوں اُس مقام کو نہ چھوڑے گا؟",
        },
        {
          verse: 25,
          text: "اَیسا کرنا تُجھ سے بعید ہے کہ نیک کو بد کے ساتھ مار ڈالے اور نیک بد کے برابر ہو جائیں۔ یہ تُجھ سے بعید ہے۔ کیا تمام دُنیا کا اِنصاف کرنے والا اِنصاف نہ کرے گا؟",
        },
        {
          verse: 26,
          text: "اور خُداوند نے فرمایا کہ اگر مُجھے سدُوؔم میں شہر کے اندر پچاس راست باز مِلیں تو مَیں اُن کی خاطِر اُس مقام کو چھوڑ دُوں گا۔",
        },
        {
          verse: 27,
          text: "تب ابرہامؔ نے جواب دِیا اور کہا کہ دیکھئے! مَیں نے خُداوند سے بات کرنے کی جُرأت کی اگرچہ مَیں خاک اور راکھ ہُوں۔",
        },
        {
          verse: 28,
          text: "شاید پچاس راست بازوں میں پانچ کم ہوں۔ کیا اُن پانچ کی کمی کے سبب سے تُو تمام شہر کو نیست کرے گا؟ اُس نے کہا اگر مُجھے وہاں پینتالِیس مِلیں تو مَیں اُسے نیست نہیں کرُوں گا۔",
        },
        {
          verse: 29,
          text: "پِھر اُس نے اُس سے کہا کہ شاید وہاں چالِیس مِلیں۔ تب اُس نے کہا کہ مَیں اُن چالِیس کی خاطِر بھی یہ نہیں کرُوں گا۔",
        },
        {
          verse: 30,
          text: "پِھر اُس نے کہا خُداوند ناراض نہ ہو تو مَیں کُچھ اَور عرض کرُوں۔ شاید وہاں تِیس مِلیں۔ اُس نے کہا۔ اگر مُجھے وہاں تِیس بھی مِلیں تَو بھی اَیسا نہیں کرُوں گا۔",
        },
        {
          verse: 31,
          text: "پِھر اُس نے کہا دیکھئے! مَیں نے خُداوند سے بات کرنے کی جُرأت کی۔ شاید وہاں بِیس مِلیں۔ اُس نے کہا مَیں بِیس کی خاطِر بھی اُسے نیست نہیں کرُوں گا۔",
        },
        {
          verse: 32,
          text: "تب اُس نے کہا خُداوند ناراض نہ ہو تو مَیں ایک بار اَور کُچھ عرض کرُوں۔ شاید وہاں دس مِلیں۔ اُس نے کہا مَیں دس کی خاطِر بھی اُسے نیست نہیں کرُوں گا۔",
        },
        {
          verse: 33,
          text: "جب خُداوند ابرہامؔ سے باتیں کر چُکا تو چلا گیا اور ابرہامؔ اپنے مکان کو لَوٹا۔",
        },
      ],
    },
    19: {
      ur: [
        {
          verse: 1,
          sectionHeading: "سدُومؔ کا گُناہ",
          text: "اور وہ دونوں فرِشتے شام کو سدُوؔم میں آئے اور لُوطؔ سدُوؔم کے پھاٹک پر بَیٹھا تھا اور لُوطؔ اُن کو دیکھ کر اُن کے اِستقبال کے لِئے اُٹھا اور زمِین تک جُھکا۔",
        },
        {
          verse: 2,
          text: "اور کہا اَے میرے خُداوندو اپنے خادِم کے گھر تشرِیف لے چلئے اور رات بھر آرام کِیجئے اور اپنے پاؤں دھوئِیے اور صُبح اُٹھ کر اپنی راہ لِیجئے اور اُنہوں نے کہا نہیں ہم چَوک ہی میں رات کاٹ لیں گے۔",
        },
        {
          verse: 3,
          text: "لیکن جب وہ بُہت بجِد ہُؤا تو وہ اُس کے ساتھ چل کر اُس کے گھر میں آئے اور اُس نے اُن کے لِئے ضِیافت تیّار کی اور بے خمیِری روٹی پکائی اور اُنہوں نے کھایا۔",
        },
        {
          verse: 4,
          text: "اور اِس سے پیشتر کہ وہ آرام کرنے لِئے لیٹیں سدُوؔم شہر کے مَردوں نے جوان سے لے کر بُڈّھے تک سب لوگوں نے ہر طرف سے اُس گھر کو گھیر لِیا۔",
        },
        {
          verse: 5,
          text: "اور اُنہوں نے لُوطؔ کو پُکار کر اُس سے کہا کہ وہ مَرد جو آج رات تیرے ہاں آئے کہاں ہیں؟ اُن کو ہمارے پاس باہر لے آ تاکہ ہم اُن سے صُحبت کریں۔",
        },
        {
          verse: 6,
          text: "تب لُوطؔ نِکل کر اُن کے پاس دروازہ پر گیا اور اپنے پیچھے کِواڑ بند کر دِیا۔",
        },
        {
          verse: 7,
          text: "اور کہا کہ اَے بھائِیو! اَیسی بدی تو نہ کرو۔",
        },
        {
          verse: 8,
          text: "دیکھو! میری دو بیٹِیاں ہیں جو مَرد سے واقِف نہیں۔ مرضی ہو تو مَیں اُن کو تُمہارے پاس لے آؤں اور جو تُم کو بھلا معلُوم ہو اُن سے کرو۔ مگر اِن مَردوں سے کُچھ نہ کہنا کیونکہ وہ اِسی واسطے میری پناہ میں آئے ہیں۔",
        },
        {
          verse: 9,
          text: "اُنہوں نے کہا یہاں سے ہٹ جا۔ پِھر کہنے لگے کہ یہ شخص ہمارے درمِیان قیام کرنے آیا تھا اور اب حُکُومت جتاتا ہے۔ سو ہم تیرے ساتھ اُن سے زِیادہ بدسلُوکی کریں گے۔ تب وہ اُس مَرد یعنی لُوطؔ پر پل پڑے اور نزدِیک آئے تاکہ کِواڑ توڑ ڈالیں۔",
        },
        {
          verse: 10,
          text: "لیکن اُن مَردوں نے اپنے ہاتھ بڑھا کر لُوطؔ کو اپنے پاس گھر میں کھینچ لِیا اور دروازہ بند کر دِیا۔",
        },
        {
          verse: 11,
          text: "اور اُن مَردوں کو جو گھر کے دروازہ پر تھے کیا چھوٹے کیا بڑے اندھا کر دِیا۔ سو وہ دروازہ ڈُھونڈتے ڈُھونڈتے تھک گئے۔",
        },
        {
          verse: 12,
          sectionHeading: "لُوطؔ سدُومؔ سے روانہ ہوتا ہے",
          text: "تب اُن مَردوں نے لُوطؔ سے کہا کیا یہاں تیرا اَور کوئی ہے؟ داماد اور اپنے بیٹوں اور بیٹِیوں اور جو کوئی تیرا اِس شہر میں ہو سب کو اِس مقام سے باہر نِکال لے جا۔",
        },
        {
          verse: 13,
          text: "کیونکہ ہم اِس مقام کو نیست کریں گے اِس لِئے کہ اُن کا شور خُداوند کے حضُور بُہت بُلند ہُؤا ہے اور خُداوند نے اُسے نیست کرنے کو ہمیں بھیجا ہے۔",
        },
        {
          verse: 14,
          text: "تب لُوطؔ نے باہر جا کر اپنے دامادوں سے جِنہوں نے اُس کی بیٹِیاں بیاہی تِھیں باتیں کِیں اور کہا کہ اُٹھو اور اِس مقام سے نِکلو کیونکہ خُداوند اِس شہر کو نیست کرے گا۔ لیکن وہ اپنے دامادوں کی نظر میں مُضحِک سا معلُوم ہُؤا۔",
        },
        {
          verse: 15,
          text: "جب صُبح ہُوئی تو فرِشتوں نے لُوطؔ سے جلدی کرائی اور کہا کہ اُٹھ اپنی بِیوی اور اپنی دونوں بیٹِیوں کو جو یہاں ہیں لے جا۔ اَیسا نہ ہو کہ تُو بھی اِس شہر کی بدی میں گرِفتار ہو کر ہلاک ہو جائے۔",
        },
        {
          verse: 16,
          text: "مگر اُس نے دیر لگائی تو اُن مَردوں نے اُس کا اور اُس کی بِیوی اور اُس کی دونوں بیٹِیوں کا ہاتھ پکڑا کیونکہ خُداوند کی مِہربانی اُس پر ہُوئی اور اُسے نِکال کر شہر سے باہر کر دِیا۔",
        },
        {
          verse: 17,
          text: "اور یُوں ہُؤا کہ جب وہ اُن کو باہر نِکال لائے تو اُس نے کہا اپنی جان بچانے کو بھاگ۔ نہ تو پیچھے مُڑ کر دیکھنا نہ کہِیں مَیدان میں ٹھہرنا۔ اُس پہاڑ کو چلا جا۔ تا نہ ہو کہ تُو ہلاک ہو جائے۔",
        },
        {
          verse: 18,
          text: "اور لُوط ؔنے اُن سے کہا کہ اَے میرے خُداوند اَیسا نہ کر۔",
        },
        {
          verse: 19,
          text: "دیکھ تُو نے اپنے خادِم پر کرم کی نظر کی ہے اور اَیسا بڑا فضل کِیا کہ میری جان بچائی۔ مَیں پہاڑ تک جا نہیں سکتا۔ کہِیں اَیسا نہ ہو کہ مُجھ پر مُصِیبت آ پڑے اور مَیں مر جاؤں۔",
        },
        {
          verse: 20,
          text: "دیکھ یہ شہر اَیسا نزدِیک ہے کہ وہاں بھاگ سکتا ہُوں اور یہ چھوٹا بھی ہے۔ اِجازت ہو تو مَیں وہاں چلا جاؤں۔ وہ چھوٹا سا بھی ہے اور میری جان بچ جائے گی۔",
        },
        {
          verse: 21,
          text: "اُس نے اُس سے کہا کہ دیکھ مَیں اِس بات میں بھی تیرا لحاظ کرتا ہُوں کہ اِس شہر کو جِس کا تُو نے ذِکر کِیا غارت نہیں کرُوں گا۔",
        },
        {
          verse: 22,
          text: "جلدی کر اور وہاں چلا جا کیونکہ مَیں کُچھ نہیں کر سکتا جب تک کہ تُو وہاں پُہنچ نہ جائے۔ اِسی لِئے اُس شہر کا نام ضُغرؔ کہلایا۔",
        },
        {
          verse: 23,
          sectionHeading: "سدُومؔ اور عمُورہؔ کی بربادی",
          text: "اور زمِین پر دُھوپ نِکل چُکی تھی جب لُوطؔ ضُغر ؔمیں داخِل ہُؤا۔",
        },
        {
          verse: 24,
          text: "تب خُداوند نے اپنی طرف سے سدُوؔم اور عمُورؔہ پر گندھک اور آگ آسمان سے برسائی۔",
        },
        {
          verse: 25,
          text: "اور اُس نے اُن شہروں کو اور اُس ساری ترائی کو اور اُن شہروں کے سب رہنے والوں کو اور سب کُچھ جو زمِین سے اُگا تھا غارت کِیا۔",
        },
        {
          verse: 26,
          text: "مگر اُس کی بِیوی نے اُس کے پیچھے سے مُڑ کر دیکھا اور وہ نمک کا سُتُون بن گئی۔",
        },
        {
          verse: 27,
          text: "اور ابرہامؔ صُبح سویرے اُٹھ کر اُس جگہ گیا جہاں وہ خُداوند کے حضُور کھڑا ہُؤا تھا۔",
        },
        {
          verse: 28,
          text: "اور اُس نے سدُوؔم اور عمُورؔہ اور اُس ترائی کی ساری زمِین کی طرف نظر کی اور کیا دیکھتا ہے کہ زمِین پر سے دُھواں اَیسا اُٹھ رہا جَیسے بھٹّی کا دُھواں۔",
        },
        {
          verse: 29,
          text: "اور یُوں ہُؤا کہ جب خُدا نے اُس ترائی کے شہروں کو نیست کِیا تو خُدا نے ابرہامؔ کو یاد کِیا اور اُن شہروں کو جہاں لُوطؔ رہتا تھا غارت کرتے وقت لُوطؔ کو اُس بلا سے بچایا۔",
        },
        {
          verse: 30,
          sectionHeading: "موآبیوں اور عمّونیوں کا آغاز",
          text: "اور لُوطؔ ضُغرؔ سے نِکل کر پہاڑ پر جا بسا اور اُس کی دونوں بیٹِیاں اُس کے ساتھ تِھیں کیونکہ اُسے ضُغر ؔمیں بستے ڈر لگا اور وہ اور اُس کی دونوں بیٹِیاں ایک غار میں رہنے لگے۔",
        },
        {
          verse: 31,
          text: "تب پہلوٹھی نے چھوٹی سے کہا کہ ہمارا باپ بُڈّھا ہے اور زمِین پر کوئی مَرد نہیں جو دُنیا کے دستُور کے مُطابِق ہمارے پاس آئے۔",
        },
        {
          verse: 32,
          text: "آؤ ہم اپنے باپ کو مَے پِلائیں اور اُس سے ہم آغوش ہوں تاکہ اپنے باپ سے نسل باقی رکھّیں۔",
        },
        {
          verse: 33,
          text: "سو اُنہوں نے اُسی رات اپنے باپ کو مَے پِلائی اور پہلوٹھی اندر گئی اور اپنے باپ سے ہم آغوش ہُوئی پر اُس نے نہ جانا کہ وہ کب لیٹی اور کب اُٹھ گئی۔",
        },
        {
          verse: 34,
          text: "اور دُوسرے روز یُوں ہُؤا کہ پہلوٹھی نے چھوٹی سے کہا کہ دیکھ کل رات کو مَیں اپنے باپ سے ہم آغوش ہُوئی۔ آؤ آج رات بھی اُس کو مَے پِلائیں اور تُو بھی جا کر اُس سے ہم آغوش ہو تاکہ ہم اپنے باپ سے نسل باقی رکھّیں",
        },
        {
          verse: 35,
          text: "سو اُس رات بھی اُنہوں نے اپنے باپ کو مَے پِلائی اور چھوٹی گئی اور اُس سے ہم آغوش ہُوئی پر اُس نے نہ جانا کہ وہ کب لیٹی اور کب اُٹھ گئی۔",
        },
        {
          verse: 36,
          text: "سو لُوطؔ کی دونوں بیٹِیاں اپنے باپ سے حامِلہ ہُوئِیں۔",
        },
        {
          verse: 37,
          text: "اور بڑی کے ایک بیٹا ہُؤا اور اُس نے اُس کا نام موآؔب رکھّا۔ وُہی موآبیوں کا باپ ہے جو اب تک مَوجُود ہیں۔",
        },
        {
          verse: 38,
          text: "اور چھوٹی کے بھی ایک بیٹا ہُؤا اور اُس نے اُس کا نام بِن عمّی رکھّا۔ وُہی بنی عَمّون کا باپ ہے جو اب تک مَوجُود ہیں۔",
        },
      ],
    },
    20: {
      ur: [
        {
          verse: 1,
          sectionHeading: "ابرہامؔ اور ابی مَلکؔ",
          text: "اور ابرہامؔ وہاں سے جنُوب کے مُلک کی طرف چلا اور قادِؔس اور شورؔ کے درمِیان ٹھہرا اور جرارؔ میں قیام کِیا۔",
        },
        {
          verse: 2,
          text: "اور ابرہامؔ نے اپنی بِیوی سارہؔ کے حق میں کہا کہ وہ میری بہن ہے اور جرارؔ کے بادشاہ ابی مَلک ؔنے سارہؔ کو بُلوا لِیا۔",
        },
        {
          verse: 3,
          text: "لیکن رات کو خُدا ابی مَلِکؔ کے پاس خواب میں آیا اور اُسے کہا کہ دیکھ تُو اُس عَورت کے سبب سے جِسے تُو نے لِیا ہے ہلاک ہو گا کیونکہ وہ شَوہر والی ہے۔",
        },
        {
          verse: 4,
          text: "پر ابی مَلِکؔ نے اُس سے صُحبت نہیں کی تھی۔ سو اُس نے کہا اَے خُداوند کیا تُو صادِق قَوم کو بھی مارے گا؟",
        },
        {
          verse: 5,
          text: "کیا اُس نے خُود مُجھ سے نہیں کہا کہ یہ میری بہن ہے؟ اور وہ آپ بھی یِہی کہتی تھی کہ وہ میرا بھائی ہے۔ مَیں نے تو اپنے سچّے دِل اور پاکِیزہ ہاتھوں سے یہ کِیا۔",
        },
        {
          verse: 6,
          text: "اور خُدا نے اُسے خواب میں کہا ہاں مَیں جانتا ہُوں کہ تُو نے اپنے سچّے دل سے یہ کِیا اور مَیں نے بھی تُجھے روکا کہ تُو میرا گُناہ نہ کرے۔ اِسی لِئے مَیں نے تُجھے اُس کو چُھونے نہ دِیا۔",
        },
        {
          verse: 7,
          text: "اب تُو اُس مَرد کی بِیوی کو واپس کر دے کیونکہ وہ نبی ہے اور وہ تیرے لِئے دُعا کرے گا اور تُو جِیتا رہے گا۔ پر اگر تُو اُسے واپس نہ کرے تو جان لے کہ تُو بھی اور جِتنے تیرے ہیں سب ضرُور ہلاک ہوں گے۔",
        },
        {
          verse: 8,
          text: "تب ابی مَلِکؔ نے صُبح سویرے اُٹھ کر اپنے سب نوکروں کو بُلایا اور اُن کو یہ سب باتیں کہہ سُنائِیں۔ تب وہ لوگ بُہت ڈر گئے۔",
        },
        {
          verse: 9,
          text: "اور ابی مَلِکؔ نے ابرہامؔ کو بُلا کر اُس سے کہا کہ تُو نے ہم سے یہ کیا کِیا؟ اور مُجھ سے تیرا کیا قصُور ہُؤا کہ تُو مُجھ پر اور میری بادشاہی پر ایک گُناہِ عظِیم لایا؟ تُو نے مُجھ سے وہ کام کِئے جِن کا کرنا مُناسِب نہ تھا۔",
        },
        {
          verse: 10,
          text: "ابی مَلِکؔ نے ابرہامؔ سے یہ بھی کہا کہ تُو نے کیا سمجھ کر یہ بات کی؟",
        },
        {
          verse: 11,
          text: "ابرہامؔ نے کہا کہ میرا خیال تھا کہ خُدا کا خوف تو اِس جگہ ہرگِز نہ ہو گا اور وہ مُجھے میری بِیوی کے سبب سے مار ڈالیں گے۔",
        },
        {
          verse: 12,
          text: "اور فی الحقِیقت وہ میری بہن بھی ہے کیونکہ وہ میرے باپ کی بیٹی ہے اگرچہ میری ماں کی بیٹی نہیں۔ پِھر وہ میری بِیوی ہُوئی۔",
        },
        {
          verse: 13,
          text: "اور جب خُدا نے میرے باپ کے گھر سے مُجھے آوارہ کِیا تو مَیں نے اِس سے کہا کہ مُجھ پر یہ تیری مِہربانی ہو گی کہ جہاں کہِیں ہم جائیں تُو میرے حق میں یِہی کہنا کہ یہ میرا بھائی ہے۔",
        },
        {
          verse: 14,
          text: "تب ابی مَلِکؔ نے بھیڑ بکرِیاں اور گائے بَیل اور غُلام اور لَونڈِیاں ابرہامؔ کو دِیں اور اُس کی بِیوی سارہؔ کو بھی اُسے واپس کر دِیا۔",
        },
        {
          verse: 15,
          text: "اور ابی مَلِکؔ نے کہا کہ دیکھ میرا مُلک تیرے سامنے ہے۔ جہاں جی چاہے رہ۔",
        },
        {
          verse: 16,
          text: "اور اُس نے سارہؔ سے کہا کہ دیکھ مَیں نے تیرے بھائی کو چاندی کے ہزار سِکّے دِئے ہیں۔ وہ اُن سب کے سامنے جو تیرے ساتھ ہیں تیرے لِئے آنکھ کا پردہ ہے اور سب کے سامنے تیری دادرسی ہو گئی۔",
        },
        {
          verse: 17,
          text: "تب ابرہامؔ نے خُدا سے دُعا کی اور خُدا نے ابی مَلِکؔ اور اُس کی بِیوی اور اُس کی لَونڈِیوں کو شِفا بخشی اور اُن کے اَولاد ہونے لگی۔",
        },
        {
          verse: 18,
          text: "کیونکہ خُداوند نے ابرہامؔ کی بِیوی سارہؔ کے سبب سے ابی مَلِکؔ کے خاندان کے سب رَحِم بند کر دِئے تھے۔",
        },
      ],
    },
    ...GENESIS_21_TO_50,
  },
  exodus: EXODUS_DATA,
};

// Helper to register imported chapters at runtime
export function registerImportedChapter(bookId: string, chapter: number, translation: TranslationId, verses: VerseContent[]) {
  const bId = bookId.toLowerCase();
  if (!SCRIPTURE_DATA[bId]) {
    SCRIPTURE_DATA[bId] = {};
  }
  if (!SCRIPTURE_DATA[bId][chapter]) {
    SCRIPTURE_DATA[bId][chapter] = {};
  }
  // Never overwrite verified Genesis 1-50 or Exodus 1-40
  if (bId === 'genesis' && chapter >= 1 && chapter <= 50) {
    return;
  }
  if (bId === 'exodus' && chapter >= 1 && chapter <= 40) {
    return;
  }
  SCRIPTURE_DATA[bId][chapter][translation] = verses;
}

// Helper to fetch verses safely. Returns empty array when no translation is installed or chapter is unpopulated.
export function getChapterVerses(bookId: string, chapter: number, translation?: TranslationId): VerseContent[] {
  if (!translation) return [];
  const bookData = SCRIPTURE_DATA[bookId.toLowerCase()];
  if (bookData && bookData[chapter] && bookData[chapter][translation]) {
    return bookData[chapter][translation];
  }
  return [];
}

export interface SearchResult {
  bookId: string;
  chapter: number;
  verse: number;
  text: string;
  translation: TranslationId;
}

// Scripture search helper. Returns empty array when no Bible translation is installed.
export function searchScripture(
  query: string,
  translation?: TranslationId,
  testamentFilter: 'ALL' | 'OT' | 'NT' = 'ALL'
): SearchResult[] {
  const cleanQuery = query.toLowerCase().trim();
  if (!cleanQuery || !translation) return [];

  const results: SearchResult[] = [];

  for (const bookId in SCRIPTURE_DATA) {
    const book = BIBLE_BOOKS.find(b => b.id.toLowerCase() === bookId.toLowerCase());
    if (testamentFilter !== 'ALL' && book && book.testament !== testamentFilter) {
      continue;
    }

    const chapters = SCRIPTURE_DATA[bookId];
    if (!chapters) continue;

    for (const chNum in chapters) {
      const chapter = Number(chNum);
      const transObj = chapters[chapter];
      if (!transObj) continue;

      const verses = transObj[translation] || [];

      for (const v of verses) {
        if (v.text.toLowerCase().includes(cleanQuery)) {
          results.push({
            bookId,
            chapter,
            verse: v.verse,
            text: v.text,
            translation,
          });
        }
      }
    }
  }

  return results;
}
