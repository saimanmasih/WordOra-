import { WorshipTrack } from '../types';

export const WORSHIP_TRACKS: WorshipTrack[] = [
  {
    id: 'zaboor-23',
    title: 'Zaboor 23 (Rab Mera Charwaha Hai)',
    subtitle: 'Classic Punjabi & Urdu Zaboor',
    category: 'geet_zaboor',
    duration: '4:12',
    lyrics: `Rab mera charwaha hai,
Mujhe koi kami na hosi.
Hari hari charagahan vich,
Mainu baithata aape hi.

Mera pawa karda thanda,
Karda hai aaram;
Raastbazi de raahan utte,
Turda le apna naam.

Maut di kaali ghati vich vi,
Daran na kade ghabra ke;
Teri soti te tera aasa,
Mainu dinde aas bana ke.`,
  },
  {
    id: 'zaboor-100',
    title: 'Zaboor 100 (Sab Zameen Ke Logo)',
    subtitle: 'Praise & Thanksgiving Zaboor',
    category: 'praise',
    duration: '3:45',
    lyrics: `Ai saari zameen de logo,
Khudaawand aage gao geet!
Khushi naal us di karo bandagi,
Uchha karke sur sangheet!

Jaano ke Khudaawand Rab hai,
Us ne sanu aape banaya;
Osdiyan bhedan te ossi da galla,
Osnay sanu charaya.

Ohde buhean vich aao shukr naal,
Ohdi dargaah vich vadho sana naal;
Shukr karo te naam nu aakho:
Mubarak har haal!`,
  },
  {
    id: 'geet-yeshu-masih',
    title: 'Yeshu Masih Deta Khushi',
    subtitle: 'Worship Geet',
    category: 'geet_zaboor',
    duration: '5:08',
    lyrics: `Yeshu Masih deta khushi,
Yeshu Masih deta shifa,
Rooh-e-Quds ki aag barse,
Har dil mein ho Khuda ka noor!

Aasmaan khulta hai jab hum gaate,
Masih ki hamd-o-sana karte,
Toot ti hain zanjeerein saari,
Azaadi deta hai Masih Huzoor!`,
  },
  {
    id: 'geet-khuda-ki-mohabbat',
    title: 'Khuda Ki Mohabbat Ajeeb Hai',
    subtitle: 'Peace & Prayer Geet',
    category: 'peace',
    duration: '4:30',
    lyrics: `Khuda ki mohabbat ajeeb hai,
Kareem hai, azeem hai.
Dunya se aisi ulfat ki,
Bakhsha yakta Beta usne.

 صلیب par us ne jaan de kar,
Hum sab ko azaad kiya.
Nijaat ka rasta khol diya,
Hamesha ki zindagi ata ki.`,
  },
  {
    id: 'morning-worship',
    title: 'Subah Ki Barkat (Morning Praise)',
    subtitle: 'Dawn Prayer & Reflection',
    category: 'morning',
    duration: '6:15',
    lyrics: `Nayi subah, naya reham,
Tere huzoor sir jhukate hain.
Suraj nikla, noor phaila,
Kalaam ki roshni mein aate hain.

Khudaawand tere hathon mein,
Aaj ka din sonpte hain.
Har qadam par saath reh tu,
Teri rehmat dhoondhte hain.`,
  },
  {
    id: 'night-worship',
    title: 'Raat Ki Shanti (Night Peace)',
    subtitle: 'Evening Meditation & Calm',
    category: 'night',
    duration: '5:50',
    lyrics: `Shaam dhal gayi, raat aayi,
Par tera wada qayam hai.
Main aaraam se so jaaoonga,
Kyunki tu hi mera salaam hai.

Pankhon tale chhupa le tu,
Khauf-o-khatar se bacha le tu.
Mubarak ho tera naam,
Har subah har shaam.`,
  },
];
