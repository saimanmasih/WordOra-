import fs from "fs";
import path from "path";
import { BIBLE_BOOKS } from "./bibleData";
import {
  ImportProgress,
  getImportProgress,
  saveImportProgress,
  fetchChapterHtml,
  parseChapterHtml,
  stageChapter,
  getStagedChapter,
  getVerifiedGenesis1To4,
  VerseContent,
} from "./importerCore";
import { rejectScriptureWrite, verifyBibleIntegrity } from "./bibleIntegrityLock";

const STAGING_DIR = path.join(process.cwd(), "src", "data", "urdu_bible_staging");
const FULL_DB_FILE = path.join(process.cwd(), "src", "data", "urdu_bible_full.json");

let isImportRunning = false;
let stopRequested = false;

export { getImportProgress, saveImportProgress } from "./importerCore";

export function isImporterActive() {
  return false; // Importer is permanently deactivated because dataset is locked
}

export function requestStopImport() {
  stopRequested = true;
}

export async function runFullBibleImport(onProgressUpdate?: (p: ImportProgress) => void): Promise<ImportProgress> {
  // REQUIREMENT 2: IMPORT PROTECTION
  // Any future Bible import system must NOT overwrite the locked dataset.
  const check = verifyBibleIntegrity();
  if (check.isValid && check.locked) {
    console.warn("[WORDORA IMPORT SHIELD]: Import attempted against locked authoritative dataset. REJECTED.");
    const progress = getImportProgress();
    progress.status = "completed";
    progress.errors = [
      "Import operation rejected: The authoritative 66-book Urdu Bible dataset is permanently locked and immutable."
    ];
    if (onProgressUpdate) onProgressUpdate(progress);
    rejectScriptureWrite("Full Bible Import");
  }

  if (isImportRunning) {
    return getImportProgress();
  }
  isImportRunning = true;
  stopRequested = false;

  const progress = getImportProgress();
  progress.status = "in_progress";
  progress.errors = [];
  progress.retries = 0;
  progress.skippedExisting = 0;
  progress.booksProcessed = 0;
  progress.totalBooks = BIBLE_BOOKS.length;
  if (!progress.startedAt) {
    progress.startedAt = new Date().toISOString();
  }
  saveImportProgress(progress);
  if (onProgressUpdate) onProgressUpdate(progress);

  // STEP 1: Strict Genesis 1-4 preservation check & staging
  console.log("[Importer] Verifying Genesis 1–4 immutable snapshot...");
  const gen1to4 = getVerifiedGenesis1To4();
  for (let ch = 1; ch <= 4; ch++) {
    const verifiedVerses = gen1to4[ch]?.ur;
    if (!verifiedVerses || verifiedVerses.length === 0) {
      throw new Error(`Critical: Genesis ${ch} missing from verified snapshot!`);
    }
    stageChapter("genesis", ch, verifiedVerses);
  }
  progress.preservedGenesis1To4 = true;
  saveImportProgress(progress);

  // Build task list of all chapters across all 66 books
  interface ChapterTask {
    bookId: string;
    bookName: string;
    usfmAbbr: string;
    chapter: number;
    testament: "OT" | "NT";
  }

  const tasks: ChapterTask[] = [];
  for (const book of BIBLE_BOOKS) {
    const usfmAbbr = book.abbreviation.toUpperCase();
    for (let ch = 1; ch <= book.chaptersCount; ch++) {
      tasks.push({
        bookId: book.id,
        bookName: book.name,
        usfmAbbr,
        chapter: ch,
        testament: book.testament,
      });
    }
  }

  // Helper to calculate books completed
  const checkBooksProcessed = () => {
    let count = 0;
    for (const b of BIBLE_BOOKS) {
      let allDone = true;
      for (let ch = 1; ch <= b.chaptersCount; ch++) {
        if (!getStagedChapter(b.id, ch)) {
          allDone = false;
          break;
        }
      }
      if (allDone) count++;
    }
    return count;
  };

  // STEP 2: Concurrently process chapters with controlled concurrency (5 workers)
  const CONCURRENCY = 5;
  let taskIndex = 0;
  let completedChCount = 0;
  let totalVersesCount = 0;

  // Initialize count of already staged
  for (const t of tasks) {
    const staged = getStagedChapter(t.bookId, t.chapter);
    if (staged && staged.length > 0) {
      completedChCount++;
      totalVersesCount += staged.length;
      if (!(t.bookId === "genesis" && t.chapter <= 4)) {
        progress.skippedExisting++;
      }
    }
  }
  progress.completedChapters = completedChCount;
  progress.totalVerses = totalVersesCount;
  progress.booksProcessed = checkBooksProcessed();
  saveImportProgress(progress);

  async function worker() {
    while (taskIndex < tasks.length && !stopRequested) {
      const currentIdx = taskIndex++;
      const task = tasks[currentIdx];
      if (!task) break;

      // Check if already staged (including Genesis 1-4)
      const existing = getStagedChapter(task.bookId, task.chapter);
      if (existing && existing.length > 0) {
        continue;
      }

      progress.currentBook = task.bookName;
      progress.currentChapter = task.chapter;

      const usfm = `${task.usfmAbbr}.${task.chapter}`;
      let verses: VerseContent[] = [];
      let retriesLeft = 3;

      while (retriesLeft > 0 && verses.length === 0 && !stopRequested) {
        try {
          const html = await fetchChapterHtml(usfm);
          verses = parseChapterHtml(html);
        } catch (err: any) {
          console.warn(`[Importer] Error fetching ${usfm}:`, err.message);
        }

        if (verses.length === 0) {
          progress.retries++;
          retriesLeft--;
          if (retriesLeft > 0 && !stopRequested) {
            await new Promise((r) => setTimeout(r, 600));
          }
        }
      }

      if (verses.length === 0) {
        const msg = `Failed to fetch ${task.bookName} ${task.chapter} (${usfm})`;
        console.error(`[Importer] ${msg}`);
        progress.errors.push(msg);
      } else {
        stageChapter(task.bookId, task.chapter, verses);
        completedChCount++;
        totalVersesCount += verses.length;
        progress.completedChapters = completedChCount;
        progress.totalVerses = totalVersesCount;
        progress.booksProcessed = checkBooksProcessed();
      }

      saveImportProgress(progress);
      if (onProgressUpdate) onProgressUpdate(progress);

      // Brief throttle between chapters
      await new Promise((r) => setTimeout(r, 25));
    }
  }

  // Launch workers
  const workerPromises: Promise<void>[] = [];
  for (let i = 0; i < CONCURRENCY; i++) {
    workerPromises.push(worker());
  }
  await Promise.all(workerPromises);

  if (stopRequested) {
    console.log("[Importer] Import paused by user request.");
    progress.status = "paused";
    saveImportProgress(progress);
    isImportRunning = false;
    if (onProgressUpdate) onProgressUpdate(progress);
    return progress;
  }

  // STEP 3: Verification Phase
  console.log("[Importer] Entering Verification Phase...");
  progress.status = "verifying";
  saveImportProgress(progress);
  if (onProgressUpdate) onProgressUpdate(progress);

  const fullBibleRecord: Record<string, Record<number, { ur: VerseContent[] }>> = {};
  const verifyErrors: string[] = [];
  let finalVerseCount = 0;
  let finalChapterCount = 0;
  let otCount = 0;
  let ntCount = 0;
  let emptyVersesCount = 0;

  for (const book of BIBLE_BOOKS) {
    fullBibleRecord[book.id] = {};
    for (let ch = 1; ch <= book.chaptersCount; ch++) {
      const staged = getStagedChapter(book.id, ch);
      if (!staged || staged.length === 0) {
        verifyErrors.push(`Missing chapter: ${book.name} ${ch}`);
      } else {
        for (const v of staged) {
          if (!v.text || v.text.trim().length === 0) {
            emptyVersesCount++;
          }
        }
        fullBibleRecord[book.id][ch] = { ur: staged };
        finalVerseCount += staged.length;
        finalChapterCount++;
        if (book.testament === "OT") otCount++;
        else ntCount++;
      }
    }
  }

  if (emptyVersesCount > 0) {
    verifyErrors.push(`Found ${emptyVersesCount} empty verses in dataset`);
  }

  // Verify Genesis 1-4 are 100% untouched
  const g1to4Ref = getVerifiedGenesis1To4();
  for (let ch = 1; ch <= 4; ch++) {
    const stagedG = fullBibleRecord.genesis[ch]?.ur;
    const refG = g1to4Ref[ch]?.ur;
    if (JSON.stringify(stagedG) !== JSON.stringify(refG)) {
      verifyErrors.push(`CRITICAL: Genesis ${ch} does not match verified snapshot!`);
    }
  }

  if (verifyErrors.length > 0) {
    console.error("[Importer] Verification failed with errors:", verifyErrors);
    progress.status = "error";
    progress.errors = verifyErrors;
    saveImportProgress(progress);
    isImportRunning = false;
    if (onProgressUpdate) onProgressUpdate(progress);
    return progress;
  }

  // STEP 4: Commit Phase
  console.log(`[Importer] Verification passed! Committing full Bible dataset (${finalChapterCount} chapters, ${finalVerseCount} verses)...`);
  fs.writeFileSync(FULL_DB_FILE, JSON.stringify(fullBibleRecord), "utf8");

  progress.status = "completed";
  progress.completedChapters = finalChapterCount;
  progress.totalVerses = finalVerseCount;
  progress.booksProcessed = BIBLE_BOOKS.length;
  progress.errors = [];
  saveImportProgress(progress);
  isImportRunning = false;
  if (onProgressUpdate) onProgressUpdate(progress);

  console.log("[Importer] Full Bible Import successfully completed and committed!");
  return progress;
}
