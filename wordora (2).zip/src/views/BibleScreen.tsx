import React, { useState } from 'react';
import { Search, ChevronRight, ChevronLeft, BookOpen, Plus, Sparkles, Filter } from 'lucide-react';
import { BIBLE_BOOKS } from '../data/bibleData';
import { BibleBook, TranslationId } from '../types';
import { ChapterSelectionScreen } from '../components/ChapterSelectionScreen';

interface BibleScreenProps {
  onSelectBook: (bookId: string, chapter?: number) => void;
  onOpenSearch: () => void;
  selectedTranslation: TranslationId;
  selectedBookId?: string | null;
  onSelectBookId?: (bookId: string | null) => void;
  onBackToHome?: () => void;
  currentReadingChapter?: number;
}

export const BibleScreen: React.FC<BibleScreenProps> = ({
  onSelectBook,
  onOpenSearch,
  selectedTranslation,
  selectedBookId,
  onSelectBookId,
  onBackToHome,
  currentReadingChapter,
}) => {
  const [internalBookId, setInternalBookId] = useState<string | null>(null);
  const [activeTestament, setActiveTestament] = useState<'ALL' | 'OT' | 'NT'>('OT');
  const [searchFilter, setSearchFilter] = useState('');

  const activeBookId = selectedBookId !== undefined ? selectedBookId : internalBookId;

  const handleSelectBook = (bookId: string) => {
    if (onSelectBookId) {
      onSelectBookId(bookId);
    } else {
      setInternalBookId(bookId);
    }
  };

  const handleBackFromChapters = () => {
    if (onSelectBookId) {
      onSelectBookId(null);
    } else {
      setInternalBookId(null);
    }
  };

  // If a book is selected, render the dedicated Chapter Selection screen
  if (activeBookId) {
    return (
      <ChapterSelectionScreen
        bookId={activeBookId}
        onSelectChapter={(chapter) => onSelectBook(activeBookId, chapter)}
        onBack={handleBackFromChapters}
        selectedTranslation={selectedTranslation}
        currentChapter={currentReadingChapter}
      />
    );
  }

  const otBooks = BIBLE_BOOKS.filter(b => b.testament === 'OT');
  const ntBooks = BIBLE_BOOKS.filter(b => b.testament === 'NT');

  const filteredBooks = BIBLE_BOOKS.filter(b => {
    const matchesTestament = activeTestament === 'ALL' || b.testament === activeTestament;
    const matchesSearch =
      b.name.toLowerCase().includes(searchFilter.toLowerCase()) ||
      (b.romanUrduName && b.romanUrduName.toLowerCase().includes(searchFilter.toLowerCase())) ||
      (b.urduName && b.urduName.includes(searchFilter));
    return matchesTestament && matchesSearch;
  });

  return (
    <div className="flex-1 overflow-y-auto px-4 py-3 space-y-4 pb-24">
      {/* Top Bible Title & Search Row */}
      <div className="flex items-center justify-between pt-1">
        <div className="flex items-center gap-2">
          {onBackToHome && (
            <button
              type="button"
              onClick={onBackToHome}
              id="btn-bible-back-home"
              className="w-10 h-10 rounded-xl bg-[#0F1A2E] border border-[#1F2A44] flex items-center justify-center text-[#B6C0D1] hover:text-[#F7F6F2] active:scale-95 transition-all"
              aria-label="Back to Home"
            >
              <ChevronLeft className="w-5 h-5 text-[#F5D77A]" />
            </button>
          )}
          <h1 className="text-xl font-bold text-[#F7F6F2] font-serif-sacred tracking-wide flex items-center gap-2">
            <span>Bible</span>
            <span className="text-xs px-2 py-0.5 rounded-full bg-[#111A2E] border border-[#1F2A44] text-[#D4AF37] font-sans font-semibold uppercase">
              {selectedTranslation || 'None'}
            </span>
          </h1>
        </div>

        <button
          type="button"
          onClick={onOpenSearch}
          className="w-10 h-10 rounded-xl bg-[#0F1A2E] border border-[#1F2A44] flex items-center justify-center text-[#00C6FF] hover:border-[#00C6FF]/60 active:scale-95 transition-all"
          aria-label="Search Scripture"
        >
          <Search className="w-5 h-5" />
        </button>
      </div>

      {/* Large Category Cards (As in Reference: OLD TESTAMENT 39 Books (Gold) & NEW TESTAMENT 27 Books (Cyan/Blue)) */}
      <div className="grid grid-cols-2 gap-3">
        {/* OLD TESTAMENT CARD */}
        <div
          onClick={() => setActiveTestament('OT')}
          className={`p-4 rounded-2xl border cursor-pointer transition-all active:scale-[0.98] flex flex-col items-center justify-center text-center ${
            activeTestament === 'OT'
              ? 'bg-[#0F1A2E] border-[#D4AF37] gold-glow-subtle'
              : 'bg-[#0F1A2E]/70 border-[#1F2A44] hover:border-[#D4AF37]/50'
          }`}
        >
          {/* Ark / Ten Commandments Gold Graphic Icon */}
          <div className="w-12 h-12 rounded-xl bg-[#081220] border border-[#D4AF37]/60 flex items-center justify-center text-[#F5D77A] mb-2.5 shadow-inner">
            <svg viewBox="0 0 24 24" className="w-6 h-6 fill-none stroke-current stroke-[1.8]">
              {/* Ark / Two stone tablets */}
              <rect x="4" y="5" width="7" height="14" rx="3" />
              <rect x="13" y="5" width="7" height="14" rx="3" />
              <line x1="6" y1="9" x2="9" y2="9" />
              <line x1="6" y1="12" x2="9" y2="12" />
              <line x1="15" y1="9" x2="18" y2="9" />
              <line x1="15" y1="12" x2="18" y2="12" />
            </svg>
          </div>

          <span className="text-xs font-bold font-serif-sacred tracking-wider text-[#F5D77A]">
            OLD TESTAMENT
          </span>
          <span className="text-[11px] text-[#B6C0D1] mt-0.5">
            39 Books
          </span>
        </div>

        {/* NEW TESTAMENT CARD */}
        <div
          onClick={() => setActiveTestament('NT')}
          className={`p-4 rounded-2xl border cursor-pointer transition-all active:scale-[0.98] flex flex-col items-center justify-center text-center ${
            activeTestament === 'NT'
              ? 'bg-[#0F1A2E] border-[#00C6FF] cyan-glow-subtle'
              : 'bg-[#0F1A2E]/70 border-[#1F2A44] hover:border-[#00C6FF]/50'
          }`}
        >
          {/* Blue/Cyan Latin Cross Icon */}
          <div className="w-12 h-12 rounded-xl bg-[#081220] border border-[#00C6FF]/60 flex items-center justify-center text-[#00C6FF] mb-2.5 shadow-inner">
            <span className="text-2xl font-serif-sacred font-bold leading-none">✝</span>
          </div>

          <span className="text-xs font-bold font-serif-sacred tracking-wider text-[#00C6FF]">
            NEW TESTAMENT
          </span>
          <span className="text-[11px] text-[#B6C0D1] mt-0.5">
            27 Books
          </span>
        </div>
      </div>

      {/* Search Input within Bible screen */}
      <div className="relative">
        <input
          type="text"
          value={searchFilter}
          onChange={(e) => setSearchFilter(e.target.value)}
          placeholder="Filter books (e.g. Genesis, Matthew, Zaboor...)"
          className="w-full bg-[#0F1A2E] border border-[#1F2A44] rounded-xl px-4 py-2.5 pl-10 text-xs text-[#F7F6F2] placeholder-[#7A869A] focus:outline-none focus:border-[#D4AF37] transition-colors"
        />
        <Search className="w-4 h-4 text-[#7A869A] absolute left-3.5 top-3" />
        {searchFilter && (
          <button
            type="button"
            onClick={() => setSearchFilter('')}
            className="absolute right-3 top-2.5 text-xs text-[#7A869A] hover:text-[#F7F6F2]"
          >
            Clear
          </button>
        )}
      </div>

      {/* Book List Header */}
      <div className="flex items-center justify-between px-1">
        <h2 className="text-xs font-bold uppercase tracking-wider text-[#F5D77A]">
          {activeTestament === 'OT' ? 'Old Testament' : activeTestament === 'NT' ? 'New Testament' : 'All Books'}
        </h2>
        <span className="text-xs text-[#7A869A]">
          {filteredBooks.length} Books
        </span>
      </div>

      {/* Books Table / Rows (As seen in Reference: Dark navy rows, thin borders, small scripture book icon, book name, arrow) */}
      <div className="rounded-2xl border border-[#1F2A44] bg-[#0F1A2E] divide-y divide-[#1F2A44] overflow-hidden shadow-lg">
        {filteredBooks.map((book) => {
          const isOT = book.testament === 'OT';
          const secondaryName = selectedTranslation === 'ru'
            ? book.romanUrduName
            : selectedTranslation === 'ur'
            ? book.urduName
            : book.romanUrduName;

          return (
            <div
              key={book.id}
              id={`book-row-${book.id}`}
              onClick={() => handleSelectBook(book.id)}
              className="px-4 py-3.5 flex items-center justify-between hover:bg-[#111A2E] cursor-pointer transition-colors active:bg-[#1E3A8A]/20 group"
            >
              <div className="flex items-center gap-3">
                {/* Small Scripture/book icon with + (as in reference image) */}
                <div
                  className={`w-7 h-7 rounded-lg border flex items-center justify-center text-xs flex-shrink-0 ${
                    isOT
                      ? 'border-[#D4AF37]/50 text-[#F5D77A] bg-[#081220]'
                      : 'border-[#00C6FF]/50 text-[#00C6FF] bg-[#081220]'
                  }`}
                >
                  <Plus className="w-3.5 h-3.5 stroke-[2.5]" />
                </div>

                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-sm font-semibold text-[#F7F6F2] group-hover:text-[#FFF4D0] transition-colors">
                      {book.name}
                    </span>
                    {secondaryName && (
                      <span className="text-xs text-[#7A869A]">
                        ({secondaryName})
                      </span>
                    )}
                  </div>
                  <span className="text-[11px] text-[#7A869A]">
                    {book.chaptersCount} {book.chaptersCount === 1 ? 'Chapter' : 'Chapters'} • {book.category}
                  </span>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <ChevronRight className="w-4 h-4 text-[#7A869A] group-hover:text-[#F5D77A] group-hover:translate-x-0.5 transition-all" />
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
