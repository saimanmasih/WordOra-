import React, { useState, useEffect } from 'react';
import { Search, ChevronRight, BookOpen, X, Loader2, AlertCircle, Sparkles } from 'lucide-react';
import { BIBLE_BOOKS, TRANSLATIONS } from '../data/bibleData';
import { searchAuthoritativeScripture } from '../services/authoritativeBibleService';
import { TranslationId, BibleVerse } from '../types';

interface SearchScreenProps {
  onNavigateToVerse: (bookId: string, chapter: number, verse: number) => void;
  selectedTranslation: TranslationId;
}

export const SearchScreen: React.FC<SearchScreenProps> = ({
  onNavigateToVerse,
  selectedTranslation,
}) => {
  const [query, setQuery] = useState('');
  const [testamentFilter, setTestamentFilter] = useState<'ALL' | 'OT' | 'NT'>('ALL');
  const [currentTranslation, setCurrentTranslation] = useState<TranslationId>(selectedTranslation);
  const [results, setResults] = useState<BibleVerse[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const quickQueries = [
    'پَیدایش',
    'مُوسیٰ',
    'چَوپان',
    'محبّت',
    'رَوشنی',
    'قُربانی',
    'John 3:16',
    'Romans 8:1',
  ];

  // Debounced Search across full 66-book authoritative dataset
  useEffect(() => {
    const trimmed = query.trim();
    if (!trimmed) {
      setResults([]);
      setIsLoading(false);
      setError(null);
      return;
    }

    setIsLoading(true);
    setError(null);

    const controller = new AbortController();
    const timeoutId = setTimeout(async () => {
      try {
        const res = await fetch(
          `/api/scripture/search?q=${encodeURIComponent(trimmed)}&testament=${testamentFilter}&limit=120`,
          { signal: controller.signal }
        );
        if (!res.ok) {
          throw new Error(`Server returned ${res.status}`);
        }
        const data = await res.json();
        setResults(data.results || []);
        setIsLoading(false);
      } catch (err: any) {
        if (err.name === 'AbortError') return;
        // Fallback to local authoritative search (powers offline APK execution)
        const localResults = searchAuthoritativeScripture(trimmed, currentTranslation, testamentFilter);
        if (localResults.length > 0) {
          setResults(localResults);
          setIsLoading(false);
        } else {
          setError(err.message || 'Search failed. Please try again.');
          setIsLoading(false);
        }
      }
    }, 200);

    return () => {
      clearTimeout(timeoutId);
      controller.abort();
    };
  }, [query, testamentFilter, currentTranslation]);

  return (
    <div className="flex-1 overflow-y-auto px-4 py-3 space-y-4 pb-24">
      {/* Title */}
      <div className="pt-1">
        <h1 className="text-xl font-bold text-[#F7F6F2] font-serif-sacred tracking-wide">
          Search Scripture
        </h1>
        <p className="text-xs text-[#7A869A] mt-0.5">
          Search all 66 books, 1,189 chapters, and 31,103 verses in authoritative Urdu.
        </p>
      </div>

      {/* Search Input Box */}
      <div className="relative">
        <input
          type="text"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="Search Urdu text, e.g. 'مُوسیٰ', 'چَوپان', or 'John 3:16'..."
          className="w-full bg-[#0F1A2E] border border-[#1F2A44] focus:border-[#00C6FF] rounded-2xl px-4 py-3 pl-11 pr-10 text-sm text-[#F7F6F2] placeholder-[#7A869A] focus:outline-none transition-colors"
          autoFocus
        />
        <Search className="w-5 h-5 text-[#00C6FF] absolute left-3.5 top-3.5" />
        {query && (
          <button
            type="button"
            onClick={() => setQuery('')}
            className="w-7 h-7 rounded-full bg-[#081220] border border-[#1F2A44] flex items-center justify-center text-[#7A869A] hover:text-[#F7F6F2] absolute right-3 top-3 transition-colors"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        )}
      </div>

      {/* Filter Row: Testament & Translation */}
      <div className="flex items-center justify-between gap-2 overflow-x-auto pb-1">
        <div className="flex items-center gap-1.5">
          {(['ALL', 'OT', 'NT'] as const).map((t) => (
            <button
              key={t}
              type="button"
              onClick={() => setTestamentFilter(t)}
              className={`px-3 py-1 rounded-xl text-xs font-semibold transition-all whitespace-nowrap ${
                testamentFilter === t
                  ? 'bg-[#D4AF37] text-[#081220] shadow-sm'
                  : 'bg-[#0F1A2E] border border-[#1F2A44] text-[#B6C0D1] hover:text-white'
              }`}
            >
              {t === 'ALL' ? 'Entire Bible (66)' : t === 'OT' ? 'Old Testament (39)' : 'New Testament (27)'}
            </button>
          ))}
        </div>

        {/* Translation badge */}
        <select
          value={currentTranslation}
          onChange={(e) => setCurrentTranslation(e.target.value as TranslationId)}
          className="bg-[#0F1A2E] border border-[#1F2A44] text-xs font-bold text-[#00C6FF] rounded-xl px-2.5 py-1 focus:outline-none uppercase"
        >
          {TRANSLATIONS.length === 0 ? (
            <option value="ur">Urdu (v189)</option>
          ) : (
            TRANSLATIONS.map((t) => (
              <option key={t.id} value={t.id}>
                {t.name}
              </option>
            ))
          )}
        </select>
      </div>

      {/* Suggested Quick Tags (Empty State) */}
      {!query && (
        <div className="space-y-3 pt-2">
          <div className="flex items-center gap-1.5 text-xs font-bold uppercase tracking-wider text-[#7A869A]">
            <Sparkles className="w-3.5 h-3.5 text-[#D4AF37]" />
            <span>Popular Themes & References</span>
          </div>
          <div className="flex flex-wrap gap-2">
            {quickQueries.map((tag) => (
              <button
                key={tag}
                type="button"
                onClick={() => setQuery(tag)}
                className="px-3.5 py-1.5 rounded-xl bg-[#0F1A2E] border border-[#1F2A44] hover:border-[#00C6FF]/60 text-xs font-medium text-[#F7F6F2] active:scale-95 transition-all"
              >
                #{tag}
              </button>
            ))}
          </div>

          <div className="mt-8 p-5 rounded-2xl bg-[#0F1A2E]/60 border border-[#1F2A44] text-center space-y-2">
            <BookOpen className="w-8 h-8 text-[#D4AF37] mx-auto opacity-70" />
            <h3 className="text-sm font-semibold text-[#F7F6F2]">
              Instant Full-Bible Search
            </h3>
            <p className="text-xs text-[#7A869A] max-w-sm mx-auto leading-relaxed">
              Search any Urdu phrase or verse reference across all 66 books and 31,103 verses of کِتابِ مُقادّس.
            </p>
          </div>
        </div>
      )}

      {/* Loading State */}
      {query && isLoading && (
        <div className="p-8 text-center rounded-2xl bg-[#0F1A2E] border border-[#1F2A44] space-y-3">
          <Loader2 className="w-7 h-7 text-[#00C6FF] animate-spin mx-auto" />
          <p className="text-xs text-[#B6C0D1] font-medium">
            Searching all 66 books and 31,103 verses...
          </p>
        </div>
      )}

      {/* Error State */}
      {query && !isLoading && error && (
        <div className="p-6 text-center rounded-2xl bg-rose-950/20 border border-rose-800/40 space-y-3">
          <AlertCircle className="w-7 h-7 text-rose-400 mx-auto" />
          <h3 className="text-sm font-semibold text-rose-200">
            Search Error
          </h3>
          <p className="text-xs text-rose-300/80">
            {error}
          </p>
        </div>
      )}

      {/* Results Header */}
      {query && !isLoading && !error && (
        <div className="flex items-center justify-between px-1">
          <span className="text-xs font-bold uppercase tracking-wider text-[#B6C0D1]">
            Search Results ({results.length}{results.length >= 120 ? '+' : ''})
          </span>
          <span className="text-[11px] text-[#7A869A]">
            Authoritative Version 189
          </span>
        </div>
      )}

      {/* Results List */}
      {query && !isLoading && !error && results.length > 0 && (
        <div className="space-y-2.5">
          {results.map((item) => {
            const book = BIBLE_BOOKS.find((b) => b.id === item.bookId);
            const isUrdu = item.translation === 'ur' || !item.translation;
            return (
              <div
                key={`${item.bookId}-${item.chapter}-${item.verse}`}
                onClick={() => onNavigateToVerse(item.bookId, item.chapter, item.verse)}
                className="p-4 rounded-2xl bg-[#0F1A2E] border border-[#1F2A44] hover:border-[#00C6FF]/60 cursor-pointer transition-all active:scale-[0.99] group shadow-sm"
              >
                <div className="flex items-center justify-between pb-2 border-b border-[#1F2A44]/60">
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-bold font-serif-sacred text-[#F5D77A]">
                      {book?.name || item.bookId} {item.chapter}:{item.verse}
                    </span>
                    {book?.urduName && (
                      <span className="text-xs font-urdu font-bold text-[#D4AF37]">
                        ({book.urduName})
                      </span>
                    )}
                    <span className="text-[9px] px-1.5 py-0.5 rounded bg-[#081220] border border-[#1F2A44] text-[#00C6FF] font-semibold uppercase">
                      {book?.testament || 'BIBLE'}
                    </span>
                  </div>

                  <ChevronRight className="w-4 h-4 text-[#7A869A] group-hover:text-[#00C6FF] transition-colors flex-shrink-0" />
                </div>

                {/* Source section heading if present */}
                {item.sectionHeading && (
                  <div className="pt-2 text-right">
                    <span className="text-xs font-bold text-[#D4AF37] font-urdu">
                      {item.sectionHeading}
                    </span>
                  </div>
                )}

                {/* Verse Text with exact RTL Urdu */}
                <p
                  className={`mt-2 text-sm text-[#F7F6F2] leading-relaxed line-clamp-3 ${
                    isUrdu ? 'text-right font-urdu rtl' : 'text-left font-serif'
                  }`}
                >
                  {item.text}
                </p>
              </div>
            );
          })}
        </div>
      )}

      {/* Empty Results State */}
      {query && !isLoading && !error && results.length === 0 && (
        <div className="p-8 text-center rounded-2xl bg-[#0F1A2E] border border-[#1F2A44] space-y-2">
          <BookOpen className="w-8 h-8 text-[#7A869A] mx-auto opacity-50" />
          <h3 className="text-sm font-semibold text-[#F7F6F2]">
            No verses found
          </h3>
          <p className="text-xs text-[#7A869A] max-w-xs mx-auto leading-relaxed">
            No verses found matching "{query}". Try checking alternate spelling or switching the testament filter.
          </p>
        </div>
      )}
    </div>
  );
};
