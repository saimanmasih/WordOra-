import React, { useState } from 'react';
import { Bookmark, Highlighter, FileText, ChevronRight, Trash2, ArrowRight } from 'lucide-react';
import { BookmarkItem, HighlightItem, NoteItem } from '../types';
import { BIBLE_BOOKS } from '../data/bibleData';

interface SavedScreenProps {
  initialTab?: 'bookmarks' | 'highlights' | 'notes';
  bookmarks: BookmarkItem[];
  highlights: HighlightItem[];
  notes: NoteItem[];
  onDeleteBookmark: (id: string) => void;
  onDeleteHighlight: (id: string) => void;
  onDeleteNote: (id: string) => void;
  onNavigateToVerse: (bookId: string, chapter: number, verse: number) => void;
}

export const SavedScreen: React.FC<SavedScreenProps> = ({
  initialTab = 'bookmarks',
  bookmarks,
  highlights,
  notes,
  onDeleteBookmark,
  onDeleteHighlight,
  onDeleteNote,
  onNavigateToVerse,
}) => {
  const [activeTab, setActiveTab] = useState<'bookmarks' | 'highlights' | 'notes'>(initialTab);

  return (
    <div className="flex-1 overflow-y-auto px-4 py-3 space-y-4 pb-24">
      {/* Header */}
      <div className="pt-1">
        <h1 className="text-xl font-bold text-[#F7F6F2] font-serif-sacred tracking-wide">
          Saved Scripture
        </h1>
        <p className="text-xs text-[#7A869A] mt-0.5">
          Your bookmarked passages, illuminated verses, and personal study notes.
        </p>
      </div>

      {/* Tabs */}
      <div className="grid grid-cols-3 gap-2 p-1 rounded-2xl bg-[#0F1A2E] border border-[#1F2A44]">
        <button
          type="button"
          onClick={() => setActiveTab('bookmarks')}
          className={`py-2 px-1 rounded-xl text-xs font-semibold flex items-center justify-center gap-1.5 transition-all ${
            activeTab === 'bookmarks'
              ? 'bg-[#111A2E] text-[#F5D77A] border border-[#D4AF37]/50 shadow-sm'
              : 'text-[#B6C0D1] hover:text-[#F7F6F2]'
          }`}
        >
          <Bookmark className="w-3.5 h-3.5" />
          <span>Bookmarks ({bookmarks.length})</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('highlights')}
          className={`py-2 px-1 rounded-xl text-xs font-semibold flex items-center justify-center gap-1.5 transition-all ${
            activeTab === 'highlights'
              ? 'bg-[#111A2E] text-[#00C6FF] border border-[#00C6FF]/50 shadow-sm'
              : 'text-[#B6C0D1] hover:text-[#F7F6F2]'
          }`}
        >
          <Highlighter className="w-3.5 h-3.5" />
          <span>Highlights ({highlights.length})</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('notes')}
          className={`py-2 px-1 rounded-xl text-xs font-semibold flex items-center justify-center gap-1.5 transition-all ${
            activeTab === 'notes'
              ? 'bg-[#111A2E] text-[#D4AF37] border border-[#D4AF37]/50 shadow-sm'
              : 'text-[#B6C0D1] hover:text-[#F7F6F2]'
          }`}
        >
          <FileText className="w-3.5 h-3.5" />
          <span>Notes ({notes.length})</span>
        </button>
      </div>

      {/* BOOKMARKS LIST */}
      {activeTab === 'bookmarks' && (
        <div className="space-y-3">
          {bookmarks.length === 0 ? (
            <div className="p-8 text-center rounded-2xl bg-[#0F1A2E] border border-[#1F2A44] space-y-2">
              <Bookmark className="w-8 h-8 text-[#7A869A] mx-auto opacity-50" />
              <p className="text-xs text-[#7A869A]">
                No bookmarks yet. Tap the bookmark icon while reading any chapter.
              </p>
            </div>
          ) : (
            bookmarks.map((bm) => {
              const book = BIBLE_BOOKS.find(b => b.id === bm.bookId);
              return (
                <div
                  key={bm.id}
                  className="p-4 rounded-2xl bg-[#0F1A2E] border border-[#1F2A44] hover:border-[#D4AF37]/60 transition-all space-y-2 group shadow-sm"
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-bold font-serif-sacred text-[#F5D77A]">
                        {book?.name || bm.bookId} {bm.chapter}:{bm.verse}
                      </span>
                      <span className="text-[10px] px-1.5 py-0.5 rounded bg-[#081220] text-[#7A869A] uppercase">
                        {bm.translation}
                      </span>
                    </div>

                    <button
                      type="button"
                      onClick={() => onDeleteBookmark(bm.id)}
                      className="p-1 text-[#7A869A] hover:text-red-400"
                      title="Remove Bookmark"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>

                  <p className="text-xs text-[#F7F6F2] leading-relaxed italic font-serif">
                    “{bm.text}”
                  </p>

                  <div className="pt-2 flex justify-end">
                    <button
                      type="button"
                      onClick={() => onNavigateToVerse(bm.bookId, bm.chapter, bm.verse)}
                      className="inline-flex items-center gap-1 text-xs font-semibold text-[#00C6FF] hover:underline"
                    >
                      <span>Read in Context</span>
                      <ChevronRight className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              );
            })
          )}
        </div>
      )}

      {/* HIGHLIGHTS LIST */}
      {activeTab === 'highlights' && (
        <div className="space-y-3">
          {highlights.length === 0 ? (
            <div className="p-8 text-center rounded-2xl bg-[#0F1A2E] border border-[#1F2A44] space-y-2">
              <Highlighter className="w-8 h-8 text-[#7A869A] mx-auto opacity-50" />
              <p className="text-xs text-[#7A869A]">
                No highlighted verses yet. Select any verse in the reader to illuminate it.
              </p>
            </div>
          ) : (
            highlights.map((hl) => {
              const book = BIBLE_BOOKS.find(b => b.id === hl.bookId);
              return (
                <div
                  key={hl.id}
                  className="p-4 rounded-2xl bg-[#0F1A2E] border border-[#1F2A44] hover:border-[#00C6FF]/60 transition-all space-y-2 shadow-sm"
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-bold font-serif-sacred text-[#F7F6F2]">
                        {book?.name || hl.bookId} {hl.chapter}:{hl.verse}
                      </span>
                      <span
                        className={`text-[10px] px-2 py-0.5 rounded-full capitalize font-semibold ${
                          hl.color === 'gold'
                            ? 'bg-[#D4AF37]/20 text-[#F5D77A]'
                            : hl.color === 'cyan'
                            ? 'bg-[#00C6FF]/20 text-[#00C6FF]'
                            : hl.color === 'emerald'
                            ? 'bg-emerald-500/20 text-emerald-300'
                            : 'bg-rose-500/20 text-rose-300'
                        }`}
                      >
                        {hl.color}
                      </span>
                    </div>

                    <button
                      type="button"
                      onClick={() => onDeleteHighlight(hl.id)}
                      className="p-1 text-[#7A869A] hover:text-red-400"
                      title="Remove Highlight"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>

                  <p className="text-xs text-[#F7F6F2] leading-relaxed font-serif">
                    {hl.text}
                  </p>

                  <div className="pt-2 flex justify-end">
                    <button
                      type="button"
                      onClick={() => onNavigateToVerse(hl.bookId, hl.chapter, hl.verse)}
                      className="inline-flex items-center gap-1 text-xs font-semibold text-[#00C6FF] hover:underline"
                    >
                      <span>Open Verse</span>
                      <ChevronRight className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              );
            })
          )}
        </div>
      )}

      {/* NOTES LIST */}
      {activeTab === 'notes' && (
        <div className="space-y-3">
          {notes.length === 0 ? (
            <div className="p-8 text-center rounded-2xl bg-[#0F1A2E] border border-[#1F2A44] space-y-2">
              <FileText className="w-8 h-8 text-[#7A869A] mx-auto opacity-50" />
              <p className="text-xs text-[#7A869A]">
                No study notes yet. Tap any verse in the reader and select "Note".
              </p>
            </div>
          ) : (
            notes.map((note) => {
              const book = BIBLE_BOOKS.find(b => b.id === note.bookId);
              return (
                <div
                  key={note.id}
                  className="p-4 rounded-2xl bg-[#0F1A2E] border border-[#1F2A44] hover:border-[#D4AF37]/60 transition-all space-y-2.5 shadow-sm"
                >
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold font-serif-sacred text-[#F5D77A]">
                      {book?.name || note.bookId} {note.chapter}:{note.verse}
                    </span>

                    <button
                      type="button"
                      onClick={() => onDeleteNote(note.id)}
                      className="p-1 text-[#7A869A] hover:text-red-400"
                      title="Delete Note"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>

                  <p className="text-xs text-[#7A869A] line-clamp-2 italic font-serif">
                    “{note.verseText}”
                  </p>

                  <div className="p-3 rounded-xl bg-[#081220] border border-[#1F2A44] text-xs text-[#F7F6F2] leading-relaxed">
                    {note.noteText}
                  </div>

                  <div className="pt-1 flex justify-end">
                    <button
                      type="button"
                      onClick={() => onNavigateToVerse(note.bookId, note.chapter, note.verse)}
                      className="inline-flex items-center gap-1 text-xs font-semibold text-[#00C6FF] hover:underline"
                    >
                      <span>View Passage</span>
                      <ChevronRight className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              );
            })
          )}
        </div>
      )}
    </div>
  );
};
