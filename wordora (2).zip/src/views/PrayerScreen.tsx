import React, { useState } from 'react';
import { Plus, Check, Heart, Bell, Trash2, Sparkles, Clock, CheckCircle } from 'lucide-react';
import { PrayerItem } from '../types';

interface PrayerScreenProps {
  prayers: PrayerItem[];
  onAddPrayer: (title: string, content: string, category: 'personal' | 'family' | 'healing' | 'community') => void;
  onMarkAnswered: (id: string, testimony?: string) => void;
  onIncrementPrayerCount: (id: string) => void;
  onDeletePrayer: (id: string) => void;
  reminderEnabled: boolean;
  reminderTime: string;
  onToggleReminder: () => void;
}

export const PrayerScreen: React.FC<PrayerScreenProps> = ({
  prayers,
  onAddPrayer,
  onMarkAnswered,
  onIncrementPrayerCount,
  onDeletePrayer,
  reminderEnabled,
  reminderTime,
  onToggleReminder,
}) => {
  const [showAddModal, setShowAddModal] = useState(false);
  const [newTitle, setNewTitle] = useState('');
  const [newContent, setNewContent] = useState('');
  const [newCategory, setNewCategory] = useState<'personal' | 'family' | 'healing' | 'community'>('personal');

  const [activeTab, setActiveTab] = useState<'active' | 'answered'>('active');
  const [testimonyModalId, setTestimonyModalId] = useState<string | null>(null);
  const [testimonyText, setTestimonyText] = useState('');

  const activePrayers = prayers.filter(p => !p.isAnswered);
  const answeredPrayers = prayers.filter(p => p.isAnswered);

  const handleCreatePrayer = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim()) return;
    onAddPrayer(newTitle.trim(), newContent.trim(), newCategory);
    setNewTitle('');
    setNewContent('');
    setShowAddModal(false);
  };

  const handleConfirmAnswered = () => {
    if (testimonyModalId) {
      onMarkAnswered(testimonyModalId, testimonyText.trim() || undefined);
      setTestimonyModalId(null);
      setTestimonyText('');
    }
  };

  return (
    <div className="flex-1 overflow-y-auto px-4 py-3 space-y-4 pb-24">
      {/* Top Header */}
      <div className="flex items-center justify-between pt-1">
        <div>
          <h1 className="text-xl font-bold text-[#F7F6F2] font-serif-sacred tracking-wide">
            Prayer & Intercession
          </h1>
          <p className="text-xs text-[#7A869A] mt-0.5">
            Dua aur Iltija — bring every petition before Khuda.
          </p>
        </div>

        <button
          type="button"
          onClick={() => setShowAddModal(true)}
          className="px-3 py-2 rounded-xl bg-gradient-to-r from-[#D4AF37] to-[#F5D77A] text-[#081220] font-bold text-xs flex items-center gap-1.5 shadow-md active:scale-95 transition-all"
        >
          <Plus className="w-4 h-4" />
          <span>New Prayer</span>
        </button>
      </div>

      {/* Daily Reminder Card */}
      <div className="p-4 rounded-2xl bg-[#0F1A2E] border border-[#1F2A44] flex items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-[#081220] border border-[#00C6FF]/40 flex items-center justify-center text-[#00C6FF] cyan-glow-subtle">
            <Bell className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-xs font-bold uppercase tracking-wider text-[#B6C0D1]">
              Daily Prayer Bell
            </h3>
            <p className="text-xs text-[#F7F6F2] font-semibold mt-0.5">
              Every day at {reminderTime}
            </p>
          </div>
        </div>

        <button
          type="button"
          onClick={onToggleReminder}
          className={`relative inline-flex h-7 w-12 items-center rounded-full transition-colors ${
            reminderEnabled ? 'bg-[#00C6FF]' : 'bg-[#1F2A44]'
          }`}
        >
          <span
            className={`inline-block h-5 w-5 transform rounded-full bg-white transition-transform ${
              reminderEnabled ? 'translate-x-6' : 'translate-x-1'
            }`}
          />
        </button>
      </div>

      {/* Tabs: Active vs Answered */}
      <div className="grid grid-cols-2 gap-2 p-1 rounded-2xl bg-[#0F1A2E] border border-[#1F2A44]">
        <button
          type="button"
          onClick={() => setActiveTab('active')}
          className={`py-2 rounded-xl text-xs font-semibold flex items-center justify-center gap-2 transition-all ${
            activeTab === 'active'
              ? 'bg-[#111A2E] text-[#F5D77A] border border-[#D4AF37]/50 shadow-sm'
              : 'text-[#B6C0D1] hover:text-[#F7F6F2]'
          }`}
        >
          <span>Active Prayers</span>
          <span className="text-[10px] px-2 py-0.5 rounded-full bg-[#081220] text-[#F5D77A]">
            {activePrayers.length}
          </span>
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('answered')}
          className={`py-2 rounded-xl text-xs font-semibold flex items-center justify-center gap-2 transition-all ${
            activeTab === 'answered'
              ? 'bg-[#111A2E] text-[#00C6FF] border border-[#00C6FF]/50 shadow-sm'
              : 'text-[#B6C0D1] hover:text-[#F7F6F2]'
          }`}
        >
          <span>Answered Prayers</span>
          <span className="text-[10px] px-2 py-0.5 rounded-full bg-[#081220] text-[#00C6FF]">
            {answeredPrayers.length}
          </span>
        </button>
      </div>

      {/* PRAYER LIST */}
      <div className="space-y-3">
        {activeTab === 'active' && activePrayers.length === 0 && (
          <div className="p-8 text-center rounded-2xl bg-[#0F1A2E] border border-[#1F2A44] space-y-2">
            <span className="text-3xl">🕊️</span>
            <h3 className="text-sm font-semibold text-[#F7F6F2]">
              No active prayer petitions
            </h3>
            <p className="text-xs text-[#7A869A]">
              Tap "New Prayer" above to write your requests before God.
            </p>
          </div>
        )}

        {activeTab === 'answered' && answeredPrayers.length === 0 && (
          <div className="p-8 text-center rounded-2xl bg-[#0F1A2E] border border-[#1F2A44] space-y-2">
            <CheckCircle className="w-8 h-8 text-[#00C6FF] mx-auto opacity-50" />
            <h3 className="text-sm font-semibold text-[#F7F6F2]">
              No answered prayers recorded yet
            </h3>
            <p className="text-xs text-[#7A869A]">
              When Khuda answers your prayer, tap "Mark Answered" to preserve your testimony.
            </p>
          </div>
        )}

        {(activeTab === 'active' ? activePrayers : answeredPrayers).map((prayer) => (
          <div
            key={prayer.id}
            className="p-4 rounded-2xl bg-[#0F1A2E] border border-[#1F2A44] space-y-3 shadow-md"
          >
            <div className="flex items-start justify-between gap-3">
              <div>
                <div className="flex items-center gap-2">
                  <h3 className="text-sm font-bold text-[#F7F6F2]">
                    {prayer.title}
                  </h3>
                  <span className="text-[10px] px-2 py-0.5 rounded-full bg-[#081220] border border-[#1F2A44] text-[#F5D77A] font-semibold capitalize">
                    {prayer.category}
                  </span>
                </div>
                <p className="text-xs text-[#B6C0D1] mt-1 leading-relaxed">
                  {prayer.content}
                </p>
              </div>

              <button
                type="button"
                onClick={() => onDeletePrayer(prayer.id)}
                className="p-1 text-[#7A869A] hover:text-red-400"
                title="Delete"
              >
                <Trash2 className="w-4 h-4" />
              </button>
            </div>

            {/* Testimony if answered */}
            {prayer.isAnswered && prayer.testimony && (
              <div className="p-3 rounded-xl bg-[#081220] border border-[#00C6FF]/40 text-xs text-[#00C6FF] leading-relaxed">
                <span className="font-bold text-[#F5D77A] block mb-0.5">Testimony:</span>
                {prayer.testimony}
              </div>
            )}

            {/* Bottom Actions */}
            <div className="flex items-center justify-between pt-2 border-t border-[#1F2A44]/60 text-xs">
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => onIncrementPrayerCount(prayer.id)}
                  className="px-3 py-1.5 rounded-xl bg-[#081220] border border-[#1F2A44] hover:border-[#D4AF37]/50 text-xs font-medium text-[#F5D77A] flex items-center gap-1.5 active:scale-95 transition-all"
                  title="Prayed for this today"
                >
                  <span>🙏 Prayed ({prayer.prayerCount})</span>
                </button>
              </div>

              {!prayer.isAnswered && (
                <button
                  type="button"
                  onClick={() => setTestimonyModalId(prayer.id)}
                  className="px-3 py-1.5 rounded-xl bg-[#1E3A8A]/40 border border-[#2563EB]/40 hover:bg-[#2563EB] text-xs font-semibold text-[#00C6FF] hover:text-white flex items-center gap-1 active:scale-95 transition-all"
                >
                  <Check className="w-3.5 h-3.5 stroke-[3]" />
                  <span>Mark Answered</span>
                </button>
              )}
            </div>
          </div>
        ))}
      </div>

      {/* Add Prayer Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md">
          <form
            onSubmit={handleCreatePrayer}
            className="w-full max-w-sm rounded-2xl bg-[#0F1A2E] border border-[#1F2A44] p-5 shadow-2xl space-y-4"
          >
            <h3 className="text-sm font-bold text-[#F7F6F2] font-serif-sacred">
              Add Prayer Request
            </h3>

            <div className="space-y-1">
              <label className="text-[11px] text-[#7A869A] uppercase tracking-wider">
                Title
              </label>
              <input
                type="text"
                required
                value={newTitle}
                onChange={(e) => setNewTitle(e.target.value)}
                placeholder="e.g. Healing for Mother, Peace in Heart"
                className="w-full p-2.5 rounded-xl bg-[#081220] border border-[#1F2A44] text-xs text-[#F7F6F2] focus:outline-none focus:border-[#D4AF37]"
              />
            </div>

            <div className="space-y-1">
              <label className="text-[11px] text-[#7A869A] uppercase tracking-wider">
                Category
              </label>
              <select
                value={newCategory}
                onChange={(e) => setNewCategory(e.target.value as any)}
                className="w-full p-2.5 rounded-xl bg-[#081220] border border-[#1F2A44] text-xs text-[#F7F6F2] focus:outline-none focus:border-[#D4AF37]"
              >
                <option value="personal">Personal Spiritual Life</option>
                <option value="family">Family & Loved Ones</option>
                <option value="healing">Healing & Health</option>
                <option value="community">Community & Nation</option>
              </select>
            </div>

            <div className="space-y-1">
              <label className="text-[11px] text-[#7A869A] uppercase tracking-wider">
                Prayer Details
              </label>
              <textarea
                value={newContent}
                onChange={(e) => setNewContent(e.target.value)}
                placeholder="Write your prayers and specific requests..."
                rows={3}
                className="w-full p-2.5 rounded-xl bg-[#081220] border border-[#1F2A44] text-xs text-[#F7F6F2] focus:outline-none focus:border-[#D4AF37]"
              />
            </div>

            <div className="flex items-center justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setShowAddModal(false)}
                className="px-4 py-2 rounded-xl text-xs text-[#7A869A] hover:text-[#F7F6F2]"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-4 py-2 rounded-xl bg-gradient-to-r from-[#D4AF37] to-[#F5D77A] text-[#081220] text-xs font-bold uppercase tracking-wider shadow-md"
              >
                Save Prayer
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Answered Testimony Modal */}
      {testimonyModalId && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md">
          <div className="w-full max-w-sm rounded-2xl bg-[#0F1A2E] border border-[#1F2A44] p-5 shadow-2xl space-y-4">
            <div className="flex items-center gap-2">
              <Sparkles className="w-5 h-5 text-[#F5D77A]" />
              <h3 className="text-sm font-bold text-[#F7F6F2] font-serif-sacred">
                Khuda Ne Dua Suni (Praise God!)
              </h3>
            </div>
            <p className="text-xs text-[#B6C0D1]">
              Record your testimony of how the Lord answered this prayer.
            </p>

            <textarea
              value={testimonyText}
              onChange={(e) => setTestimonyText(e.target.value)}
              placeholder="What did Khuda do? How did He grant peace or answer this request?"
              rows={3}
              className="w-full p-2.5 rounded-xl bg-[#081220] border border-[#1F2A44] text-xs text-[#F7F6F2] focus:outline-none focus:border-[#00C6FF]"
            />

            <div className="flex items-center justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setTestimonyModalId(null)}
                className="px-4 py-2 rounded-xl text-xs text-[#7A869A] hover:text-[#F7F6F2]"
              >
                Skip
              </button>
              <button
                type="button"
                onClick={handleConfirmAnswered}
                className="px-4 py-2 rounded-xl bg-gradient-to-r from-[#00C6FF] to-[#2563EB] text-[#081220] text-xs font-bold uppercase tracking-wider shadow-md"
              >
                Record Answer
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
