import React from 'react';
import {
  BookOpen,
  Search,
  Music,
  Bot,
  CloudDownload,
  Bookmark,
  Highlighter,
  FileText,
  Share2,
  ArrowRight,
  Sparkles,
  ChevronRight,
  Bell,
  Clock,
  Check,
} from 'lucide-react';
import { ReadingProgress, TranslationId } from '../types';
import { TRANSLATIONS } from '../data/bibleData';

interface HomeScreenProps {
  onNavigateToBible: (bookId?: string, chapter?: number) => void;
  onNavigateToSearch: () => void;
  onNavigateToWorship: (trackId?: string) => void;
  onNavigateToPrayer: () => void;
  onNavigateToAI: (initialQuery?: string) => void;
  onNavigateToSaved: (tab?: 'bookmarks' | 'highlights' | 'notes') => void;
  onOpenTranslations: () => void;
  readingProgress: ReadingProgress;
  prayerReminderEnabled: boolean;
  onTogglePrayerReminder: () => void;
  onShareDailyVerse: () => void;
  onBookmarkDailyVerse: () => void;
  dailyVerseBookmarked: boolean;
}

export const HomeScreen: React.FC<HomeScreenProps> = ({
  onNavigateToBible,
  onNavigateToSearch,
  onNavigateToWorship,
  onNavigateToPrayer,
  onNavigateToAI,
  onNavigateToSaved,
  onOpenTranslations,
  readingProgress,
  prayerReminderEnabled,
  onTogglePrayerReminder,
  onShareDailyVerse,
  onBookmarkDailyVerse,
  dailyVerseBookmarked,
}) => {
  return (
    <div className="flex-1 overflow-y-auto px-4 py-4 space-y-5 pb-24">
      {/* 1. GREETING */}
      <div className="px-1 pt-1">
        <h1 className="text-2xl font-bold text-[#F7F6F2] font-serif-sacred tracking-tight">
          Good Morning!
        </h1>
        <p className="text-xs text-[#B6C0D1] mt-0.5 font-medium flex items-center gap-1.5">
          <span>May Khuda bless your day.</span>
          <span className="w-1.5 h-1.5 rounded-full bg-[#D4AF37]" />
        </p>
      </div>

      {/* 2. VERSE OF THE DAY CARD (As seen in the approved reference image) */}
      <div className="relative rounded-2xl p-5 bg-gradient-to-br from-[#0F1A2E] via-[#111A2E] to-[#081220] border border-[#1F2A44] shadow-xl overflow-hidden sacred-card-glow">
        {/* Subtle Sacred Gold & Cyan atmospheric light glow */}
        <div className="absolute -top-12 -right-12 w-48 h-48 bg-[#D4AF37]/15 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute -bottom-12 -left-12 w-40 h-40 bg-[#00C6FF]/10 rounded-full blur-2xl pointer-events-none" />

        <div className="relative z-10">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-1.5 text-xs font-semibold uppercase tracking-wider text-[#F5D77A]">
              <Sparkles className="w-3.5 h-3.5 text-[#F5D77A]" />
              <span>Verse of the Day</span>
            </div>

            <span className="text-[11px] px-2 py-0.5 rounded-full bg-[#1E3A8A]/40 border border-[#2563EB]/40 text-[#00C6FF] font-medium">
              Daily Light
            </span>
          </div>

          {TRANSLATIONS.length === 0 ? (
            <div className="my-4 p-5 rounded-xl bg-[#081220]/70 border border-[#1F2A44] text-center space-y-3">
              <div className="space-y-1">
                <p className="text-sm font-semibold font-serif-sacred text-[#F7F6F2]">
                  No Bible translation installed.
                </p>
                <p className="text-xs text-[#7A869A] leading-relaxed">
                  Add an authorized Bible translation to begin reading.
                </p>
              </div>
              <button
                type="button"
                onClick={onOpenTranslations}
                className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-gradient-to-r from-[#D4AF37] to-[#F5D77A] text-[#081220] text-xs font-bold uppercase tracking-wider active:scale-95 transition-all shadow-md"
              >
                <BookOpen className="w-3.5 h-3.5" />
                <span>Add Bible Translation</span>
              </button>
            </div>
          ) : (
            <>
              {/* Scripture Verse Text */}
              <blockquote className="mt-3.5 text-base sm:text-lg font-medium text-[#F7F6F2] leading-relaxed italic font-serif">
                “Your word is a lamp to my feet and a light to my path.”
              </blockquote>

              {/* Reference */}
              <div className="mt-2.5 text-xs font-semibold text-[#D4AF37] tracking-wide uppercase">
                Psalms 119:105
              </div>

              {/* Card Graphic: Glowing Bible & Cross silhouette (Matching Reference Graphic) */}
              <div className="my-3 py-1 flex items-center justify-end">
                <div className="relative w-36 h-20 flex items-center justify-center">
                  <svg viewBox="0 0 160 90" className="w-full h-full drop-shadow-[0_0_12px_rgba(212,175,55,0.4)]">
                    <defs>
                      <radialGradient id="verseFlare" cx="50%" cy="40%" r="50%">
                        <stop offset="0%" stopColor="#FFFFFF" stopOpacity="0.95" />
                        <stop offset="35%" stopColor="#F5D77A" stopOpacity="0.7" />
                        <stop offset="100%" stopColor="#D4AF37" stopOpacity="0" />
                      </radialGradient>
                    </defs>
                    {/* Light ray cone */}
                    <polygon points="80,10 20,85 140,85" fill="url(#verseFlare)" opacity="0.35" />
                    {/* Latin Cross radiating light */}
                    <rect x="77" y="15" width="6" height="42" rx="1.5" fill="#FFF9E6" />
                    <rect x="66" y="26" width="28" height="6" rx="1.5" fill="#FFF9E6" />
                    <circle cx="80" cy="29" r="10" fill="url(#verseFlare)" opacity="0.8" />
                    {/* Open Holy Bible at base */}
                    <path d="M42,68 Q80,56 80,72 Q80,56 118,68 L114,80 Q80,70 80,82 Q80,70 46,80 Z" fill="#D4AF37" />
                    <path d="M44,67 Q80,57 79,71 L79,79 Q80,69 47,78 Z" fill="#FFF4D0" />
                    <path d="M81,71 Q80,57 116,67 L113,78 Q80,69 81,79 Z" fill="#FFF4D0" />
                  </svg>
                </div>
              </div>

              {/* Action Row */}
              <div className="flex items-center justify-between pt-2 border-t border-[#1F2A44]/80">
                <button
                  type="button"
                  onClick={() => onNavigateToBible('psalms', 119)}
                  className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-[#1E3A8A]/50 hover:bg-[#2563EB] border border-[#2563EB]/60 text-xs font-semibold text-[#F7F6F2] active:scale-95 transition-all shadow-sm"
                >
                  <span>Read</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>

                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={onBookmarkDailyVerse}
                    className={`p-2 rounded-xl border transition-all active:scale-90 ${
                      dailyVerseBookmarked
                        ? 'bg-[#D4AF37]/20 border-[#D4AF37] text-[#F5D77A]'
                        : 'bg-[#081220]/60 border-[#1F2A44] text-[#B6C0D1] hover:text-[#F7F6F2]'
                    }`}
                    title="Bookmark Verse"
                    aria-label="Bookmark Daily Verse"
                  >
                    <Bookmark className="w-4 h-4" />
                  </button>

                  <button
                    type="button"
                    onClick={onShareDailyVerse}
                    className="p-2 rounded-xl bg-[#081220]/60 border border-[#1F2A44] text-[#00C6FF] hover:border-[#00C6FF]/60 hover:text-white transition-all active:scale-90"
                    title="Share Verse"
                    aria-label="Share Daily Verse"
                  >
                    <Share2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </>
          )}
        </div>
      </div>

      {/* 3. CONTINUE READING (Display real user reading history) */}
      <div className="space-y-2">
        <h2 className="text-xs font-bold uppercase tracking-wider text-[#B6C0D1] px-1">
          Continue Reading
        </h2>

        <div
          onClick={() => onNavigateToBible(readingProgress.bookId, readingProgress.chapter)}
          className="p-4 rounded-2xl bg-[#0F1A2E] border border-[#1F2A44] hover:border-[#D4AF37]/60 cursor-pointer transition-all active:scale-[0.99] flex items-center justify-between gap-4 group"
        >
          <div className="flex items-center gap-3.5 min-w-0">
            {/* Golden cross icon in rounded square */}
            <div className="w-12 h-12 rounded-xl bg-[#081220] border border-[#D4AF37]/70 flex items-center justify-center text-[#F5D77A] flex-shrink-0 gold-glow-subtle group-hover:scale-105 transition-transform">
              <span className="text-xl font-bold font-serif-sacred text-[#F5D77A]">✝</span>
            </div>

            <div className="min-w-0 flex-1">
              <div className="flex items-center gap-2">
                <h3 className="text-sm font-bold text-[#F7F6F2] capitalize">
                  {readingProgress.bookId} {readingProgress.chapter}
                </h3>
                <span className="text-[10px] px-1.5 py-0.5 rounded bg-[#081220] border border-[#1F2A44] text-[#D4AF37] font-semibold uppercase">
                  {readingProgress.translation || 'None'}
                </span>
              </div>
              <p className="text-xs text-[#7A869A] mt-0.5">
                Chapter {readingProgress.chapter}
              </p>

              {/* Progress bar */}
              <div className="mt-2 w-36 sm:w-48 h-1.5 bg-[#081220] rounded-full overflow-hidden border border-[#1F2A44]/50">
                <div
                  className="h-full bg-gradient-to-r from-[#2563EB] to-[#00C6FF] rounded-full"
                  style={{ width: `${readingProgress.percent}%` }}
                />
              </div>
            </div>
          </div>

          <div className="flex flex-col items-end gap-1 flex-shrink-0">
            <span className="text-xs font-semibold text-[#00C6FF]">
              {readingProgress.percent}%
            </span>
            <ChevronRight className="w-5 h-5 text-[#7A869A] group-hover:text-[#F5D77A] group-hover:translate-x-0.5 transition-all" />
          </div>
        </div>
      </div>

      {/* 4. QUICK ACCESS GRID (Compact rounded cards with approved visual language) */}
      <div className="space-y-2">
        <h2 className="text-xs font-bold uppercase tracking-wider text-[#B6C0D1] px-1">
          Quick Access
        </h2>

        <div className="grid grid-cols-3 gap-2.5">
          {/* Bible */}
          <button
            type="button"
            onClick={() => onNavigateToBible()}
            className="p-3 rounded-2xl bg-[#0F1A2E] border border-[#1F2A44] hover:border-[#2563EB]/60 flex flex-col items-center justify-center text-center transition-all active:scale-95 group"
          >
            <div className="w-11 h-11 rounded-xl bg-[#081220] border border-[#2563EB]/40 flex items-center justify-center text-[#00C6FF] group-hover:cyan-glow transition-all">
              <BookOpen className="w-5 h-5 stroke-[2.2]" />
            </div>
            <span className="text-xs font-semibold text-[#F7F6F2] mt-2">
              Bible
            </span>
          </button>

          {/* Search */}
          <button
            type="button"
            onClick={onNavigateToSearch}
            className="p-3 rounded-2xl bg-[#0F1A2E] border border-[#1F2A44] hover:border-[#00C6FF]/60 flex flex-col items-center justify-center text-center transition-all active:scale-95 group"
          >
            <div className="w-11 h-11 rounded-xl bg-[#081220] border border-[#00C6FF]/40 flex items-center justify-center text-[#00C6FF] group-hover:cyan-glow transition-all">
              <Search className="w-5 h-5 stroke-[2.2]" />
            </div>
            <span className="text-xs font-semibold text-[#F7F6F2] mt-2">
              Search
            </span>
          </button>

          {/* Prayer */}
          <button
            type="button"
            onClick={onNavigateToPrayer}
            className="p-3 rounded-2xl bg-[#0F1A2E] border border-[#1F2A44] hover:border-[#D4AF37]/60 flex flex-col items-center justify-center text-center transition-all active:scale-95 group"
          >
            <div className="w-11 h-11 rounded-xl bg-[#081220] border border-[#D4AF37]/40 flex items-center justify-center text-[#F5D77A] group-hover:gold-glow transition-all">
              <span className="text-xl">🙏</span>
            </div>
            <span className="text-xs font-semibold text-[#F7F6F2] mt-2">
              Prayer
            </span>
          </button>

          {/* Worship (Geet & Zaboor) */}
          <button
            type="button"
            onClick={() => onNavigateToWorship()}
            className="p-3 rounded-2xl bg-[#0F1A2E] border border-[#1F2A44] hover:border-[#D4AF37]/60 flex flex-col items-center justify-center text-center transition-all active:scale-95 group"
          >
            <div className="w-11 h-11 rounded-xl bg-[#081220] border border-[#D4AF37]/40 flex items-center justify-center text-[#F5D77A] group-hover:gold-glow transition-all">
              <Music className="w-5 h-5 stroke-[2.2]" />
            </div>
            <span className="text-xs font-semibold text-[#F7F6F2] mt-1.5 leading-tight">
              Worship
            </span>
            <span className="text-[9.5px] text-[#7A869A] leading-none mt-0.5">
              Geet & Zaboor
            </span>
          </button>

          {/* AI Bible Assistant */}
          <button
            type="button"
            onClick={() => onNavigateToAI()}
            className="p-3 rounded-2xl bg-[#0F1A2E] border border-[#1F2A44] hover:border-[#00C6FF]/60 flex flex-col items-center justify-center text-center transition-all active:scale-95 group"
          >
            <div className="w-11 h-11 rounded-xl bg-[#081220] border border-[#00C6FF]/40 flex items-center justify-center text-[#00C6FF] group-hover:cyan-glow transition-all">
              <Bot className="w-5 h-5 stroke-[2.2]" />
            </div>
            <span className="text-xs font-semibold text-[#F7F6F2] mt-1.5 leading-tight">
              AI Bible
            </span>
            <span className="text-[9.5px] text-[#7A869A] leading-none mt-0.5">
              Assistant
            </span>
          </button>

          {/* Offline Bible */}
          <button
            type="button"
            onClick={onOpenTranslations}
            className="p-3 rounded-2xl bg-[#0F1A2E] border border-[#1F2A44] hover:border-[#00C6FF]/60 flex flex-col items-center justify-center text-center transition-all active:scale-95 group"
          >
            <div className="w-11 h-11 rounded-xl bg-[#081220] border border-[#2563EB]/40 flex items-center justify-center text-[#00C6FF] group-hover:cyan-glow transition-all">
              <CloudDownload className="w-5 h-5 stroke-[2.2]" />
            </div>
            <span className="text-xs font-semibold text-[#F7F6F2] mt-1.5 leading-tight">
              Offline
            </span>
            <span className="text-[9.5px] text-[#7A869A] leading-none mt-0.5">
              Bible
            </span>
          </button>
        </div>
      </div>

      {/* 5. RECENT READING */}
      <div className="space-y-2">
        <h2 className="text-xs font-bold uppercase tracking-wider text-[#B6C0D1] px-1">
          Recent Reading
        </h2>

        <div
          onClick={() => onNavigateToBible('genesis', 1)}
          className="p-3.5 rounded-xl bg-[#0F1A2E] border border-[#1F2A44] hover:border-[#2563EB]/60 cursor-pointer flex items-center justify-between group transition-all"
        >
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-[#081220] border border-[#1F2A44] flex items-center justify-center text-[#00C6FF]">
              <BookOpen className="w-4 h-4" />
            </div>
            <div>
              <span className="text-sm font-semibold text-[#F7F6F2]">
                Genesis 1
              </span>
              <span className="text-xs text-[#7A869A] ml-2 font-serif">
                Creation of Heavens & Earth
              </span>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <span className="text-xs text-[#D4AF37] font-semibold">KJV</span>
            <ChevronRight className="w-4 h-4 text-[#7A869A] group-hover:text-[#F7F6F2] transition-colors" />
          </div>
        </div>
      </div>

      {/* 6. QUICK ACTIONS (Rounded circular buttons as in reference) */}
      <div className="space-y-2">
        <h2 className="text-xs font-bold uppercase tracking-wider text-[#B6C0D1] px-1">
          Quick Actions
        </h2>

        <div className="grid grid-cols-4 gap-2">
          {/* Bookmark */}
          <button
            type="button"
            onClick={() => onNavigateToSaved('bookmarks')}
            className="p-3 rounded-2xl bg-[#0F1A2E] border border-[#1F2A44] hover:border-[#D4AF37]/60 flex flex-col items-center justify-center transition-all active:scale-95 group"
          >
            <div className="w-10 h-10 rounded-full border border-[#D4AF37]/50 bg-[#081220] flex items-center justify-center text-[#F5D77A] group-hover:gold-glow transition-all">
              <Bookmark className="w-4 h-4" />
            </div>
            <span className="text-[11px] font-medium text-[#F7F6F2] mt-1.5">
              Bookmark
            </span>
          </button>

          {/* Highlight */}
          <button
            type="button"
            onClick={() => onNavigateToSaved('highlights')}
            className="p-3 rounded-2xl bg-[#0F1A2E] border border-[#1F2A44] hover:border-[#D4AF37]/60 flex flex-col items-center justify-center transition-all active:scale-95 group"
          >
            <div className="w-10 h-10 rounded-full border border-[#D4AF37]/50 bg-[#081220] flex items-center justify-center text-[#F5D77A] group-hover:gold-glow transition-all">
              <Highlighter className="w-4 h-4" />
            </div>
            <span className="text-[11px] font-medium text-[#F7F6F2] mt-1.5">
              Highlight
            </span>
          </button>

          {/* Note */}
          <button
            type="button"
            onClick={() => onNavigateToSaved('notes')}
            className="p-3 rounded-2xl bg-[#0F1A2E] border border-[#1F2A44] hover:border-[#D4AF37]/60 flex flex-col items-center justify-center transition-all active:scale-95 group"
          >
            <div className="w-10 h-10 rounded-full border border-[#D4AF37]/50 bg-[#081220] flex items-center justify-center text-[#F5D77A] group-hover:gold-glow transition-all">
              <FileText className="w-4 h-4" />
            </div>
            <span className="text-[11px] font-medium text-[#F7F6F2] mt-1.5">
              Note
            </span>
          </button>

          {/* Share */}
          <button
            type="button"
            onClick={onShareDailyVerse}
            className="p-3 rounded-2xl bg-[#0F1A2E] border border-[#1F2A44] hover:border-[#00C6FF]/60 flex flex-col items-center justify-center transition-all active:scale-95 group"
          >
            <div className="w-10 h-10 rounded-full border border-[#00C6FF]/50 bg-[#081220] flex items-center justify-center text-[#00C6FF] group-hover:cyan-glow transition-all">
              <Share2 className="w-4 h-4" />
            </div>
            <span className="text-[11px] font-medium text-[#F7F6F2] mt-1.5">
              Share
            </span>
          </button>
        </div>
      </div>

      {/* 7. AI BIBLE ASSISTANT CARD (As in Reference) */}
      <div className="p-4 rounded-2xl bg-[#0F1A2E] border border-[#1F2A44] flex items-center justify-between gap-4 shadow-lg">
        <div className="min-w-0">
          <div className="flex items-center gap-2">
            <h3 className="text-sm font-bold text-[#00C6FF]">
              AI Bible Assistant
            </h3>
            <span className="text-[9.5px] px-1.5 py-0.5 rounded bg-[#1E3A8A]/50 text-[#00C6FF] border border-[#2563EB]/40 font-semibold">
              Gemini 3.8
            </span>
          </div>
          <p className="text-xs text-[#B6C0D1] mt-1 leading-snug">
            Ask anything about the Bible in English or Roman Urdu...
          </p>

          <button
            type="button"
            onClick={() => onNavigateToAI()}
            className="mt-3 px-4 py-2 rounded-xl bg-gradient-to-r from-[#00C6FF] to-[#2563EB] text-[#081220] font-bold text-xs flex items-center gap-1.5 shadow-[0_0_12px_rgba(0,198,255,0.4)] active:scale-95 transition-all"
          >
            <span>+ Ask Now</span>
          </button>
        </div>

        {/* Robot head graphic with cyan glow */}
        <div className="relative w-16 h-16 flex-shrink-0 flex items-center justify-center rounded-2xl bg-[#081220] border border-[#00C6FF]/40 cyan-glow">
          <svg viewBox="0 0 100 100" className="w-12 h-12">
            {/* Robot Head */}
            <rect x="20" y="25" width="60" height="50" rx="14" fill="#0F1A2E" stroke="#00C6FF" strokeWidth="2.5" />
            {/* Antenna */}
            <line x1="50" y1="25" x2="50" y2="12" stroke="#00C6FF" strokeWidth="2" />
            <circle cx="50" cy="11" r="4" fill="#00C6FF" />
            {/* Eyes */}
            <circle cx="38" cy="45" r="7" fill="#00C6FF" />
            <circle cx="62" cy="45" r="7" fill="#00C6FF" />
            <circle cx="40" cy="43" r="2.5" fill="#FFFFFF" />
            <circle cx="64" cy="43" r="2.5" fill="#FFFFFF" />
            {/* Smile */}
            <path d="M40 60 Q50 67 60 60" stroke="#00C6FF" strokeWidth="2.5" strokeLinecap="round" fill="none" />
            {/* Ears */}
            <rect x="14" y="42" width="6" height="16" rx="2" fill="#2563EB" />
            <rect x="80" y="42" width="6" height="16" rx="2" fill="#2563EB" />
          </svg>
        </div>
      </div>

      {/* 8. PRAYER REMINDER CARD (As in Reference) */}
      <div className="p-4 rounded-2xl bg-[#0F1A2E] border border-[#1F2A44] flex items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="w-11 h-11 rounded-xl bg-[#081220] border border-[#D4AF37]/50 flex items-center justify-center text-xl flex-shrink-0 gold-glow-subtle">
            🙏
          </div>
          <div>
            <h3 className="text-xs font-bold uppercase tracking-wider text-[#B6C0D1]">
              Prayer Reminder
            </h3>
            <div className="flex items-center gap-1.5 mt-0.5">
              <span className="text-sm font-bold text-[#F7F6F2]">Daily Prayer</span>
              <span className="text-xs text-[#D4AF37] font-semibold">• 7:00 AM</span>
            </div>
          </div>
        </div>

        {/* Toggle Switch */}
        <button
          type="button"
          onClick={onTogglePrayerReminder}
          className={`relative inline-flex h-7 w-12 items-center rounded-full transition-colors focus:outline-none ${
            prayerReminderEnabled ? 'bg-[#00C6FF]' : 'bg-[#1F2A44]'
          }`}
          aria-label="Toggle daily prayer reminder"
        >
          <span
            className={`inline-block h-5 w-5 transform rounded-full bg-white transition-transform ${
              prayerReminderEnabled ? 'translate-x-6' : 'translate-x-1'
            }`}
          />
        </button>
      </div>

      {/* 9. BOTTOM SHOWCASE BANNER (Matching bottom banner in poster) */}
      <div className="p-4 rounded-2xl bg-gradient-to-r from-[#0F1A2E] via-[#081220] to-[#0F1A2E] border border-[#1F2A44] grid grid-cols-2 gap-3 text-left">
        {/* Offline Bible */}
        <div
          onClick={onOpenTranslations}
          className="p-2.5 rounded-xl bg-[#081220]/60 border border-[#1F2A44] flex items-start gap-2.5 cursor-pointer hover:border-[#00C6FF]/40 transition-colors"
        >
          <CloudDownload className="w-5 h-5 text-[#00C6FF] flex-shrink-0 mt-0.5" />
          <div>
            <div className="text-[11px] font-bold text-[#F7F6F2] uppercase tracking-wide">
              Offline Bible
            </div>
            <div className="text-[10px] text-[#7A869A] mt-0.5">
              Read anytime, anywhere.
            </div>
          </div>
        </div>

        {/* Saved Scripture */}
        <div
          onClick={() => onNavigateToSaved()}
          className="p-2.5 rounded-xl bg-[#081220]/60 border border-[#1F2A44] flex items-start gap-2.5 cursor-pointer hover:border-[#D4AF37]/40 transition-colors"
        >
          <Bookmark className="w-5 h-5 text-[#F5D77A] flex-shrink-0 mt-0.5" />
          <div>
            <div className="text-[11px] font-bold text-[#F7F6F2] uppercase tracking-wide">
              Saved Scripture
            </div>
            <div className="text-[10px] text-[#7A869A] mt-0.5">
              Bookmarks, Highlights & Notes
            </div>
          </div>
        </div>

        {/* Prayer Reminder */}
        <div
          onClick={onNavigateToPrayer}
          className="p-2.5 rounded-xl bg-[#081220]/60 border border-[#1F2A44] flex items-start gap-2.5 cursor-pointer hover:border-[#00C6FF]/40 transition-colors"
        >
          <Bell className="w-5 h-5 text-[#00C6FF] flex-shrink-0 mt-0.5" />
          <div>
            <div className="text-[11px] font-bold text-[#F7F6F2] uppercase tracking-wide">
              Prayer Reminder
            </div>
            <div className="text-[10px] text-[#7A869A] mt-0.5">
              Never miss your prayer time
            </div>
          </div>
        </div>

        {/* Worship & Zaboor */}
        <div
          onClick={() => onNavigateToWorship()}
          className="p-2.5 rounded-xl bg-[#081220]/60 border border-[#1F2A44] flex items-start gap-2.5 cursor-pointer hover:border-[#D4AF37]/40 transition-colors"
        >
          <Music className="w-5 h-5 text-[#F5D77A] flex-shrink-0 mt-0.5" />
          <div>
            <div className="text-[11px] font-bold text-[#F7F6F2] uppercase tracking-wide">
              Worship & Zaboor
            </div>
            <div className="text-[10px] text-[#7A869A] mt-0.5">
              Geet, Hymns & Zaboor
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
