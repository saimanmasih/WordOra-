import React, { useState } from 'react';
import { Play, Pause, Music, Heart, Share2, Sparkles, Filter, Volume2 } from 'lucide-react';
import { WORSHIP_TRACKS } from '../data/worshipData';
import { WorshipTrack } from '../types';

interface WorshipScreenProps {
  currentTrack: WorshipTrack | null;
  isPlaying: boolean;
  onPlayTrack: (track: WorshipTrack) => void;
  onTogglePlay: () => void;
}

export const WorshipScreen: React.FC<WorshipScreenProps> = ({
  currentTrack,
  isPlaying,
  onPlayTrack,
  onTogglePlay,
}) => {
  const [selectedCategory, setSelectedCategory] = useState<'all' | 'geet_zaboor' | 'praise' | 'peace' | 'morning' | 'night'>('all');
  const [selectedLyricsTrack, setSelectedLyricsTrack] = useState<WorshipTrack | null>(WORSHIP_TRACKS[0]);

  const categories = [
    { id: 'all', label: 'All Songs' },
    { id: 'geet_zaboor', label: 'Geet & Zaboor' },
    { id: 'praise', label: 'Praise' },
    { id: 'peace', label: 'Peace' },
    { id: 'morning', label: 'Morning' },
    { id: 'night', label: 'Night' },
  ];

  const filteredTracks = selectedCategory === 'all'
    ? WORSHIP_TRACKS
    : WORSHIP_TRACKS.filter(t => t.category === selectedCategory);

  return (
    <div className="flex-1 overflow-y-auto px-4 py-3 space-y-4 pb-32">
      {/* Title */}
      <div className="pt-1">
        <h1 className="text-xl font-bold text-[#F7F6F2] font-serif-sacred tracking-wide">
          Worship & Zaboor
        </h1>
        <p className="text-xs text-[#7A869A] mt-0.5">
          Sacred Punjabi & Urdu Zaboor, Christian Geet, and prayer melodies.
        </p>
      </div>

      {/* Featured Header Card */}
      <div className="p-4 rounded-2xl bg-gradient-to-br from-[#0F1A2E] via-[#1E3A8A]/30 to-[#081220] border border-[#1F2A44] flex items-center justify-between gap-4 shadow-xl relative overflow-hidden">
        <div className="absolute right-0 top-0 w-32 h-32 bg-[#D4AF37]/10 rounded-full blur-2xl pointer-events-none" />

        <div className="min-w-0 z-10">
          <span className="text-[10px] font-bold uppercase tracking-wider text-[#F5D77A] flex items-center gap-1">
            <Sparkles className="w-3 h-3 text-[#F5D77A]" />
            <span>Featured Zaboor</span>
          </span>
          <h3 className="text-sm font-bold text-[#F7F6F2] mt-1 truncate">
            {WORSHIP_TRACKS[0].title}
          </h3>
          <p className="text-xs text-[#00C6FF] font-medium">
            {WORSHIP_TRACKS[0].subtitle}
          </p>

          <button
            type="button"
            onClick={() => onPlayTrack(WORSHIP_TRACKS[0])}
            className="mt-3 px-4 py-2 rounded-xl bg-gradient-to-r from-[#D4AF37] to-[#F5D77A] text-[#081220] font-bold text-xs uppercase tracking-wider flex items-center gap-2 shadow-md active:scale-95 transition-all"
          >
            {currentTrack?.id === WORSHIP_TRACKS[0].id && isPlaying ? (
              <>
                <Pause className="w-3.5 h-3.5 fill-current" />
                <span>Pause</span>
              </>
            ) : (
              <>
                <Play className="w-3.5 h-3.5 fill-current" />
                <span>Listen Now</span>
              </>
            )}
          </button>
        </div>

        <div className="w-16 h-16 rounded-2xl bg-[#081220] border border-[#D4AF37]/50 flex items-center justify-center text-[#F5D77A] flex-shrink-0 gold-glow shadow-inner">
          <Music className="w-7 h-7" />
        </div>
      </div>

      {/* Category Pills */}
      <div className="flex items-center gap-2 overflow-x-auto pb-1 no-scrollbar">
        {categories.map((cat) => (
          <button
            key={cat.id}
            type="button"
            onClick={() => setSelectedCategory(cat.id as any)}
            className={`px-3.5 py-1.5 rounded-full text-xs font-medium whitespace-nowrap transition-all ${
              selectedCategory === cat.id
                ? 'bg-[#00C6FF] text-[#081220] font-bold shadow-[0_0_10px_rgba(0,198,255,0.4)]'
                : 'bg-[#0F1A2E] border border-[#1F2A44] text-[#B6C0D1] hover:text-[#F7F6F2]'
            }`}
          >
            {cat.label}
          </button>
        ))}
      </div>

      {/* Track List */}
      <div className="space-y-2">
        <h2 className="text-xs font-bold uppercase tracking-wider text-[#B6C0D1] px-1">
          Songs ({filteredTracks.length})
        </h2>

        <div className="rounded-2xl border border-[#1F2A44] bg-[#0F1A2E] divide-y divide-[#1F2A44] overflow-hidden shadow-lg">
          {filteredTracks.map((track) => {
            const isThisPlaying = currentTrack?.id === track.id && isPlaying;
            const isThisSelected = currentTrack?.id === track.id;

            return (
              <div
                key={track.id}
                onClick={() => {
                  setSelectedLyricsTrack(track);
                  onPlayTrack(track);
                }}
                className={`p-3.5 flex items-center justify-between cursor-pointer transition-colors ${
                  isThisSelected
                    ? 'bg-[#111A2E]'
                    : 'hover:bg-[#111A2E]/60'
                }`}
              >
                <div className="flex items-center gap-3 min-w-0">
                  <div
                    className={`w-10 h-10 rounded-xl border flex items-center justify-center flex-shrink-0 transition-all ${
                      isThisSelected
                        ? 'border-[#00C6FF] bg-[#00C6FF]/10 text-[#00C6FF]'
                        : 'border-[#1F2A44] bg-[#081220] text-[#B6C0D1]'
                    }`}
                  >
                    {isThisPlaying ? (
                      <Pause className="w-4 h-4 fill-current" />
                    ) : (
                      <Play className="w-4 h-4 fill-current ml-0.5" />
                    )}
                  </div>

                  <div className="min-w-0">
                    <h4
                      className={`text-xs font-bold truncate ${
                        isThisSelected ? 'text-[#00C6FF]' : 'text-[#F7F6F2]'
                      }`}
                    >
                      {track.title}
                    </h4>
                    <p className="text-[11px] text-[#7A869A] truncate mt-0.5">
                      {track.subtitle}
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-3 flex-shrink-0">
                  <span className="text-[11px] text-[#7A869A]">
                    {track.duration}
                  </span>
                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      setSelectedLyricsTrack(track);
                    }}
                    className="p-1.5 rounded-lg text-[#7A869A] hover:text-[#F5D77A]"
                    title="View Lyrics"
                  >
                    <Sparkles className="w-4 h-4" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Selected Lyrics Viewer Card */}
      {selectedLyricsTrack && (
        <div className="p-4 rounded-2xl bg-[#0F1A2E] border border-[#1F2A44] space-y-2.5">
          <div className="flex items-center justify-between border-b border-[#1F2A44] pb-2">
            <div>
              <h3 className="text-xs font-bold uppercase tracking-wider text-[#F5D77A]">
                Lyrics & Reflection
              </h3>
              <p className="text-xs font-semibold text-[#F7F6F2]">
                {selectedLyricsTrack.title}
              </p>
            </div>

            <button
              type="button"
              onClick={() => onPlayTrack(selectedLyricsTrack)}
              className="px-3 py-1.5 rounded-xl bg-[#081220] border border-[#00C6FF]/50 text-xs font-semibold text-[#00C6FF] flex items-center gap-1.5"
            >
              <Volume2 className="w-3.5 h-3.5" />
              <span>Play</span>
            </button>
          </div>

          <div className="p-3 rounded-xl bg-[#081220] border border-[#1F2A44]/60 text-xs leading-relaxed text-[#B6C0D1] whitespace-pre-line font-serif italic text-center">
            {selectedLyricsTrack.lyrics}
          </div>
        </div>
      )}
    </div>
  );
};
