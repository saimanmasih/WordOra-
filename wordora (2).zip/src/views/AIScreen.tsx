import React, { useState, useRef, useEffect } from 'react';
import { Send, Bot, User, Sparkles, BookOpen, AlertCircle, RefreshCw } from 'lucide-react';
import { AIMessage, TranslationId } from '../types';

interface AIScreenProps {
  initialQuery?: string;
  selectedTranslation: TranslationId;
  onNavigateToVerse: (bookId: string, chapter: number, verse: number) => void;
}

export const AIScreen: React.FC<AIScreenProps> = ({
  initialQuery = '',
  selectedTranslation,
  onNavigateToVerse,
}) => {
  const [messages, setMessages] = useState<AIMessage[]>([
    {
      id: 'welcome',
      role: 'assistant',
      content: `Salam and Blessings! I am the **WordOra AI Bible Assistant**.\n\nI can help you study Scripture, explore biblical historical context, explain verses in **English, Roman Urdu, or Urdu**, and understand God's Word more deeply.\n\nAsk me any question or tap one of the suggested study prompts below.`,
      createdAt: new Date().toISOString(),
    },
  ]);

  const [inputQuery, setInputQuery] = useState(initialQuery);
  const [isLoading, setIsLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const chatEndRef = useRef<HTMLDivElement>(null);

  const suggestedQuestions = [
    'What does John 3:16 mean in depth?',
    'Roman Urdu mein Zaboor 23 ki roohani tafseer samjhayein',
    'What is the meaning of the Beatitudes in Matthew 5?',
    'Khuda ki mohabbat aur nijaat ka rasta kya hai?',
  ];

  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isLoading]);

  const handleSendMessage = async (textToSend?: string) => {
    const query = textToSend || inputQuery;
    if (!query.trim() || isLoading) return;

    const userMessage: AIMessage = {
      id: `usr-${Date.now()}`,
      role: 'user',
      content: query.trim(),
      createdAt: new Date().toISOString(),
    };

    setMessages((prev) => [...prev, userMessage]);
    setInputQuery('');
    setIsLoading(true);
    setErrorMsg(null);

    try {
      const res = await fetch('/api/ai/ask', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          question: query.trim(),
          translation: selectedTranslation,
        }),
      });

      const data = await res.json();

      if (!res.ok) {
        throw new Error(data.error || 'Failed to get answer from AI Assistant');
      }

      const assistantMessage: AIMessage = {
        id: `ast-${Date.now()}`,
        role: 'assistant',
        content: data.answer || 'No response generated.',
        createdAt: new Date().toISOString(),
      };

      setMessages((prev) => [...prev, assistantMessage]);
    } catch (err: any) {
      console.error('AI Ask Error:', err);
      setErrorMsg(err.message || 'Connection error. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="flex-1 flex flex-col h-full overflow-hidden bg-[#081220] pb-20">
      {/* Top Header */}
      <div className="px-4 py-3 border-b border-[#1F2A44] bg-[#0F1A2E]/90 backdrop-blur-md flex items-center justify-between">
        <div className="flex items-center gap-2.5">
          <div className="w-10 h-10 rounded-xl bg-[#081220] border border-[#00C6FF]/50 flex items-center justify-center text-[#00C6FF] cyan-glow-subtle">
            <Bot className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <h1 className="text-sm font-bold text-[#F7F6F2]">
                WordOra AI Bible Assistant
              </h1>
              <span className="text-[10px] px-1.5 py-0.2 rounded bg-[#1E3A8A]/60 border border-[#2563EB]/40 text-[#00C6FF]">
                Gemini
              </span>
            </div>
            <p className="text-[11px] text-[#7A869A]">
              Faithful, Scripture-anchored study in English & Roman Urdu
            </p>
          </div>
        </div>
      </div>

      {/* Messages Scroll Area */}
      <div className="flex-1 overflow-y-auto px-4 py-4 space-y-4">
        {messages.map((msg) => {
          const isUser = msg.role === 'user';
          return (
            <div
              key={msg.id}
              className={`flex gap-2.5 ${isUser ? 'justify-end' : 'justify-start'}`}
            >
              {!isUser && (
                <div className="w-8 h-8 rounded-lg bg-[#0F1A2E] border border-[#00C6FF]/40 flex items-center justify-center text-[#00C6FF] flex-shrink-0 mt-0.5">
                  <Bot className="w-4 h-4" />
                </div>
              )}

              <div
                className={`max-w-[85%] rounded-2xl px-4 py-3 text-xs leading-relaxed ${
                  isUser
                    ? 'bg-gradient-to-r from-[#1E3A8A] to-[#2563EB] text-[#F7F6F2] rounded-tr-sm shadow-md'
                    : 'bg-[#0F1A2E] border border-[#1F2A44] text-[#F7F6F2] rounded-tl-sm shadow-lg whitespace-pre-line'
                }`}
              >
                {msg.content}
              </div>

              {isUser && (
                <div className="w-8 h-8 rounded-lg bg-[#0F1A2E] border border-[#D4AF37]/50 flex items-center justify-center text-[#F5D77A] flex-shrink-0 mt-0.5">
                  <User className="w-4 h-4" />
                </div>
              )}
            </div>
          );
        })}

        {isLoading && (
          <div className="flex gap-2.5 items-center text-xs text-[#00C6FF] animate-pulse">
            <div className="w-8 h-8 rounded-lg bg-[#0F1A2E] border border-[#00C6FF]/40 flex items-center justify-center">
              <Bot className="w-4 h-4" />
            </div>
            <span className="p-3 rounded-2xl bg-[#0F1A2E] border border-[#1F2A44] text-xs">
              Reflecting on Scripture...
            </span>
          </div>
        )}

        {errorMsg && (
          <div className="p-3 rounded-xl bg-red-950/40 border border-red-800/60 text-xs text-red-200 flex items-center gap-2">
            <AlertCircle className="w-4 h-4 flex-shrink-0" />
            <span>{errorMsg}</span>
          </div>
        )}

        <div ref={chatEndRef} />
      </div>

      {/* Suggested Prompts (when only welcome message exists) */}
      {messages.length <= 2 && (
        <div className="px-4 py-2 space-y-1.5">
          <span className="text-[10px] font-bold uppercase tracking-wider text-[#7A869A] flex items-center gap-1">
            <Sparkles className="w-3 h-3 text-[#F5D77A]" />
            <span>Suggested Questions:</span>
          </span>
          <div className="flex flex-wrap gap-1.5">
            {suggestedQuestions.map((q, idx) => (
              <button
                key={idx}
                type="button"
                onClick={() => handleSendMessage(q)}
                className="text-[11px] px-3 py-1.5 rounded-xl bg-[#0F1A2E] border border-[#1F2A44] hover:border-[#00C6FF]/60 text-[#B6C0D1] hover:text-[#F7F6F2] active:scale-95 transition-all text-left"
              >
                {q}
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Input Bar */}
      <div className="p-3 border-t border-[#1F2A44] bg-[#0F1A2E]">
        <form
          onSubmit={(e) => {
            e.preventDefault();
            handleSendMessage();
          }}
          className="flex items-center gap-2"
        >
          <input
            type="text"
            value={inputQuery}
            onChange={(e) => setInputQuery(e.target.value)}
            placeholder="Ask anything about Scripture (English or Roman Urdu)..."
            className="flex-1 bg-[#081220] border border-[#1F2A44] focus:border-[#00C6FF] rounded-xl px-3.5 py-2.5 text-xs text-[#F7F6F2] placeholder-[#7A869A] focus:outline-none transition-colors"
          />

          <button
            type="submit"
            disabled={!inputQuery.trim() || isLoading}
            className={`w-10 h-10 rounded-xl flex items-center justify-center font-bold transition-all shadow-md ${
              inputQuery.trim() && !isLoading
                ? 'bg-gradient-to-r from-[#00C6FF] to-[#2563EB] text-[#081220] active:scale-95'
                : 'bg-[#1F2A44] text-[#7A869A] cursor-not-allowed'
            }`}
            aria-label="Send query"
          >
            <Send className="w-4 h-4" />
          </button>
        </form>
      </div>
    </div>
  );
};
