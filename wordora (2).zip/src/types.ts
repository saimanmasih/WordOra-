export type TranslationId = string;

export interface BibleTranslation {
  id: TranslationId;
  code: string;
  name: string;
  fullName: string;
  language: string;
  isDownloaded: boolean;
  isRTL?: boolean;
  description: string;
}

export interface BibleBook {
  id: string;
  name: string;
  testament: 'OT' | 'NT';
  chaptersCount: number;
  abbreviation: string;
  romanUrduName?: string;
  urduName?: string;
  category: string;
}

export interface BibleVerse {
  bookId: string;
  chapter: number;
  verse: number;
  text: string;
  translation?: TranslationId;
  sectionHeading?: string;
}

export interface VerseContent {
  verse: number;
  text: string;
  sectionHeading?: string;
}

export interface HighlightItem {
  id: string;
  bookId: string;
  chapter: number;
  verse: number;
  text: string;
  color: 'gold' | 'cyan' | 'emerald' | 'rose';
  translation: TranslationId;
  createdAt: string;
}

export interface BookmarkItem {
  id: string;
  bookId: string;
  chapter: number;
  verse: number;
  text: string;
  translation: TranslationId;
  createdAt: string;
}

export interface NoteItem {
  id: string;
  bookId: string;
  chapter: number;
  verse: number;
  verseText: string;
  noteText: string;
  translation: TranslationId;
  createdAt: string;
}

export interface ReadingProgress {
  bookId: string;
  chapter: number;
  percent: number;
  translation: TranslationId;
  updatedAt: string;
}

export interface PrayerItem {
  id: string;
  title: string;
  content: string;
  category: 'personal' | 'family' | 'community' | 'healing' | 'answered';
  isAnswered: boolean;
  prayerCount: number;
  createdAt: string;
  answeredAt?: string;
  testimony?: string;
}

export interface WorshipTrack {
  id: string;
  title: string;
  subtitle: string;
  category: 'geet_zaboor' | 'morning' | 'night' | 'peace' | 'praise';
  duration: string;
  lyrics: string;
  audioKey?: string;
}

export interface AIMessage {
  id: string;
  sender?: 'user' | 'assistant';
  role?: 'user' | 'assistant';
  text?: string;
  content?: string;
  timestamp?: string;
  createdAt?: string;
  references?: string[];
}
