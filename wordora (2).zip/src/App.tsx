import React, { useState, useEffect } from 'react';
import { Header } from './components/Header';
import { BottomNavigation, NavTab } from './components/BottomNavigation';
import { NavigationDrawer } from './components/NavigationDrawer';
import { TranslationsModal } from './components/TranslationsModal';
import { AboutModal } from './components/AboutModal';
import { ProfileModal } from './components/ProfileModal';
import { FullBibleImportModal } from './components/FullBibleImportModal';
import { AudioPlayerBar } from './components/AudioPlayerBar';
import { getAuthoritativeChapterVerses } from './services/authoritativeBibleService';

import { HomeScreen } from './views/HomeScreen';
import { BibleScreen } from './views/BibleScreen';
import { ReaderScreen } from './views/ReaderScreen';
import { WorshipScreen } from './views/WorshipScreen';
import { SearchScreen } from './views/SearchScreen';
import { SavedScreen } from './views/SavedScreen';
import { AIScreen } from './views/AIScreen';

import {
  TranslationId,
  ReadingProgress,
  BookmarkItem,
  HighlightItem,
  NoteItem,
  PrayerItem,
  WorshipTrack,
  BibleVerse,
} from './types';
import {
  getStoredProgress,
  saveStoredProgress,
  getStoredBookmarks,
  saveStoredBookmarks,
  getStoredHighlights,
  saveStoredHighlights,
  getStoredNotes,
  saveStoredNotes,
  getStoredPrayers,
  saveStoredPrayers,
  getStoredPrayerReminder,
  saveStoredPrayerReminder,
  getStoredReaderConfig,
  saveStoredReaderConfig,
  ReaderConfig,
} from './utils/storage';
import { sacredAudio } from './utils/audioSynthesizer';

export function App() {
  // Navigation
  const [currentTab, setCurrentTab] = useState<NavTab>('home');
  const [activeReader, setActiveReader] = useState<{ bookId: string; chapter: number; initialVerse?: number } | null>(null);
  const [bibleSelectedBookId, setBibleSelectedBookId] = useState<string | null>(null);

  // Translation (Reset state: 0 installed Bible datasets)
  const [selectedTranslation, setSelectedTranslation] = useState<TranslationId>('ur');

  // Persistence State
  const [readingProgress, setReadingProgress] = useState<ReadingProgress>(getStoredProgress());
  const [bookmarks, setBookmarks] = useState<BookmarkItem[]>(getStoredBookmarks());
  const [highlights, setHighlights] = useState<HighlightItem[]>(getStoredHighlights());
  const [notes, setNotes] = useState<NoteItem[]>(getStoredNotes());
  const [prayers, setPrayers] = useState<PrayerItem[]>(getStoredPrayers());
  const [prayerReminder, setPrayerReminder] = useState(getStoredPrayerReminder());
  const [readerConfig, setReaderConfig] = useState<ReaderConfig>(getStoredReaderConfig());

  // Audio Playback
  const [currentTrack, setCurrentTrack] = useState<WorshipTrack | null>(null);
  const [isPlayingAudio, setIsPlayingAudio] = useState(false);

  // Modals & Drawers
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isTranslationsOpen, setIsTranslationsOpen] = useState(false);
  const [isAboutOpen, setIsAboutOpen] = useState(false);
  const [isProfileOpen, setIsProfileOpen] = useState(false);
  const [isFullImportOpen, setIsFullImportOpen] = useState(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const [savedInitialTab, setSavedInitialTab] = useState<'bookmarks' | 'highlights' | 'notes'>('bookmarks');
  const [aiInitialQuery, setAiInitialQuery] = useState<string>('');

  // Daily verse bookmark state
  const isDailyVerseBookmarked = bookmarks.some(
    (b) => b.bookId === 'psalms' && b.chapter === 119 && b.verse === 105
  );

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage(null);
    }, 2800);
  };

  // Keep storage in sync
  useEffect(() => {
    saveStoredProgress(readingProgress);
  }, [readingProgress]);

  useEffect(() => {
    saveStoredBookmarks(bookmarks);
  }, [bookmarks]);

  useEffect(() => {
    saveStoredHighlights(highlights);
  }, [highlights]);

  useEffect(() => {
    saveStoredNotes(notes);
  }, [notes]);

  useEffect(() => {
    saveStoredPrayers(prayers);
  }, [prayers]);

  useEffect(() => {
    saveStoredPrayerReminder(prayerReminder);
  }, [prayerReminder]);

  useEffect(() => {
    saveStoredReaderConfig(readerConfig);
  }, [readerConfig]);

  // Handle Sacred Audio Playback
  const handlePlayTrack = (track: WorshipTrack) => {
    if (currentTrack?.id === track.id && isPlayingAudio) {
      sacredAudio.stop();
      setIsPlayingAudio(false);
    } else {
      setCurrentTrack(track);
      sacredAudio.playSacredMeditation();
      setIsPlayingAudio(true);
      showToast(`Playing ${track.title}`);
    }
  };

  const handleTogglePlayAudio = () => {
    if (isPlayingAudio) {
      sacredAudio.stop();
      setIsPlayingAudio(false);
    } else if (currentTrack) {
      sacredAudio.playSacredMeditation();
      setIsPlayingAudio(true);
    }
  };

  const handleCloseAudio = () => {
    sacredAudio.stop();
    setIsPlayingAudio(false);
    setCurrentTrack(null);
  };

  // Navigation handlers
  const handleSelectTab = (tab: NavTab) => {
    setActiveReader(null);
    if (tab === 'bible' && currentTab === 'bible') {
      setBibleSelectedBookId(null);
    }
    setCurrentTab(tab);
    window.scrollTo(0, 0);
  };

  const handleOpenReader = (bookId: string = 'john', chapter: number = 3, initialVerse?: number) => {
    setActiveReader({ bookId, chapter, initialVerse });
    setBibleSelectedBookId(bookId);
    setReadingProgress((prev) => ({
      ...prev,
      bookId,
      chapter,
      translation: selectedTranslation,
      updatedAt: new Date().toISOString(),
    }));
  };

  const handleNavigateToVerse = (bookId: string, chapter: number, verse: number) => {
    handleOpenReader(bookId, chapter, verse);
  };

  // Reader Interactions
  const handleToggleBookmark = (verse: BibleVerse) => {
    const existingIndex = bookmarks.findIndex(
      (b) => b.bookId === verse.bookId && b.chapter === verse.chapter && b.verse === verse.verse
    );
    if (existingIndex >= 0) {
      setBookmarks((prev) => prev.filter((_, idx) => idx !== existingIndex));
      showToast('Bookmark removed');
    } else {
      const newBm: BookmarkItem = {
        id: `bm-${Date.now()}`,
        bookId: verse.bookId,
        chapter: verse.chapter,
        verse: verse.verse,
        text: verse.text,
        translation: verse.translation,
        createdAt: new Date().toISOString(),
      };
      setBookmarks((prev) => [newBm, ...prev]);
      showToast('Verse bookmarked');
    }
  };

  const handleAddHighlight = (verse: BibleVerse, color: 'gold' | 'cyan' | 'emerald' | 'rose') => {
    setHighlights((prev) => [
      {
        id: `hl-${Date.now()}`,
        bookId: verse.bookId,
        chapter: verse.chapter,
        verse: verse.verse,
        text: verse.text,
        color,
        translation: verse.translation,
        createdAt: new Date().toISOString(),
      },
      ...prev.filter(
        (h) => !(h.bookId === verse.bookId && h.chapter === verse.chapter && h.verse === verse.verse)
      ),
    ]);
    showToast(`Verse illuminated in ${color}`);
  };

  const handleRemoveHighlight = (verse: BibleVerse) => {
    setHighlights((prev) =>
      prev.filter(
        (h) => !(h.bookId === verse.bookId && h.chapter === verse.chapter && h.verse === verse.verse)
      )
    );
    showToast('Highlight cleared');
  };

  const handleAddNote = (verse: BibleVerse, noteText: string) => {
    setNotes((prev) => [
      {
        id: `note-${Date.now()}`,
        bookId: verse.bookId,
        chapter: verse.chapter,
        verse: verse.verse,
        verseText: verse.text,
        noteText,
        translation: verse.translation,
        createdAt: new Date().toISOString(),
      },
      ...prev.filter(
        (n) => !(n.bookId === verse.bookId && n.chapter === verse.chapter && n.verse === verse.verse)
      ),
    ]);
    showToast('Study note saved');
  };

  const handleShareVerse = (verse: BibleVerse) => {
    const textToShare = `“${verse.text}” — ${verse.bookId.toUpperCase()} ${verse.chapter}:${verse.verse} (WordOra)`;
    if (navigator.clipboard) {
      navigator.clipboard.writeText(textToShare);
      showToast('Verse copied to clipboard');
    } else {
      showToast('Verse ready to share');
    }
  };

  const handleAskAIAboutVerse = (verse: BibleVerse) => {
    setActiveReader(null);
    setCurrentTab('ai');
    setAiInitialQuery(`Please explain ${verse.bookId.toUpperCase()} ${verse.chapter}:${verse.verse} (“${verse.text}”) with historical and spiritual depth.`);
  };

  // Daily Verse Bookmark / Share
  const handleBookmarkDailyVerse = () => {
    if (!selectedTranslation) {
      showToast('No Bible translation installed');
      return;
    }
    const verses = getAuthoritativeChapterVerses('psalms', 119, selectedTranslation);
    const v105 = verses.find((v) => v.verse === 105);
    const dailyVerse: BibleVerse = {
      bookId: 'psalms',
      chapter: 119,
      verse: 105,
      text: v105?.text || '(نون) تیرا کلام میرے قدموں کے لِئے چراغ اور میری راہ کے لِئے رَوشنی ہے۔',
      translation: selectedTranslation,
    };
    handleToggleBookmark(dailyVerse);
  };

  const handleShareDailyVerse = () => {
    if (!selectedTranslation) {
      showToast('No Bible translation installed');
      return;
    }
    const verses = getAuthoritativeChapterVerses('psalms', 119, selectedTranslation);
    const v105 = verses.find((v) => v.verse === 105);
    handleShareVerse({
      bookId: 'psalms',
      chapter: 119,
      verse: 105,
      text: v105?.text || '(نون) تیرا کلام میرے قدموں کے لِئے چراغ اور میری راہ کے لِئے رَوشنی ہے۔',
      translation: selectedTranslation,
    });
  };

  // Prayers
  const handleAddPrayer = (
    title: string,
    content: string,
    category: 'personal' | 'family' | 'healing' | 'community'
  ) => {
    const newP: PrayerItem = {
      id: `pr-${Date.now()}`,
      title,
      content,
      category,
      isAnswered: false,
      prayerCount: 1,
      createdAt: new Date().toISOString(),
    };
    setPrayers((prev) => [newP, ...prev]);
    showToast('Prayer petition lifted to Khuda');
  };

  const handleMarkPrayerAnswered = (id: string, testimony?: string) => {
    setPrayers((prev) =>
      prev.map((p) =>
        p.id === id
          ? {
              ...p,
              isAnswered: true,
              answeredAt: new Date().toISOString(),
              testimony,
            }
          : p
      )
    );
    showToast('Praise God! Testimony recorded');
  };

  const handleIncrementPrayerCount = (id: string) => {
    setPrayers((prev) =>
      prev.map((p) => (p.id === id ? { ...p, prayerCount: p.prayerCount + 1 } : p))
    );
    showToast('Amen! Prayed today');
  };

  const handleDeletePrayer = (id: string) => {
    setPrayers((prev) => prev.filter((p) => p.id !== id));
    showToast('Prayer removed');
  };

  const handleTogglePrayerReminder = () => {
    setPrayerReminder((prev) => {
      const next = { ...prev, enabled: !prev.enabled };
      showToast(next.enabled ? 'Daily Prayer Bell set for 7:00 AM' : 'Prayer Bell muted');
      return next;
    });
  };

  return (
    <div className="min-h-screen bg-[#081220] text-[#F7F6F2] flex justify-center font-sans select-none antialiased">
      {/* Mobile Android Container Frame */}
      <div className="w-full max-w-md min-h-screen flex flex-col bg-[#081220] border-x border-[#1F2A44]/60 shadow-2xl relative">
        {/* Top Sacred Header */}
        {!activeReader && (
          <Header
            onOpenMenu={() => setIsMenuOpen(true)}
            onOpenNotifications={() => {
              showToast(
                prayerReminder.enabled
                  ? 'Daily Prayer Bell is active at 7:00 AM'
                  : 'Daily Prayer Bell is currently off'
              );
            }}
            onOpenProfile={() => setIsProfileOpen(true)}
            onLogoClick={() => handleSelectTab('home')}
            reminderActive={prayerReminder.enabled}
          />
        )}

        {/* Main View Display */}
        <main className="flex-1 flex flex-col min-h-0 relative">
          {activeReader ? (
            <ReaderScreen
              bookId={activeReader.bookId}
              chapter={activeReader.chapter}
              initialVerse={activeReader.initialVerse}
              translation={selectedTranslation}
              onNavigateChapter={(b, c) => {
                setActiveReader({ bookId: b, chapter: c });
                setReadingProgress((prev) => ({
                  ...prev,
                  bookId: b,
                  chapter: c,
                  updatedAt: new Date().toISOString(),
                }));
              }}
              onBack={() => {
                setActiveReader(null);
                setCurrentTab('bible');
              }}
              onOpenChapterSelect={() => {
                if (activeReader) {
                  setBibleSelectedBookId(activeReader.bookId);
                }
                setActiveReader(null);
                setCurrentTab('bible');
              }}
              onOpenTranslations={() => setIsTranslationsOpen(true)}
              bookmarks={bookmarks}
              highlights={highlights}
              notes={notes}
              onToggleBookmark={handleToggleBookmark}
              onAddHighlight={handleAddHighlight}
              onRemoveHighlight={handleRemoveHighlight}
              onAddNote={handleAddNote}
              onShareVerse={handleShareVerse}
              onAskAIAboutVerse={handleAskAIAboutVerse}
              readerConfig={readerConfig}
              onUpdateReaderConfig={setReaderConfig}
            />
          ) : currentTab === 'home' ? (
            <HomeScreen
              onNavigateToBible={(b, c) => handleOpenReader(b, c)}
              onNavigateToSearch={() => setCurrentTab('search')}
              onNavigateToWorship={() => setCurrentTab('worship')}
              onNavigateToPrayer={() => {
                setSavedInitialTab('bookmarks');
                setCurrentTab('saved');
              }}
              onNavigateToAI={(query) => {
                if (query) setAiInitialQuery(query);
                setCurrentTab('ai');
              }}
              onNavigateToSaved={(tab) => {
                if (tab) setSavedInitialTab(tab);
                setCurrentTab('saved');
              }}
              onOpenTranslations={() => setIsTranslationsOpen(true)}
              readingProgress={readingProgress}
              prayerReminderEnabled={prayerReminder.enabled}
              onTogglePrayerReminder={handleTogglePrayerReminder}
              onShareDailyVerse={handleShareDailyVerse}
              onBookmarkDailyVerse={handleBookmarkDailyVerse}
              dailyVerseBookmarked={isDailyVerseBookmarked}
            />
          ) : currentTab === 'bible' ? (
            <BibleScreen
              onSelectBook={(b, c) => handleOpenReader(b, c || 1)}
              onOpenSearch={() => setCurrentTab('search')}
              selectedTranslation={selectedTranslation}
              selectedBookId={bibleSelectedBookId}
              onSelectBookId={setBibleSelectedBookId}
              onBackToHome={() => handleSelectTab('home')}
              currentReadingChapter={
                readingProgress.bookId === bibleSelectedBookId
                  ? readingProgress.chapter
                  : undefined
              }
            />
          ) : currentTab === 'worship' ? (
            <WorshipScreen
              currentTrack={currentTrack}
              isPlaying={isPlayingAudio}
              onPlayTrack={handlePlayTrack}
              onTogglePlay={handleTogglePlayAudio}
            />
          ) : currentTab === 'search' ? (
            <SearchScreen
              onNavigateToVerse={handleNavigateToVerse}
              selectedTranslation={selectedTranslation}
            />
          ) : currentTab === 'saved' ? (
            <SavedScreen
              initialTab={savedInitialTab}
              bookmarks={bookmarks}
              highlights={highlights}
              notes={notes}
              onDeleteBookmark={(id) => {
                setBookmarks((prev) => prev.filter((b) => b.id !== id));
                showToast('Bookmark deleted');
              }}
              onDeleteHighlight={(id) => {
                setHighlights((prev) => prev.filter((h) => h.id !== id));
                showToast('Highlight deleted');
              }}
              onDeleteNote={(id) => {
                setNotes((prev) => prev.filter((n) => n.id !== id));
                showToast('Note deleted');
              }}
              onNavigateToVerse={handleNavigateToVerse}
            />
          ) : currentTab === 'ai' ? (
            <AIScreen
              initialQuery={aiInitialQuery}
              selectedTranslation={selectedTranslation}
              onNavigateToVerse={handleNavigateToVerse}
            />
          ) : null}
        </main>

        {/* Floating Ambient Worship Bar (when active) */}
        <AudioPlayerBar
          currentTrack={currentTrack}
          isPlaying={isPlayingAudio}
          onTogglePlay={handleTogglePlayAudio}
          onCloseTrack={handleCloseAudio}
        />

        {/* Bottom Navigation (When not immersed in Reader) */}
        {!activeReader && (
          <BottomNavigation currentTab={currentTab} onSelectTab={handleSelectTab} />
        )}

        {/* Navigation Drawer */}
        <NavigationDrawer
          isOpen={isMenuOpen}
          onClose={() => setIsMenuOpen(false)}
          onSelectTab={handleSelectTab}
          onOpenTranslations={() => setIsTranslationsOpen(true)}
          onOpenAbout={() => setIsAboutOpen(true)}
          onOpenPrayer={() => {
            setSavedInitialTab('bookmarks');
            setCurrentTab('saved');
          }}
          onOpenFullImport={() => setIsFullImportOpen(true)}
        />

        {/* Translations Modal */}
        <TranslationsModal
          isOpen={isTranslationsOpen}
          onClose={() => setIsTranslationsOpen(false)}
          selectedTranslation={selectedTranslation}
          onSelectTranslation={(id) => {
            setSelectedTranslation(id);
            setIsTranslationsOpen(false);
            showToast(`Active Translation: ${id.toUpperCase()}`);
          }}
          onOpenFullImport={() => setIsFullImportOpen(true)}
        />

        {/* About WordOra Modal */}
        <AboutModal isOpen={isAboutOpen} onClose={() => setIsAboutOpen(false)} />

        {/* Full Bible Importer Modal */}
        <FullBibleImportModal
          isOpen={isFullImportOpen}
          onClose={() => setIsFullImportOpen(false)}
          onImportComplete={() => {
            showToast('Full کِتابِ مُقادّس Bible import completed!');
          }}
        />

        {/* User Profile Modal */}
        <ProfileModal
          isOpen={isProfileOpen}
          onClose={() => setIsProfileOpen(false)}
          selectedTranslation={selectedTranslation}
          onSelectTranslation={setSelectedTranslation}
          prayerReminderEnabled={prayerReminder.enabled}
          onTogglePrayerReminder={handleTogglePrayerReminder}
          savedCount={bookmarks.length + highlights.length + notes.length}
          prayerCount={prayers.length}
        />

        {/* Notification Toast */}
        {toastMessage && (
          <div className="fixed top-14 left-0 right-0 z-50 flex justify-center px-4 pointer-events-none animate-in fade-in slide-in-from-top-2">
            <div className="px-4 py-2 rounded-xl bg-[#0F1A2E]/95 border border-[#D4AF37]/60 text-xs font-semibold text-[#F5D77A] shadow-2xl backdrop-blur-md flex items-center gap-2">
              <span className="w-1.5 h-1.5 rounded-full bg-[#00C6FF]" />
              <span>{toastMessage}</span>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
export default App;
