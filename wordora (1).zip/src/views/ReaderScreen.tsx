import React, { useState, useEffect } from 'react';
import {
  ChevronLeft,
  ChevronRight,
  Volume2,
  VolumeX,
  Type,
  Bookmark,
  Highlighter,
  FileText,
  Share2,
  Bot,
  Check,
  Globe,
  Sliders,
  Sparkles,
  BookOpen,
} from 'lucide-react';
import { BIBLE_BOOKS, getChapterVerses, registerImportedChapter } from '../data/bibleData';
import { TranslationId, BibleVerse, HighlightItem, BookmarkItem, NoteItem } from '../types';
import { speakVerses } from '../utils/audioSynthesizer';
import { ReaderConfig } from '../utils/storage';

interface ReaderScreenProps {
  bookId: string;
  chapter: number;
  initialVerse?: number;
  translation: TranslationId;
  onNavigateChapter: (bookId: string, chapter: number) => void;
  onBack: () => void;
  onOpenChapterSelect?: () => void;
  onOpenTranslations: () => void;
  bookmarks: BookmarkItem[];
  highlights: HighlightItem[];
  notes: NoteItem[];
  onToggleBookmark: (verse: BibleVerse) => void;
  onAddHighlight: (verse: BibleVerse, color: 'gold' | 'cyan' | 'emerald' | 'rose') => void;
  onRemoveHighlight: (verse: BibleVerse) => void;
  onAddNote: (verse: BibleVerse, noteText: string) => void;
  onShareVerse: (verse: BibleVerse) => void;
  onAskAIAboutVerse: (verse: BibleVerse) => void;
  readerConfig: ReaderConfig;
  onUpdateReaderConfig: (config: ReaderConfig) => void;
}

export const ReaderScreen: React.FC<ReaderScreenProps> = ({
  bookId,
  chapter,
  initialVerse,
  translation,
  onNavigateChapter,
  onBack,
  onOpenChapterSelect,
  onOpenTranslations,
  bookmarks,
  highlights,
  notes,
  onToggleBookmark,
  onAddHighlight,
  onRemoveHighlight,
  onAddNote,
  onShareVerse,
  onAskAIAboutVerse,
  readerConfig,
  onUpdateReaderConfig,
}) => {
  const [selectedVerseNumber, setSelectedVerseNumber] = useState<number | null>(null);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [stopSpeechFn, setStopSpeechFn] = useState<(() => void) | null>(null);
  const [showConfigModal, setShowConfigModal] = useState(false);
  const [showNoteInputModal, setShowNoteInputModal] = useState(false);
  const [noteTextInput, setNoteTextInput] = useState('');

  const [dynamicVerses, setDynamicVerses] = useState<BibleVerse[]>([]);
  const [isLoadingVerses, setIsLoadingVerses] = useState(false);

  const currentBook = BIBLE_BOOKS.find(b => b.id === bookId) || BIBLE_BOOKS[0];
  const staticVerses = getChapterVerses(bookId, chapter, translation);
  const verses = staticVerses.length > 0 ? staticVerses : dynamicVerses;
  const isUrduRTL = translation === 'ur';

  // Load verses from backend if not bundled statically
  useEffect(() => {
    if (staticVerses.length > 0) {
      setDynamicVerses([]);
      return;
    }
    let isCancelled = false;
    setIsLoadingVerses(true);
    fetch(`/api/scripture/${bookId}/${chapter}`)
      .then((res) => {
        if (!res.ok) throw new Error("Chapter not in database");
        return res.json();
      })
      .then((data) => {
        if (!isCancelled && data.verses && data.verses.length > 0) {
          setDynamicVerses(data.verses);
          registerImportedChapter(bookId, chapter, translation, data.verses);
        }
      })
      .catch(() => {
        if (!isCancelled) {
          setDynamicVerses([]);
        }
      })
      .finally(() => {
        if (!isCancelled) {
          setIsLoadingVerses(false);
        }
      });

    return () => {
      isCancelled = true;
    };
  }, [bookId, chapter, translation, staticVerses.length]);

  // Auto-scroll to verse if navigated from search or deep link
  useEffect(() => {
    if (initialVerse && verses.length > 0) {
      setSelectedVerseNumber(initialVerse);
      const timer = setTimeout(() => {
        const el = document.getElementById(`verse-${initialVerse}`);
        if (el) {
          el.scrollIntoView({ behavior: 'smooth', block: 'center' });
        }
      }, 200);
      return () => clearTimeout(timer);
    }
  }, [initialVerse, verses.length, bookId, chapter]);

  // Stop speech if chapter changes
  useEffect(() => {
    if (stopSpeechFn) {
      stopSpeechFn();
      setIsSpeaking(false);
    }
  }, [bookId, chapter, translation]);

  const handleToggleSpeech = () => {
    if (verses.length === 0) return;
    if (isSpeaking) {
      if (stopSpeechFn) stopSpeechFn();
      setIsSpeaking(false);
      setStopSpeechFn(null);
    } else {
      const fullText = verses.map(v => `Verse ${v.verse}. ${v.text}`).join(' ');
      const stop = speakVerses(fullText, () => setIsSpeaking(false));
      setStopSpeechFn(() => stop);
      setIsSpeaking(true);
    }
  };

  const selectedVerseObj = verses.find(v => v.verse === selectedVerseNumber) || verses[0];

  const handleOpenNoteModal = () => {
    if (!selectedVerseObj) return;
    const existing = notes.find(
      n => n.bookId === bookId && n.chapter === chapter && n.verse === selectedVerseObj.verse
    );
    setNoteTextInput(existing?.noteText || '');
    setShowNoteInputModal(true);
  };

  const handleSaveNote = () => {
    if (selectedVerseObj && noteTextInput.trim()) {
      onAddNote(selectedVerseObj, noteTextInput.trim());
    }
    setShowNoteInputModal(false);
  };

  const canGoPrev = chapter > 1;
  const canGoNext = chapter < currentBook.chaptersCount;

  return (
    <div className="flex-1 flex flex-col h-full bg-[#081220] text-[#F7F6F2] overflow-hidden">
      {/* Top Header Bar */}
      <div className="sticky top-0 z-30 bg-[#081220]/95 backdrop-blur-md border-b border-[#1F2A44] px-3 py-2 flex items-center justify-between">
        <button
          type="button"
          onClick={onBack}
          className="w-10 h-10 flex items-center justify-center rounded-xl text-[#B6C0D1] hover:text-[#F7F6F2] hover:bg-[#0F1A2E] active:scale-95 transition-all"
          aria-label="Back to Books"
        >
          <ChevronLeft className="w-6 h-6" />
        </button>

        {/* Book & Chapter title (tappable to jump to Chapter Selection Grid) */}
        <button
          type="button"
          onClick={() => {
            if (onOpenChapterSelect) {
              onOpenChapterSelect();
            } else {
              onBack();
            }
          }}
          className="flex items-center gap-1.5 px-3 py-1 rounded-xl hover:bg-[#0F1A2E] border border-transparent hover:border-[#1F2A44] transition-all group cursor-pointer"
          title="Change Chapter"
        >
          <div className="text-center">
            <div className="flex items-center justify-center gap-1">
              <h1 className="text-sm font-bold font-serif-sacred text-[#F7F6F2] group-hover:text-[#F5D77A] tracking-wide transition-colors">
                {currentBook.name} {chapter}
              </h1>
              <ChevronRight className="w-3.5 h-3.5 text-[#7A869A] group-hover:text-[#F5D77A] transition-colors" />
            </div>
            <span className="text-[10px] text-[#7A869A] block group-hover:text-[#B6C0D1] transition-colors">
              {currentBook.category} • Tap to change chapter
            </span>
          </div>
        </button>

        {/* Action icons */}
        <div className="flex items-center gap-1">
          {/* Translation selector pill */}
          <button
            type="button"
            onClick={onOpenTranslations}
            className="px-2.5 py-1 rounded-lg bg-[#0F1A2E] border border-[#1F2A44] hover:border-[#D4AF37]/60 text-xs font-semibold text-[#D4AF37] uppercase flex items-center gap-1 active:scale-95 transition-all"
            title="Change Translation"
          >
            <Globe className="w-3 h-3 text-[#00C6FF]" />
            <span>{translation || 'None'}</span>
          </button>

          {/* Audio Speaker */}
          <button
            type="button"
            onClick={handleToggleSpeech}
            className={`w-9 h-9 rounded-lg border flex items-center justify-center transition-all ${
              isSpeaking
                ? 'bg-[#00C6FF]/20 border-[#00C6FF] text-[#00C6FF] animate-pulse'
                : 'bg-[#0F1A2E] border-[#1F2A44] text-[#B6C0D1] hover:text-[#F7F6F2]'
            }`}
            title={isSpeaking ? "Pause Audio" : "Listen to Chapter"}
          >
            {isSpeaking ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
          </button>

          {/* Display / Font Settings */}
          <button
            type="button"
            onClick={() => setShowConfigModal(!showConfigModal)}
            className="w-9 h-9 rounded-lg bg-[#0F1A2E] border border-[#1F2A44] flex items-center justify-center text-[#B6C0D1] hover:text-[#F7F6F2]"
            title="Display Options"
          >
            <Type className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Scripture Content Canvas */}
      <div className="flex-1 overflow-y-auto px-5 py-6 space-y-4 max-w-2xl mx-auto w-full pb-36">
        {/* Chapter Header */}
        <div className="text-center pb-4 border-b border-[#1F2A44]/60">
          <div className="inline-flex items-center justify-center w-8 h-8 rounded-full border border-[#D4AF37]/50 text-[#F5D77A] text-xs font-serif-sacred mb-2 shadow-sm">
            ✝
          </div>
          <h2 className="text-xl font-bold font-serif-sacred text-[#D4AF37] tracking-wider uppercase">
            {currentBook.name}
          </h2>
          <p className="text-xs text-[#7A869A] mt-1 tracking-widest uppercase">
            Chapter {chapter}
          </p>
        </div>

        {/* Verses Container */}
        {isLoadingVerses ? (
          <div className="my-16 p-7 rounded-2xl bg-[#0F1A2E] border border-[#1F2A44] text-center space-y-4 max-w-sm mx-auto shadow-xl">
            <div className="w-12 h-12 border-2 border-[#D4AF37] border-t-transparent rounded-full animate-spin mx-auto" />
            <div className="space-y-1">
              <h3 className="text-sm font-bold font-serif-sacred text-[#F7F6F2]">
                Loading Scripture...
              </h3>
              <p className="text-xs text-[#7A869A]">
                {currentBook.name} {chapter}
              </p>
            </div>
          </div>
        ) : verses.length === 0 ? (
          <div className="my-10 p-7 rounded-2xl bg-[#0F1A2E] border border-[#1F2A44] text-center space-y-4 max-w-sm mx-auto shadow-xl">
            <div className="w-14 h-14 rounded-2xl bg-[#081220] border border-[#D4AF37]/40 flex items-center justify-center text-[#F5D77A] mx-auto shadow-inner">
              <BookOpen className="w-7 h-7 stroke-[1.8]" />
            </div>
            <div className="space-y-1.5">
              <h3 className="text-base font-bold font-serif-sacred text-[#F7F6F2]">
                No Bible translation installed.
              </h3>
              <p className="text-xs text-[#7A869A] leading-relaxed">
                Add an authorized Bible translation to begin reading.
              </p>
            </div>
            <button
              type="button"
              onClick={onOpenTranslations}
              className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-gradient-to-r from-[#D4AF37] to-[#F5D77A] text-[#081220] font-bold text-xs uppercase tracking-wider hover:opacity-95 active:scale-95 transition-all shadow-md"
            >
              <Globe className="w-4 h-4" />
              <span>Install Translations</span>
            </button>
          </div>
        ) : (
          <div
            className={`space-y-3 leading-relaxed transition-all ${
              isUrduRTL ? 'text-right font-urdu rtl' : 'text-left font-sans ltr'
            }`}
            style={{
              fontSize: `${readerConfig.fontSize}px`,
              lineHeight: readerConfig.lineHeight,
              fontFamily: readerConfig.fontFamily === 'serif' ? 'Cinzel, Georgia, serif' : undefined,
            }}
          >
            {verses.map((verse) => {
              const isSelected = selectedVerseNumber === verse.verse;
              const highlight = highlights.find(
                h => h.bookId === bookId && h.chapter === chapter && h.verse === verse.verse
              );
              const isBookmarked = bookmarks.some(
                b => b.bookId === bookId && b.chapter === chapter && b.verse === verse.verse
              );
              const hasNote = notes.some(
                n => n.bookId === bookId && n.chapter === chapter && n.verse === verse.verse
              );

              // Highlight styling
              let highlightBg = '';
              if (highlight?.color === 'gold') highlightBg = 'bg-[#D4AF37]/20 rounded px-1 text-[#FFF4D0] border-b border-[#D4AF37]';
              if (highlight?.color === 'cyan') highlightBg = 'bg-[#00C6FF]/20 rounded px-1 text-[#E0F7FF] border-b border-[#00C6FF]';
              if (highlight?.color === 'emerald') highlightBg = 'bg-emerald-500/20 rounded px-1 text-emerald-200 border-b border-emerald-400';
              if (highlight?.color === 'rose') highlightBg = 'bg-rose-500/20 rounded px-1 text-rose-200 border-b border-rose-400';

              return (
                <React.Fragment key={verse.verse}>
                  {verse.sectionHeading && (
                    <div className="pt-5 pb-2.5 my-2 border-b border-[#1F2A44]/70">
                      <h3 className="text-base sm:text-lg font-bold text-[#D4AF37] font-urdu tracking-wide leading-relaxed">
                        {verse.sectionHeading}
                      </h3>
                    </div>
                  )}
                  <p
                    id={`verse-${verse.verse}`}
                    onClick={() => setSelectedVerseNumber(isSelected ? null : verse.verse)}
                  className={`p-2 rounded-xl cursor-pointer transition-all ${
                    isSelected
                      ? 'bg-[#111A2E] border border-[#00C6FF]/60 shadow-lg'
                      : 'hover:bg-[#0F1A2E]/50'
                  }`}
                >
                  {/* Verse Number (Gold, sacred modern specification) */}
                  <span
                    className={`inline-flex items-center justify-center text-xs font-serif-sacred font-bold text-[#D4AF37] mr-2 select-none ${
                      isSelected ? 'text-[#F5D77A]' : ''
                    }`}
                  >
                    {verse.verse}
                  </span>

                  {/* Verse Text with possible highlight */}
                  <span className={`${highlightBg} transition-colors`}>
                    {verse.text}
                  </span>

                  {/* Indicators */}
                  {(isBookmarked || hasNote) && (
                    <span className="inline-flex items-center gap-1 ml-2 text-xs">
                      {isBookmarked && (
                        <span className="text-[#F5D77A]" title="Bookmarked">
                          ★
                        </span>
                      )}
                      {hasNote && (
                        <span className="text-[#00C6FF]" title="Has Note">
                          📝
                        </span>
                      )}
                    </span>
                  )}
                </p>
                </React.Fragment>
              );
            })}
          </div>
        )}

        {/* Chapter Navigation Buttons */}
        <div className="flex items-center justify-between pt-8 pb-4 border-t border-[#1F2A44]/60">
          <button
            type="button"
            disabled={!canGoPrev}
            onClick={() => onNavigateChapter(bookId, chapter - 1)}
            className={`px-4 py-2.5 rounded-xl border flex items-center gap-2 text-xs font-semibold transition-all ${
              canGoPrev
                ? 'bg-[#0F1A2E] border-[#1F2A44] text-[#F7F6F2] hover:border-[#D4AF37]/60 active:scale-95'
                : 'opacity-30 border-[#1F2A44] text-[#7A869A] cursor-not-allowed'
            }`}
          >
            <ChevronLeft className="w-4 h-4" />
            <span>Previous</span>
          </button>

          <span className="text-xs text-[#7A869A] font-medium">
            {currentBook.name} {chapter} of {currentBook.chaptersCount}
          </span>

          <button
            type="button"
            disabled={!canGoNext}
            onClick={() => onNavigateChapter(bookId, chapter + 1)}
            className={`px-4 py-2.5 rounded-xl border flex items-center gap-2 text-xs font-semibold transition-all ${
              canGoNext
                ? 'bg-[#0F1A2E] border-[#1F2A44] text-[#F7F6F2] hover:border-[#D4AF37]/60 active:scale-95'
                : 'opacity-30 border-[#1F2A44] text-[#7A869A] cursor-not-allowed'
            }`}
          >
            <span>Next</span>
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Floating Verse Action Toolbar (When a verse is tapped) */}
      {selectedVerseNumber !== null && (
        <div className="fixed bottom-16 left-0 right-0 z-40 px-4 max-w-md mx-auto animate-in slide-in-from-bottom-3">
          <div className="p-3 rounded-2xl bg-[#0F1A2E]/98 border border-[#00C6FF]/60 shadow-2xl backdrop-blur-xl">
            <div className="flex items-center justify-between pb-2 mb-2 border-b border-[#1F2A44] text-xs">
              <span className="font-serif-sacred font-bold text-[#F5D77A]">
                {currentBook.name} {chapter}:{selectedVerseNumber}
              </span>
              <button
                type="button"
                onClick={() => setSelectedVerseNumber(null)}
                className="text-[11px] text-[#7A869A] hover:text-[#F7F6F2]"
              >
                Deselect
              </button>
            </div>

            {/* Quick Actions Row */}
            <div className="flex items-center justify-between gap-1">
              {/* Bookmark */}
              <button
                type="button"
                onClick={() => {
                  onToggleBookmark(selectedVerseObj);
                }}
                className="flex-1 py-1.5 px-2 rounded-xl bg-[#081220] border border-[#1F2A44] hover:border-[#D4AF37]/60 text-xs flex flex-col items-center justify-center gap-1 active:scale-95 transition-all"
              >
                <Bookmark className="w-4 h-4 text-[#F5D77A]" />
                <span className="text-[10px] text-[#B6C0D1]">Bookmark</span>
              </button>

              {/* Color Highlighters */}
              <div className="flex items-center gap-1 px-1">
                <button
                  type="button"
                  onClick={() => onAddHighlight(selectedVerseObj, 'gold')}
                  className="w-7 h-7 rounded-full bg-[#D4AF37] border-2 border-white/40 hover:scale-110 active:scale-95 shadow-sm"
                  title="Highlight Gold"
                />
                <button
                  type="button"
                  onClick={() => onAddHighlight(selectedVerseObj, 'cyan')}
                  className="w-7 h-7 rounded-full bg-[#00C6FF] border-2 border-white/40 hover:scale-110 active:scale-95 shadow-sm"
                  title="Highlight Cyan"
                />
                <button
                  type="button"
                  onClick={() => onAddHighlight(selectedVerseObj, 'emerald')}
                  className="w-7 h-7 rounded-full bg-emerald-500 border-2 border-white/40 hover:scale-110 active:scale-95 shadow-sm"
                  title="Highlight Emerald"
                />
                <button
                  type="button"
                  onClick={() => onRemoveHighlight(selectedVerseObj)}
                  className="w-7 h-7 rounded-full bg-[#081220] border border-[#1F2A44] text-[10px] text-[#7A869A] flex items-center justify-center hover:text-white"
                  title="Clear highlight"
                >
                  ✕
                </button>
              </div>

              {/* Note */}
              <button
                type="button"
                onClick={handleOpenNoteModal}
                className="flex-1 py-1.5 px-2 rounded-xl bg-[#081220] border border-[#1F2A44] hover:border-[#D4AF37]/60 text-xs flex flex-col items-center justify-center gap-1 active:scale-95 transition-all"
              >
                <FileText className="w-4 h-4 text-[#00C6FF]" />
                <span className="text-[10px] text-[#B6C0D1]">Note</span>
              </button>

              {/* AI Explain */}
              <button
                type="button"
                onClick={() => onAskAIAboutVerse(selectedVerseObj)}
                className="flex-1 py-1.5 px-2 rounded-xl bg-gradient-to-r from-[#00C6FF]/20 to-[#2563EB]/20 border border-[#00C6FF]/50 text-xs flex flex-col items-center justify-center gap-1 active:scale-95 transition-all"
              >
                <Bot className="w-4 h-4 text-[#00C6FF]" />
                <span className="text-[10px] text-[#00C6FF] font-semibold">AI Study</span>
              </button>

              {/* Share */}
              <button
                type="button"
                onClick={() => onShareVerse(selectedVerseObj)}
                className="flex-1 py-1.5 px-2 rounded-xl bg-[#081220] border border-[#1F2A44] hover:border-[#00C6FF]/60 text-xs flex flex-col items-center justify-center gap-1 active:scale-95 transition-all"
              >
                <Share2 className="w-4 h-4 text-[#B6C0D1]" />
                <span className="text-[10px] text-[#B6C0D1]">Share</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Note Input Modal */}
      {showNoteInputModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-md">
          <div className="w-full max-w-sm rounded-2xl bg-[#0F1A2E] border border-[#1F2A44] p-5 shadow-2xl space-y-4">
            <h3 className="text-sm font-bold text-[#F7F6F2] font-serif-sacred">
              Note for {currentBook.name} {chapter}:{selectedVerseNumber}
            </h3>

            <textarea
              value={noteTextInput}
              onChange={(e) => setNoteTextInput(e.target.value)}
              placeholder="Write your spiritual reflection, prayer or study note..."
              rows={4}
              className="w-full p-3 rounded-xl bg-[#081220] border border-[#1F2A44] text-xs text-[#F7F6F2] placeholder-[#7A869A] focus:outline-none focus:border-[#D4AF37]"
            />

            <div className="flex items-center justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setShowNoteInputModal(false)}
                className="px-4 py-2 rounded-xl text-xs text-[#7A869A] hover:text-[#F7F6F2]"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleSaveNote}
                className="px-4 py-2 rounded-xl bg-[#D4AF37] text-[#081220] text-xs font-bold uppercase tracking-wider shadow-md"
              >
                Save Note
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Display / Font Modal */}
      {showConfigModal && (
        <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-3 bg-black/75 backdrop-blur-md">
          <div className="w-full max-w-sm rounded-2xl bg-[#0F1A2E] border border-[#1F2A44] p-5 shadow-2xl space-y-5">
            <div className="flex items-center justify-between border-b border-[#1F2A44] pb-3">
              <span className="text-xs font-bold uppercase tracking-wider text-[#F5D77A]">
                Reading Preferences
              </span>
              <button
                type="button"
                onClick={() => setShowConfigModal(false)}
                className="text-xs text-[#7A869A] hover:text-[#F7F6F2]"
              >
                Done
              </button>
            </div>

            {/* Font Size */}
            <div className="space-y-2">
              <div className="flex items-center justify-between text-xs text-[#B6C0D1]">
                <span>Font Size</span>
                <span className="font-semibold text-[#00C6FF]">{readerConfig.fontSize}px</span>
              </div>
              <div className="flex items-center gap-3">
                <button
                  type="button"
                  onClick={() => onUpdateReaderConfig({ ...readerConfig, fontSize: Math.max(14, readerConfig.fontSize - 1) })}
                  className="px-3 py-1.5 rounded-lg bg-[#081220] border border-[#1F2A44] text-xs font-bold text-[#F7F6F2]"
                >
                  A-
                </button>
                <input
                  type="range"
                  min={14}
                  max={26}
                  value={readerConfig.fontSize}
                  onChange={(e) => onUpdateReaderConfig({ ...readerConfig, fontSize: parseInt(e.target.value) })}
                  className="flex-1 accent-[#00C6FF]"
                />
                <button
                  type="button"
                  onClick={() => onUpdateReaderConfig({ ...readerConfig, fontSize: Math.min(26, readerConfig.fontSize + 1) })}
                  className="px-3 py-1.5 rounded-lg bg-[#081220] border border-[#1F2A44] text-xs font-bold text-[#F7F6F2]"
                >
                  A+
                </button>
              </div>
            </div>

            {/* Font Type */}
            <div className="space-y-2">
              <span className="text-xs text-[#B6C0D1]">Font Family</span>
              <div className="grid grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={() => onUpdateReaderConfig({ ...readerConfig, fontFamily: 'sans' })}
                  className={`py-2 px-3 rounded-xl border text-xs font-medium ${
                    readerConfig.fontFamily === 'sans'
                      ? 'bg-[#111A2E] border-[#00C6FF] text-[#00C6FF]'
                      : 'bg-[#081220] border-[#1F2A44] text-[#B6C0D1]'
                  }`}
                >
                  Modern Sans
                </button>
                <button
                  type="button"
                  onClick={() => onUpdateReaderConfig({ ...readerConfig, fontFamily: 'serif' })}
                  className={`py-2 px-3 rounded-xl border text-xs font-medium font-serif ${
                    readerConfig.fontFamily === 'serif'
                      ? 'bg-[#111A2E] border-[#D4AF37] text-[#F5D77A]'
                      : 'bg-[#081220] border-[#1F2A44] text-[#B6C0D1]'
                  }`}
                >
                  Sacred Serif
                </button>
              </div>
            </div>

            {/* Line Spacing */}
            <div className="space-y-2">
              <span className="text-xs text-[#B6C0D1]">Line Spacing</span>
              <div className="grid grid-cols-3 gap-2">
                {[1.5, 1.75, 2.0].map(spacing => (
                  <button
                    key={spacing}
                    type="button"
                    onClick={() => onUpdateReaderConfig({ ...readerConfig, lineHeight: spacing })}
                    className={`py-2 rounded-xl border text-xs ${
                      readerConfig.lineHeight === spacing
                        ? 'bg-[#111A2E] border-[#00C6FF] text-[#00C6FF]'
                        : 'bg-[#081220] border-[#1F2A44] text-[#B6C0D1]'
                    }`}
                  >
                    {spacing}x
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
